fn main() {
    // The OAuth client ID is a public identifier for this desktop application.
    // Rebuild the Rust binary whenever the publisher changes it.
    println!("cargo:rerun-if-env-changed=VOID_CLIENT_MICROSOFT_CLIENT_ID");
    tauri_build::build()
}
