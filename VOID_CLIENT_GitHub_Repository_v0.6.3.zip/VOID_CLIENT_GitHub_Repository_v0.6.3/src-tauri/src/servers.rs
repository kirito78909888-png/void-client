use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use sha1::Sha1;
use sha2::{Digest, Sha512};
use std::{
    collections::{HashMap, VecDeque},
    fs,
    io::{BufRead, BufReader, Read, Write},
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    net::TcpListener,
    sync::{mpsc, Mutex, OnceLock},
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter, Manager};

const MOJANG_MANIFEST: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const USER_AGENT: &str = "VOID-CLIENT/0.6.3 (Minecraft server manager)";

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ServerInstance {
    pub id: String,
    pub name: String,
    pub minecraft_version: String,
    pub software: String,
    pub ram_mb: u32,
    pub cpu_threads: u8,
    pub java_path: Option<String>,
    pub port: u16,
    pub max_players: u16,
    pub motd: String,
    pub online_mode: bool,
    pub eula_accepted: bool,
    pub installed: bool,
    pub created_at: u64,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ServerInfo {
    #[serde(flatten)]
    pub server: ServerInstance,
    pub is_running: bool,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ServerFile {
    pub name: String,
    pub size: u64,
    pub is_directory: bool,
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ServerModInstallResult {
    pub installed: Vec<String>,
    pub skipped: Vec<String>,
}

#[derive(Debug)]
enum ProcessMessage {
    Input(String),
    Kill,
}

static SERVER_PROCESSES: OnceLock<Mutex<HashMap<String, mpsc::Sender<ProcessMessage>>>> = OnceLock::new();

fn server_processes() -> &'static Mutex<HashMap<String, mpsc::Sender<ProcessMessage>>> {
    SERVER_PROCESSES.get_or_init(|| Mutex::new(HashMap::new()))
}

fn ensure_server_stopped(server_id: &str) -> Result<(), String> {
    if server_processes().lock().map_err(|_| "Server process list is unavailable.")?.contains_key(server_id) {
        return Err("Stop this server before changing its files, mods or configuration.".into());
    }
    Ok(())
}

#[cfg(target_os = "windows")]
fn hide_console(command: &mut Command) {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    command.creation_flags(CREATE_NO_WINDOW);
}
#[cfg(not(target_os = "windows"))]
fn hide_console(_command: &mut Command) {}

fn now_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64
}

fn data_root(app: &AppHandle) -> Result<PathBuf, String> {
    let root = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    Ok(root)
}

fn servers_root(app: &AppHandle) -> Result<PathBuf, String> {
    let root = data_root(app)?.join("servers");
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    Ok(root)
}

fn database_path(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(data_root(app)?.join("servers.json"))
}

fn read_servers(app: &AppHandle) -> Result<Vec<ServerInstance>, String> {
    let path = database_path(app)?;
    if !path.exists() { return Ok(Vec::new()); }
    serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
        .map_err(|e| format!("Could not read server library: {e}"))
}

fn write_servers(app: &AppHandle, servers: &[ServerInstance]) -> Result<(), String> {
    fs::write(database_path(app)?, serde_json::to_vec_pretty(servers).map_err(|e| e.to_string())?)
        .map_err(|e| format!("Could not save server library: {e}"))
}

fn valid_id(id: &str) -> bool {
    !id.is_empty() && id.len() <= 80 && id.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_')
}

fn server_directory(app: &AppHandle, id: &str) -> Result<PathBuf, String> {
    if !valid_id(id) { return Err("Invalid server identifier.".into()); }
    for entry in fs::read_dir(servers_root(app)?).map_err(|e| e.to_string())?.flatten() {
        let path = entry.path();
        if path.is_dir() && path.file_name().and_then(|n| n.to_str()).map(|n| n.ends_with(&format!("-{id}"))).unwrap_or(false) {
            return Ok(path);
        }
    }
    Err("Server directory was not found.".into())
}

fn find_server(app: &AppHandle, id: &str) -> Result<ServerInstance, String> {
    read_servers(app)?.into_iter().find(|s| s.id == id).ok_or_else(|| "Server was not found.".into())
}

fn safe_version(version: &str) -> bool {
    !version.is_empty() && version.len() <= 80 && version.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-' | '+'))
}

fn safe_direct_file_name(name: &str) -> Result<&str, String> {
    let leaf = Path::new(name).file_name().and_then(|n| n.to_str()).ok_or("Invalid file name.")?;
    if leaf != name || leaf.is_empty() || leaf.contains("..") || leaf.chars().any(|c| c.is_control()) {
        return Err("Invalid file name.".into());
    }
    Ok(leaf)
}

fn ensure_server_folders(dir: &Path) -> Result<(), String> {
    for name in ["mods", "config", "plugins", "world", "logs", "backups"] {
        fs::create_dir_all(dir.join(name)).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn default_properties(server: &ServerInstance) -> String {
    let motd = server.motd.replace('\r', " ").replace('\n', " ");
    format!(
        "# VOID CLIENT server settings\nserver-port={}\nmax-players={}\nmotd={}\nonline-mode={}\ndifficulty=easy\ngamemode=survival\npvp=true\nview-distance=10\nsimulation-distance=10\nallow-flight=false\nspawn-protection=16\nwhite-list=false\nenforce-whitelist=false\n",
        server.port, server.max_players, motd, server.online_mode
    )
}

fn http_client() -> Result<Client, String> {
    Client::builder().timeout(Duration::from_secs(300)).user_agent(USER_AGENT).build().map_err(|e| e.to_string())
}

fn get_json(client: &Client, url: &str) -> Result<Value, String> {
    let response = client.get(url).send().map_err(|e| format!("Could not contact metadata service: {e}"))?;
    let status = response.status();
    let body: Value = response.json().map_err(|e| format!("Invalid metadata response: {e}"))?;
    if !status.is_success() {
        return Err(body.get("error").and_then(Value::as_str).unwrap_or("Metadata service returned an error.").to_string());
    }
    Ok(body)
}

fn sha1_hex(bytes: &[u8]) -> String {
    let mut hasher = Sha1::new();
    hasher.update(bytes);
    hex::encode(hasher.finalize())
}

fn download_https(client: &Client, url: &str, max_bytes: u64) -> Result<Vec<u8>, String> {
    let parsed = reqwest::Url::parse(url).map_err(|_| "The download URL is invalid.".to_string())?;
    if parsed.scheme() != "https" { return Err("Only HTTPS downloads are allowed.".into()); }
    let response = client.get(url).send().map_err(|e| format!("Download failed: {e}"))?
        .error_for_status().map_err(|e| format!("Download server returned an error: {e}"))?;
    if response.url().scheme() != "https" { return Err("A download redirected to a non-HTTPS URL and was blocked.".into()); }
    if response.content_length().unwrap_or(0) > max_bytes { return Err("Download exceeded the safety size limit.".into()); }
    let mut limited = response.take(max_bytes + 1);
    let mut bytes = Vec::new();
    limited.read_to_end(&mut bytes).map_err(|e| e.to_string())?;
    if bytes.len() as u64 > max_bytes { return Err("Download exceeded the safety size limit.".into()); }
    Ok(bytes)
}

fn emit_log(app: &AppHandle, server_id: &str, server_name: &str, stream: &str, message: &str) {
    let _ = app.emit("void-server-log", serde_json::json!({
        "serverId": server_id,
        "serverName": server_name,
        "stream": stream,
        "message": message,
        "timestamp": now_ms()
    }));
}

fn start_output_reader<R: Read + Send + 'static>(app: AppHandle, id: String, name: String, stream: &'static str, reader: R, log_path: PathBuf) {
    thread::spawn(move || {
        let mut file = fs::OpenOptions::new().create(true).append(true).open(log_path).ok();
        for line in BufReader::new(reader).lines() {
            match line {
                Ok(line) => {
                    if let Some(f) = file.as_mut() { let _ = writeln!(f, "{line}"); }
                    emit_log(&app, &id, &name, stream, &line);
                }
                Err(e) => { emit_log(&app, &id, &name, "warning", &format!("Could not read process output: {e}")); break; }
            }
        }
    });
}

#[tauri::command]
pub fn get_servers(app: AppHandle) -> Result<Vec<ServerInfo>, String> {
    let servers = read_servers(&app)?;
    let running = server_processes().lock().map_err(|_| "Server process list is unavailable.")?;
    Ok(servers.into_iter().map(|server| ServerInfo { is_running: running.contains_key(&server.id), server }).collect())
}

#[tauri::command]
pub fn create_server(
    app: AppHandle,
    name: String,
    minecraft_version: String,
    software: String,
    ram_mb: u32,
    cpu_threads: u8,
    port: u16,
) -> Result<ServerInstance, String> {
    let name = name.trim();
    if name.is_empty() || name.len() > 48 || name.chars().any(|c| c.is_control()) { return Err("Server name must be 1–48 characters.".into()); }
    if !safe_version(&minecraft_version) { return Err("Enter a valid Minecraft version ID.".into()); }
    if !["Vanilla", "Fabric"].contains(&software.as_str()) { return Err("Choose Vanilla or Fabric server software.".into()); }
    if !(1024..=32768).contains(&ram_mb) { return Err("Server RAM must be between 1 GB and 32 GB.".into()); }
    if !(1..=64).contains(&cpu_threads) { return Err("CPU thread limit must be between 1 and 64.".into()); }
    if port == 0 { return Err("Server port must be between 1 and 65535.".into()); }
    let mut servers = read_servers(&app)?;
    if servers.iter().any(|server| server.port == port) {
        return Err(format!("Port {port} is already assigned to another VOID CLIENT server. Choose a different local port (for example 25566)."));
    }
    let stamp = now_ms();
    let mut id = format!("s{stamp}");
    let mut suffix = 1_u32;
    while servers.iter().any(|server| server.id == id) {
        id = format!("s{stamp}_{suffix}");
        suffix += 1;
    }
    let slug: String = name.chars().map(|c| if c.is_ascii_alphanumeric() { c.to_ascii_lowercase() } else if c.is_whitespace() || c == '-' || c == '_' { '-' } else { '_' }).collect();
    let slug = slug.trim_matches('-');
    let slug = if slug.is_empty() { "server" } else { slug };
    let folder = servers_root(&app)?.join(format!("{slug}-{id}"));
    fs::create_dir_all(&folder).map_err(|e| e.to_string())?;
    let server = ServerInstance {
        id, name: name.to_string(), minecraft_version, software, ram_mb, cpu_threads, java_path: None,
        port, max_players: 20, motd: name.to_string(), online_mode: true, eula_accepted: false, installed: false, created_at: now_ms(),
    };
    ensure_server_folders(&folder)?;
    fs::write(folder.join("server.properties"), default_properties(&server)).map_err(|e| e.to_string())?;
    fs::write(folder.join("eula.txt"), "# Accept the Minecraft EULA in VOID CLIENT's server settings.\neula=false\n").map_err(|e| e.to_string())?;
    servers.push(server.clone());
    write_servers(&app, &servers)?;
    Ok(server)
}

#[tauri::command]
pub fn update_server(app: AppHandle, updated: ServerInstance) -> Result<ServerInstance, String> {
    if !valid_id(&updated.id) { return Err("Invalid server identifier.".into()); }
    if updated.name.trim().is_empty() || updated.name.len() > 48 || updated.name.chars().any(|c| c.is_control()) { return Err("Server name must be 1–48 characters.".into()); }
    if !safe_version(&updated.minecraft_version) || !["Vanilla", "Fabric"].contains(&updated.software.as_str()) { return Err("Invalid Minecraft version or server software.".into()); }
    if !(1024..=32768).contains(&updated.ram_mb) || !(1..=64).contains(&updated.cpu_threads) { return Err("Invalid server resource allocation.".into()); }
    if updated.port == 0 || updated.max_players == 0 || updated.max_players > 1000 { return Err("Invalid port or player limit.".into()); }
    let mut servers = read_servers(&app)?;
    if servers.iter().any(|s| s.id != updated.id && s.port == updated.port) {
        return Err(format!("Port {} is already assigned to another VOID CLIENT server. Choose a different local port.", updated.port));
    }
    let slot = servers.iter_mut().find(|s| s.id == updated.id).ok_or("Server not found.")?;
    *slot = updated.clone();
    write_servers(&app, &servers)?;
    let dir = server_directory(&app, &updated.id)?;
    write_server_properties_for(&dir, &updated)?;
    Ok(updated)
}

fn write_server_properties_for(dir: &Path, server: &ServerInstance) -> Result<(), String> {
    let path = dir.join("server.properties");
    let existing = fs::read_to_string(&path).unwrap_or_default();
    let replacements = [
        ("server-port", server.port.to_string()),
        ("max-players", server.max_players.to_string()),
        ("motd", server.motd.replace('\r', " ").replace('\n', " ")),
        ("online-mode", server.online_mode.to_string()),
    ];
    let mut found = HashMap::new();
    let mut lines = Vec::new();
    for line in existing.lines() {
        if let Some((key, _)) = line.split_once('=') {
            if let Some((_, value)) = replacements.iter().find(|(k, _)| *k == key) {
                lines.push(format!("{key}={value}"));
                found.insert(key.to_string(), true);
                continue;
            }
        }
        lines.push(line.to_string());
    }
    for (key, value) in replacements {
        if !found.contains_key(key) { lines.push(format!("{key}={value}")); }
    }
    fs::write(path, format!("{}\n", lines.join("\n"))).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn set_server_eula(app: AppHandle, server_id: String, accepted: bool) -> Result<(), String> {
    let mut servers = read_servers(&app)?;
    let server = servers.iter_mut().find(|s| s.id == server_id).ok_or("Server not found.")?;
    server.eula_accepted = accepted;
    write_servers(&app, &servers)?;
    let dir = server_directory(&app, &server_id)?;
    fs::write(dir.join("eula.txt"), format!("# By setting eula=true you confirm acceptance of https://aka.ms/MinecraftEULA\neula={}\n", accepted))
        .map_err(|e| e.to_string())
}

fn java_command(server: &ServerInstance) -> Command {
    let executable = server.java_path.as_deref().filter(|p| !p.trim().is_empty()).unwrap_or("java");
    let mut command = Command::new(executable);
    command.arg(format!("-Xms{}M", (server.ram_mb / 2).max(512)))
        .arg(format!("-Xmx{}M", server.ram_mb))
        .arg(format!("-XX:ActiveProcessorCount={}", server.cpu_threads))
        .arg("-Dfile.encoding=UTF-8");
    command
}

fn install_vanilla_server(app: &AppHandle, server: &ServerInstance, dir: &Path) -> Result<(), String> {
    let client = http_client()?;
    emit_log(app, &server.id, &server.name, "system", &format!("Resolving official Minecraft {} server files…", server.minecraft_version));
    let manifest = get_json(&client, MOJANG_MANIFEST)?;
    let entry = manifest.get("versions").and_then(Value::as_array)
        .and_then(|items| items.iter().find(|v| v.get("id").and_then(Value::as_str) == Some(server.minecraft_version.as_str())))
        .ok_or_else(|| format!("Minecraft {} is not listed in Mojang's version manifest.", server.minecraft_version))?;
    let meta_url = entry.get("url").and_then(Value::as_str).ok_or("Mojang version metadata URL is missing.")?;
    let metadata = get_json(&client, meta_url)?;
    let download = metadata.pointer("/downloads/server").ok_or("Mojang does not publish a dedicated server JAR for this version.")?;
    let url = download.get("url").and_then(Value::as_str).ok_or("Server JAR download URL is missing.")?;
    let expected = download.get("sha1").and_then(Value::as_str).unwrap_or("");
    emit_log(app, &server.id, &server.name, "system", "Downloading the official server JAR…");
    let bytes = download_https(&client, url, 250 * 1024 * 1024)?;
    if !expected.is_empty() && !sha1_hex(&bytes).eq_ignore_ascii_case(expected) { return Err("Minecraft server JAR failed SHA-1 verification.".into()); }
    fs::write(dir.join("server.jar.part"), &bytes).map_err(|e| e.to_string())?;
    fs::rename(dir.join("server.jar.part"), dir.join("server.jar")).map_err(|e| e.to_string())?;
    emit_log(app, &server.id, &server.name, "system", "Official server JAR installed and verified.");
    Ok(())
}

fn install_fabric_server(app: &AppHandle, server: &ServerInstance, dir: &Path) -> Result<(), String> {
    let client = http_client()?;
    emit_log(app, &server.id, &server.name, "system", "Resolving Fabric installer and loader versions…");
    let installers = get_json(&client, "https://meta.fabricmc.net/v2/versions/installer")?;
    let installer_version = installers.as_array().and_then(|a| a.iter().find(|v| v.get("stable").and_then(Value::as_bool) == Some(true)).or_else(|| a.first()))
        .and_then(|v| v.get("version")).and_then(Value::as_str).ok_or("Fabric installer metadata is unavailable.")?.to_string();
    let loader_url = format!("https://meta.fabricmc.net/v2/versions/loader/{}", server.minecraft_version);
    let loaders = get_json(&client, &loader_url)?;
    let loader_version = loaders.as_array().and_then(|a| a.iter().find(|v| v.pointer("/loader/stable").and_then(Value::as_bool) == Some(true)).or_else(|| a.first()))
        .and_then(|v| v.pointer("/loader/version")).and_then(Value::as_str).ok_or("No Fabric server loader is published for this Minecraft version.")?.to_string();
    let installer_url = format!("https://maven.fabricmc.net/net/fabricmc/fabric-installer/{installer_version}/fabric-installer-{installer_version}.jar");
    let installer_bytes = download_https(&client, &installer_url, 32 * 1024 * 1024)?;
    let installer_path = dir.join("fabric-installer.jar");
    fs::write(&installer_path, installer_bytes).map_err(|e| e.to_string())?;
    emit_log(app, &server.id, &server.name, "system", &format!("Installing Fabric server loader {loader_version}…"));
    let mut command = java_command(server);
    command.arg("-jar").arg(&installer_path).arg("server")
        .arg("-mcversion").arg(&server.minecraft_version)
        .arg("-loader").arg(&loader_version)
        .arg("-dir").arg(dir)
        .arg("-downloadMinecraft")
        .current_dir(dir).stdout(Stdio::piped()).stderr(Stdio::piped());
    hide_console(&mut command);
    let output = command.output().map_err(|e| format!("Could not run the Fabric installer: {e}"))?;
    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    for line in stdout.lines().chain(stderr.lines()) { emit_log(app, &server.id, &server.name, "stdout", line); }
    if !output.status.success() { return Err(format!("Fabric server installation failed (exit {}). Check the server console for details.", output.status.code().unwrap_or(-1))); }
    if !dir.join("fabric-server-launch.jar").exists() { return Err("Fabric installer finished but fabric-server-launch.jar was not created.".into()); }
    let _ = fs::remove_file(installer_path);
    emit_log(app, &server.id, &server.name, "system", "Fabric server installed successfully.");
    Ok(())
}

fn install_server_inner(app: &AppHandle, server: &ServerInstance, reinstall: bool) -> Result<(), String> {
    if server_processes().lock().map_err(|_| "Server process list unavailable.")?.contains_key(&server.id) {
        return Err("Stop this server before installing or reinstalling its software.".into());
    }
    let dir = server_directory(app, &server.id)?;
    ensure_server_folders(&dir)?;
    if reinstall {
        let mut records = read_servers(app)?;
        if let Some(record) = records.iter_mut().find(|s| s.id == server.id) { record.installed = false; }
        write_servers(app, &records)?;
        for file in ["server.jar", "fabric-server-launch.jar", "fabric-server-launcher.properties", "fabric-installer.jar"] {
            let _ = fs::remove_file(dir.join(file));
        }
        let libraries = dir.join("libraries");
        if libraries.exists() { fs::remove_dir_all(libraries).map_err(|e| e.to_string())?; }
        emit_log(app, &server.id, &server.name, "system", "Reinstalling server software. Worlds, mods and server settings are being preserved.");
    }
    match server.software.as_str() {
        "Vanilla" => install_vanilla_server(app, server, &dir)?,
        "Fabric" => install_fabric_server(app, server, &dir)?,
        _ => return Err("Unsupported server software. Choose Vanilla or Fabric.".into()),
    }
    if !dir.join("server.properties").exists() { fs::write(dir.join("server.properties"), default_properties(server)).map_err(|e| e.to_string())?; }
    let mut servers = read_servers(app)?;
    if let Some(record) = servers.iter_mut().find(|s| s.id == server.id) { record.installed = true; }
    write_servers(app, &servers)?;
    Ok(())
}

#[tauri::command]
pub async fn install_server(app: AppHandle, server_id: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let server = find_server(&app, &server_id)?;
        install_server_inner(&app, &server, false)?;
        Ok(format!("{} server software installed.", server.name))
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn reinstall_server(app: AppHandle, server_id: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let server = find_server(&app, &server_id)?;
        install_server_inner(&app, &server, true)?;
        Ok(format!("{} server software reinstalled. Worlds and settings were preserved.", server.name))
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub fn start_server(app: AppHandle, server_id: String) -> Result<String, String> {
    let server = find_server(&app, &server_id)?;
    if !server.installed { return Err("Install this server before starting it.".into()); }
    if !server.eula_accepted { return Err("Review and accept the Minecraft EULA in this server's Settings before starting it.".into()); }
    if server_processes().lock().map_err(|_| "Server process list unavailable.")?.contains_key(&server_id) { return Err("This server is already running.".into()); }
    let dir = server_directory(&app, &server_id)?;
    let port_probe = TcpListener::bind(("0.0.0.0", server.port)).map_err(|e| format!("Port {} is not available: {e}. Stop the other service using it or choose another port in server Settings.", server.port))?;
    drop(port_probe);
    let jar = if server.software == "Fabric" { dir.join("fabric-server-launch.jar") } else { dir.join("server.jar") };
    if !jar.exists() { return Err("Server JAR is missing. Reinstall server software.".into()); }
    let mut command = java_command(&server);
    command.arg("-jar").arg(jar.file_name().ok_or("Server JAR name is invalid.")?).arg("nogui")
        .current_dir(&dir).stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped());
    hide_console(&mut command);
    let mut child = command.spawn().map_err(|e| format!("Could not start the server process: {e}. Check the Java path in Settings."))?;
    let pid = child.id();
    let stdout = child.stdout.take().ok_or("Could not capture server output.")?;
    let stderr = child.stderr.take().ok_or("Could not capture server errors.")?;
    let stdin = child.stdin.take().ok_or("Could not connect to the server console.")?;
    let (tx, rx) = mpsc::channel();
    server_processes().lock().map_err(|_| "Server process list unavailable.")?.insert(server_id.clone(), tx);
    let server_name = server.name.clone();
    start_output_reader(app.clone(), server_id.clone(), server_name.clone(), "stdout", stdout, dir.join("logs").join("latest.log"));
    start_output_reader(app.clone(), server_id.clone(), server_name.clone(), "stderr", stderr, dir.join("logs").join("latest.log"));
    emit_log(&app, &server_id, &server_name, "system", &format!("Server process started (PID {pid}) using {} MB RAM and {} CPU threads.", server.ram_mb, server.cpu_threads));
    let monitor_app = app.clone();
    let monitor_id = server_id.clone();
    thread::spawn(move || monitor_child(child, stdin, rx, monitor_app, monitor_id, server_name));
    Ok(format!("{} server started (PID {pid}).", server.name))
}

fn monitor_child(mut child: Child, mut stdin: std::process::ChildStdin, rx: mpsc::Receiver<ProcessMessage>, app: AppHandle, id: String, name: String) {
    loop {
        match rx.recv_timeout(Duration::from_millis(250)) {
            Ok(ProcessMessage::Input(line)) => {
                if let Err(e) = writeln!(stdin, "{line}") { emit_log(&app, &id, &name, "error", &format!("Could not send server command: {e}")); }
                let _ = stdin.flush();
            }
            Ok(ProcessMessage::Kill) => {
                let _ = child.kill();
                let _ = child.wait();
                break;
            }
            Err(mpsc::RecvTimeoutError::Disconnected) => { let _ = child.kill(); let _ = child.wait(); break; }
            Err(mpsc::RecvTimeoutError::Timeout) => {}
        }
        match child.try_wait() {
            Ok(Some(status)) => {
                emit_log(&app, &id, &name, if status.success() { "system" } else { "error" }, &format!("Server process exited with code {}.", status.code().map(|c| c.to_string()).unwrap_or_else(|| "unknown".into())));
                break;
            }
            Ok(None) => {}
            Err(e) => { emit_log(&app, &id, &name, "error", &format!("Could not monitor server process: {e}")); break; }
        }
    }
    if let Ok(mut processes) = server_processes().lock() { processes.remove(&id); }
}

#[tauri::command]
pub fn send_server_command(server_id: String, command: String) -> Result<(), String> {
    let command = command.trim();
    if command.is_empty() || command.len() > 512 || command.chars().any(|c| c.is_control()) { return Err("Enter a server command up to 512 characters on one line.".into()); }
    let processes = server_processes().lock().map_err(|_| "Server process list unavailable.")?;
    let sender = processes.get(&server_id).ok_or("This server is not running.")?;
    sender.send(ProcessMessage::Input(command.to_string())).map_err(|_| "Server console is not available.".into())
}

#[tauri::command]
pub fn stop_server(server_id: String) -> Result<(), String> {
    let processes = server_processes().lock().map_err(|_| "Server process list unavailable.")?;
    let sender = processes.get(&server_id).ok_or("This server is not running.")?;
    sender.send(ProcessMessage::Input("stop".into())).map_err(|_| "Could not send stop command.".into())
}

#[tauri::command]
pub fn kill_server(server_id: String) -> Result<(), String> {
    let processes = server_processes().lock().map_err(|_| "Server process list unavailable.")?;
    let sender = processes.get(&server_id).ok_or("This server is not running.")?;
    sender.send(ProcessMessage::Kill).map_err(|_| "Could not terminate server process.".into())
}

#[tauri::command]
pub fn delete_server(app: AppHandle, server_id: String) -> Result<(), String> {
    if server_processes().lock().map_err(|_| "Server process list unavailable.")?.contains_key(&server_id) { return Err("Stop the server before deleting it.".into()); }
    let mut servers = read_servers(&app)?;
    if !servers.iter().any(|s| s.id == server_id) { return Err("Server not found.".into()); }
    let dir = server_directory(&app, &server_id)?;
    fs::remove_dir_all(dir).map_err(|e| format!("Could not delete server files: {e}"))?;
    servers.retain(|s| s.id != server_id);
    write_servers(&app, &servers)
}

fn category_dir(category: &str) -> Result<&'static str, String> {
    match category {
        "root" => Ok(""), "mods" => Ok("mods"), "plugins" => Ok("plugins"), "config" => Ok("config"),
        "world" => Ok("world"), "logs" => Ok("logs"), "backups" => Ok("backups"),
        _ => Err("Unsupported server folder.".into()),
    }
}

#[tauri::command]
pub fn get_server_files(app: AppHandle, server_id: String, category: String) -> Result<Vec<ServerFile>, String> {
    let child = category_dir(&category)?;
    let base = server_directory(&app, &server_id)?;
    let dir = if child.is_empty() { base } else { base.join(child) };
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let mut results = Vec::new();
    for entry in fs::read_dir(dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let metadata = entry.metadata().map_err(|e| e.to_string())?;
        results.push(ServerFile {
            name: entry.file_name().to_string_lossy().to_string(), size: metadata.len(), is_directory: metadata.is_dir()
        });
    }
    results.sort_by(|a, b| b.is_directory.cmp(&a.is_directory).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
    Ok(results)
}

#[tauri::command]
pub fn remove_server_file(app: AppHandle, server_id: String, category: String, file_name: String) -> Result<(), String> {
    ensure_server_stopped(&server_id)?;
    let child = category_dir(&category)?;
    let leaf = safe_direct_file_name(&file_name)?;
    if category == "root" && ["server.jar", "fabric-server-launch.jar", "eula.txt"].contains(&leaf) {
        return Err("Core server files cannot be removed here. Use Reinstall server software instead.".into());
    }
    let base = server_directory(&app, &server_id)?;
    let dir = if child.is_empty() { base } else { base.join(child) };
    let path = dir.join(leaf);
    if !path.exists() { return Err("File was not found.".into()); }
    if path.is_dir() { fs::remove_dir_all(path).map_err(|e| e.to_string()) } else { fs::remove_file(path).map_err(|e| e.to_string()) }
}

#[tauri::command]
pub fn toggle_server_mod(app: AppHandle, server_id: String, file_name: String, enabled: bool) -> Result<(), String> {
    ensure_server_stopped(&server_id)?;
    let leaf = safe_direct_file_name(&file_name)?;
    let dir = server_directory(&app, &server_id)?.join("mods");
    let current = dir.join(leaf);
    if !current.is_file() { return Err("Mod JAR was not found.".into()); }
    let target_name = if enabled {
        leaf.strip_suffix(".disabled").ok_or("Mod is already enabled.")?.to_string()
    } else {
        if !leaf.to_ascii_lowercase().ends_with(".jar") { return Err("Only JAR files can be disabled.".into()); }
        format!("{leaf}.disabled")
    };
    let target = dir.join(target_name);
    if target.exists() { return Err("A mod file with that name already exists.".into()); }
    fs::rename(current, target).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn read_server_text_file(app: AppHandle, server_id: String, file_name: String) -> Result<String, String> {
    let leaf = safe_direct_file_name(&file_name)?;
    if !["server.properties", "whitelist.json", "ops.json", "banned-players.json", "banned-ips.json"].contains(&leaf) {
        return Err("This server file is not editable in VOID CLIENT.".into());
    }
    let path = server_directory(&app, &server_id)?.join(leaf);
    let meta = fs::metadata(&path).map_err(|e| e.to_string())?;
    if meta.len() > 2 * 1024 * 1024 { return Err("File is larger than the 2 MB editor limit.".into()); }
    fs::read_to_string(path).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn write_server_text_file(app: AppHandle, server_id: String, file_name: String, contents: String) -> Result<(), String> {
    ensure_server_stopped(&server_id)?;
    let leaf = safe_direct_file_name(&file_name)?;
    if !["server.properties", "whitelist.json", "ops.json", "banned-players.json", "banned-ips.json"].contains(&leaf) { return Err("This server file is not editable in VOID CLIENT.".into()); }
    if contents.len() > 2 * 1024 * 1024 { return Err("The editor has a 2 MB save limit.".into()); }
    fs::write(server_directory(&app, &server_id)?.join(leaf), contents).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn open_server_folder(app: AppHandle, server_id: String) -> Result<(), String> {
    let dir = server_directory(&app, &server_id)?;
    #[cfg(target_os = "windows")]
    let result = Command::new("explorer").arg(&dir).spawn();
    #[cfg(target_os = "macos")]
    let result = Command::new("open").arg(&dir).spawn();
    #[cfg(all(unix, not(target_os = "macos")))]
    let result = Command::new("xdg-open").arg(&dir).spawn();
    result.map(|_| ()).map_err(|e| format!("Could not open server folder: {e}"))
}

fn fetch_modrinth_project_version(client: &Client, project_id: &str, mc_version: &str) -> Result<Value, String> {
    if project_id.is_empty() || project_id.len() > 64 || !project_id.chars().all(|c| c.is_ascii_alphanumeric()) { return Err("Invalid Modrinth project ID.".into()); }
    let game_versions = serde_json::to_string(&vec![mc_version]).map_err(|e| e.to_string())?;
    let loaders = serde_json::to_string(&vec!["fabric"]).map_err(|e| e.to_string())?;
    let response = client.get(format!("https://api.modrinth.com/v2/project/{project_id}/version"))
        .query(&[("game_versions", game_versions.as_str()), ("loaders", loaders.as_str())])
        .send().map_err(|e| format!("Could not contact Modrinth: {e}"))?;
    let status = response.status();
    let body: Value = response.json().map_err(|e| e.to_string())?;
    if !status.is_success() { return Err(body.get("description").and_then(Value::as_str).unwrap_or("Modrinth did not return a compatible server mod version.").to_string()); }
    body.as_array().and_then(|a| a.first()).cloned().ok_or_else(|| "No Fabric mod version is compatible with this server.".into())
}

fn install_server_mod_recursive(
    client: &Client,
    server_dir: &Path,
    mc_version: &str,
    project_id: &str,
    visiting: &mut Vec<String>,
    installed: &mut Vec<String>,
    skipped: &mut Vec<String>,
) -> Result<(), String> {
    if visiting.contains(&project_id.to_string()) { return Ok(()); }
    if visiting.len() > 24 { return Err("Mod dependency graph is too large.".into()); }
    visiting.push(project_id.to_string());
    let version = fetch_modrinth_project_version(client, project_id, mc_version)?;
    let dependencies = version.get("dependencies").and_then(Value::as_array).cloned().unwrap_or_default();
    for dep in dependencies.iter().filter(|d| d.get("dependency_type").and_then(Value::as_str) == Some("required")) {
        if let Some(dep_project) = dep.get("project_id").and_then(Value::as_str) {
            install_server_mod_recursive(client, server_dir, mc_version, dep_project, visiting, installed, skipped)?;
        }
    }
    let files = version.get("files").and_then(Value::as_array).ok_or("Modrinth version has no files.")?;
    let file = files.iter().find(|f| f.get("primary").and_then(Value::as_bool) == Some(true)).or_else(|| files.first()).ok_or("Modrinth version has no downloadable file.")?;
    let filename = file.get("filename").and_then(Value::as_str).ok_or("Modrinth file name is missing.")?;
    let leaf = safe_direct_file_name(filename)?.to_string();
    let url = file.get("url").and_then(Value::as_str).ok_or("Modrinth download URL is missing.")?;
    let parsed = reqwest::Url::parse(url).map_err(|_| "Modrinth returned an invalid download URL.".to_string())?;
    if parsed.scheme() != "https" || parsed.host_str() != Some("cdn.modrinth.com") { return Err("Modrinth returned a download outside its official CDN.".into()); }
    let response = client.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
    if response.url().scheme() != "https" || response.url().host_str() != Some("cdn.modrinth.com") { return Err("Mod download redirected outside Modrinth's CDN.".into()); }
    if response.content_length().unwrap_or(0) > 100 * 1024 * 1024 { return Err("Mod file exceeds the 100 MB safety limit.".into()); }
    let mut bytes = Vec::new();
    response.take(100 * 1024 * 1024 + 1).read_to_end(&mut bytes).map_err(|e| e.to_string())?;
    if bytes.len() > 100 * 1024 * 1024 { return Err("Mod file exceeds the 100 MB safety limit.".into()); }
    if let Some(expected) = file.pointer("/hashes/sha512").and_then(Value::as_str) {
        let mut hasher = Sha512::new(); hasher.update(&bytes);
        if hex::encode(hasher.finalize()) != expected { return Err(format!("SHA-512 verification failed for {leaf}.")); }
    }
    let mods_dir = server_dir.join("mods");
    fs::create_dir_all(&mods_dir).map_err(|e| e.to_string())?;
    let target = mods_dir.join(&leaf);
    if target.exists() { skipped.push(leaf); }
    else { fs::write(target, bytes).map_err(|e| e.to_string())?; installed.push(leaf); }
    Ok(())
}

#[tauri::command]
pub async fn search_server_mods(query: String, server_id: String, app: AppHandle) -> Result<Value, String> {
    let server = find_server(&app, &server_id)?;
    if server.software != "Fabric" { return Err("Modrinth server mods require a Fabric server. Switch this server to Fabric and reinstall its software first.".into()); }
    tauri::async_runtime::spawn_blocking(move || {
        let client = http_client()?;
        let facets = serde_json::to_string(&vec![vec!["project_type:mod".to_string()], vec![format!("versions:{}", server.minecraft_version)], vec!["categories:fabric".to_string()]])
            .map_err(|e| e.to_string())?;
        let response = client.get("https://api.modrinth.com/v2/search").query(&[
            ("query", query.as_str()), ("facets", facets.as_str()), ("index", "downloads"), ("limit", "20")
        ]).send().map_err(|e| format!("Could not search Modrinth: {e}"))?;
        let status = response.status(); let value: Value = response.json().map_err(|e| e.to_string())?;
        if !status.is_success() { return Err(value.get("error").and_then(Value::as_str).unwrap_or("Modrinth search failed.").to_string()); }
        Ok(value)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn install_server_mod(app: AppHandle, server_id: String, project_id: String) -> Result<ServerModInstallResult, String> {
    ensure_server_stopped(&server_id)?;
    let server = find_server(&app, &server_id)?;
    if server.software != "Fabric" { return Err("Install a Fabric server before adding Fabric mods.".into()); }
    tauri::async_runtime::spawn_blocking(move || {
        ensure_server_stopped(&server_id)?;
        let client = http_client()?;
        let dir = server_directory(&app, &server_id)?;
        let mut visiting = Vec::new(); let mut installed = Vec::new(); let mut skipped = Vec::new();
        install_server_mod_recursive(&client, &dir, &server.minecraft_version, &project_id, &mut visiting, &mut installed, &mut skipped)?;
        Ok(ServerModInstallResult { installed, skipped })
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn install_playit_with_winget(app: AppHandle) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        emit_log(&app, "playit", "Playit.gg", "system", "Installing the official Playit Windows package…");
        let mut command = Command::new("winget");
        command.args(["install", "--id", "DevelopedMethods.playit", "-e", "--accept-source-agreements", "--accept-package-agreements"])
            .stdout(Stdio::piped()).stderr(Stdio::piped());
        hide_console(&mut command);
        let output = command.output().map_err(|e| format!("Could not start winget: {e}. Install Playit from https://playit.gg/download/windows instead."))?;
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        for line in stdout.lines().chain(stderr.lines()) { emit_log(&app, "playit", "Playit.gg", "stdout", line); }
        if !output.status.success() {
            return Err(format!("Playit installation failed (exit {}). You can install it manually from https://playit.gg/download/windows.", output.status.code().unwrap_or(-1)));
        }
        emit_log(&app, "playit", "Playit.gg", "system", "Playit installed. The official Windows installer registers the playitd service and tray application.");
        Ok("Playit installed. Its Windows service (playitd) may already be running. Claim/link the agent from the Playit tray app, then create a Minecraft Java tunnel in the Playit dashboard.".into())
    }).await.map_err(|e| e.to_string())?
}

#[cfg(target_os = "windows")]
fn query_playit_service() -> Result<bool, String> {
    let mut command = Command::new("sc.exe");
    command.args(["query", "playitd"]).stdout(Stdio::piped()).stderr(Stdio::piped());
    hide_console(&mut command);
    let output = command.output().map_err(|e| format!("Could not query the Playit Windows service: {e}"))?;
    let text = format!("{}\n{}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr));
    if text.contains("1060") || text.to_ascii_lowercase().contains("does not exist as an installed service") {
        return Err("Playit service is not installed. Use Install Playit agent first.".into());
    }
    Ok(text.to_ascii_uppercase().contains("RUNNING"))
}

#[cfg(not(target_os = "windows"))]
fn query_playit_service() -> Result<bool, String> {
    Err("VOID CLIENT's Playit service controls are currently available on Windows only.".into())
}

fn emit_recent_playit_logs(app: &AppHandle) {
    let root = std::env::var_os("ProgramData").map(PathBuf::from).unwrap_or_else(|| PathBuf::from(r"C:\ProgramData"));
    let logs_dir = root.join("playit_gg").join("logs");
    let Ok(entries) = fs::read_dir(logs_dir) else { return; };
    let mut candidates: Vec<(SystemTime, PathBuf)> = entries.flatten().filter_map(|entry| {
        let path = entry.path();
        if !path.is_file() { return None; }
        let modified = entry.metadata().ok()?.modified().ok()?;
        Some((modified, path))
    }).collect();
    candidates.sort_by(|a, b| b.0.cmp(&a.0));
    let Some((_, path)) = candidates.first() else { return; };
    let Ok(file) = fs::File::open(path) else { return; };
    let lines: VecDeque<String> = BufReader::new(file).take(5 * 1024 * 1024).lines().filter_map(Result::ok).collect();
    for line in lines.into_iter().rev().take(80).collect::<Vec<_>>().into_iter().rev() {
        emit_log(app, "playit", "Playit.gg", "stdout", &line);
    }
}

#[tauri::command]
pub fn start_playit_agent(app: AppHandle, server_id: String) -> Result<String, String> {
    let server = find_server(&app, &server_id)?;
    #[cfg(target_os = "windows")]
    {
        if !query_playit_service()? {
            let mut command = Command::new("sc.exe");
            command.args(["start", "playitd"]).stdout(Stdio::piped()).stderr(Stdio::piped());
            hide_console(&mut command);
            let output = command.output().map_err(|e| format!("Could not start the Playit service: {e}"))?;
            if !output.status.success() && !query_playit_service()? {
                let detail = format!("{} {}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr));
                return Err(format!("Could not start Playit service. Windows said: {}. You can start it from the Playit tray app or Windows Services.", detail.trim()));
            }
            let mut running = false;
            for _ in 0..20 {
                thread::sleep(Duration::from_millis(350));
                if query_playit_service().unwrap_or(false) { running = true; break; }
            }
            if !running { return Err("Playit service did not enter RUNNING state. Open the Playit tray app and check its status/logs.".into()); }
        }
        emit_log(&app, &server.id, &server.name, "system", &format!("Playit Windows service is running. This server uses local TCP port {}.", server.port));
        emit_recent_playit_logs(&app);
        Ok(format!("Playit service is running. In the Playit dashboard, create a Minecraft Java tunnel for local TCP port {}. The official installer manages the service and tray app separately from VOID CLIENT.", server.port))
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = server;
        Err("Playit service controls are currently available on Windows only.".into())
    }
}

#[tauri::command]
pub fn stop_playit_agent(app: AppHandle) -> Result<String, String> {
    #[cfg(target_os = "windows")]
    {
        if !query_playit_service()? {
            emit_log(&app, "playit", "Playit.gg", "system", "Playit service is already stopped.");
            return Ok("Playit service is already stopped.".into());
        }
        let mut command = Command::new("sc.exe");
        command.args(["stop", "playitd"]).stdout(Stdio::piped()).stderr(Stdio::piped());
        hide_console(&mut command);
        let output = command.output().map_err(|e| format!("Could not stop the Playit service: {e}"))?;
        if !output.status.success() && query_playit_service()? {
            let detail = format!("{} {}", String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr));
            return Err(format!("Windows could not stop Playit: {}", detail.trim()));
        }
        for _ in 0..20 {
            thread::sleep(Duration::from_millis(250));
            if !query_playit_service().unwrap_or(false) { break; }
        }
        emit_log(&app, "playit", "Playit.gg", "system", "Playit Windows service stop was requested.");
        Ok("Playit service stopped. Tunnels are offline until you start the service again.".into())
    }
    #[cfg(not(target_os = "windows"))]
    {
        let _ = app;
        Err("Playit service controls are currently available on Windows only.".into())
    }
}

#[tauri::command]
pub fn is_playit_running() -> bool {
    query_playit_service().unwrap_or(false)
}
