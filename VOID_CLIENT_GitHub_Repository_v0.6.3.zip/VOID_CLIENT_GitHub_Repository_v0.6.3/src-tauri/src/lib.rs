use serde::{Deserialize, Serialize};
use std::{
    fs,
    io,
    path::{Path, PathBuf},
    process::Command,
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Manager};
use sha2::{Digest, Sha512};
use md5::Md5;

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Profile {
    pub id: String,
    pub name: String,
    pub minecraft_version: String,
    pub loader: String,
    pub ram_gb: u8,
    pub created_at: u64,
    pub last_played: Option<u64>,
    pub java_path: Option<String>,
    pub jvm_args: String,
    pub game_width: u16,
    pub game_height: u16,
    pub fullscreen: bool,
    #[serde(default)]
    pub installed_version: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LauncherSettings {
    pub accent: String,
    pub theme: String,
    pub game_directory: Option<String>,
    // Public OAuth application ID. This is not a secret; the desktop app cannot
    // safely store a client secret. Players can paste their app registration ID here.
    #[serde(default)]
    pub microsoft_client_id: String,
    #[serde(default)]
    pub selected_account_id: Option<String>,
    pub max_downloads: u8,
}

impl Default for LauncherSettings {
    fn default() -> Self {
        Self {
            accent: "violet".into(),
            theme: "dark".into(),
            game_directory: None,
            microsoft_client_id: String::new(),
            selected_account_id: None,
            max_downloads: 8,
        }
    }
}

/// Resolve the public OAuth client ID from launcher settings first, then from an
/// optional publisher build-time value. A client ID is public configuration, not a secret.
fn valid_microsoft_client_id(value: &str) -> bool {
    let parts: Vec<&str> = value.split('-').collect();
    parts.len() == 5
        && [8, 4, 4, 4, 12].iter().zip(parts.iter()).all(|(expected, part)| {
            part.len() == *expected && part.chars().all(|c| c.is_ascii_hexdigit())
        })
}

pub(crate) fn microsoft_client_id(app: &AppHandle) -> Result<String, String> {
    let path = root_dir(app)?.join("settings.json");
    if path.exists() {
        let bytes = fs::read(&path).map_err(|e| format!("Could not read launcher settings: {e}"))?;
        let settings: serde_json::Value = serde_json::from_slice(&bytes)
            .map_err(|e| format!("Could not parse launcher settings: {e}"))?;
        if let Some(value) = settings.get("microsoftClientId").and_then(|v| v.as_str()) {
            let value = value.trim();
            if !value.is_empty() {
                if !valid_microsoft_client_id(value) {
                    return Err("The Microsoft Application (client) ID must be a GUID. Copy the Application (client) ID from your Entra app registration, not its Object ID or tenant ID.".into());
                }
                return Ok(value.to_string());
            }
        }
    }
    let built_in = option_env!("VOID_CLIENT_MICROSOFT_CLIENT_ID").unwrap_or("").trim();
    if !built_in.is_empty() {
        if !valid_microsoft_client_id(built_in) {
            return Err("The built-in Microsoft Application (client) ID is not a valid GUID. Check VOID_CLIENT_MICROSOFT_CLIENT_ID in your build environment.".into());
        }
        return Ok(built_in.to_string());
    }
    Err("Microsoft sign-in needs a public Application (client) ID from an Entra app registered for personal Microsoft accounts with public-client/device-code flow enabled. Paste its Application (client) ID in Accounts; never use a client secret.".into())
}

fn root_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let base = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&base).map_err(|e| e.to_string())?;
    Ok(base)
}

fn profiles_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let dir = root_dir(app)?.join("profiles");
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir)
}

fn profiles_file(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(root_dir(app)?.join("profiles.json"))
}

fn read_profiles(app: &AppHandle) -> Result<Vec<Profile>, String> {
    let path = profiles_file(app)?;
    if !path.exists() {
        return Ok(Vec::new());
    }
    let bytes = fs::read(path).map_err(|e| e.to_string())?;
    serde_json::from_slice(&bytes).map_err(|e| format!("Could not read profile database: {e}"))
}

fn write_profiles(app: &AppHandle, profiles: &[Profile]) -> Result<(), String> {
    let path = profiles_file(app)?;
    let bytes = serde_json::to_vec_pretty(profiles).map_err(|e| e.to_string())?;
    fs::write(&path, bytes).map_err(|e| e.to_string())
}

fn now_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64
}

fn folder_name(name: &str, id: &str) -> String {
    let clean: String = name
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else if c.is_whitespace() { '-' } else { '_' })
        .collect();
    let clean = clean.trim_matches('-').to_lowercase();
    let short = if clean.is_empty() { "profile" } else { clean.as_str() };
    format!("{}-{}", short.chars().take(32).collect::<String>(), id)
}

fn create_profile_folders(path: &Path) -> io::Result<()> {
    for child in ["mods", "config", "resourcepacks", "shaderpacks", "saves", "logs", "screenshots", "versions", "crash-reports"] {
        fs::create_dir_all(path.join(child))?;
    }
    Ok(())
}

#[tauri::command]
fn get_profiles(app: AppHandle) -> Result<Vec<Profile>, String> {
    read_profiles(&app)
}

#[tauri::command]
fn create_profile(
    app: AppHandle,
    name: String,
    minecraft_version: String,
    loader: String,
    ram_gb: u8,
) -> Result<Profile, String> {
    let name = name.trim();
    if name.is_empty() || name.len() > 48 {
        return Err("Profile name must contain 1–48 characters.".into());
    }
    if !["Vanilla", "Fabric", "Forge", "NeoForge", "Quilt"].contains(&loader.as_str()) {
        return Err("Unsupported mod loader.".into());
    }
    if !(2..=32).contains(&ram_gb) {
        return Err("Memory allocation must be between 2 and 32 GB.".into());
    }
    let mut profiles = read_profiles(&app)?;
    let id = format!("p{}", now_ms());
    let profile = Profile {
        id: id.clone(),
        name: name.to_string(),
        minecraft_version: minecraft_version.trim().to_string(),
        loader,
        ram_gb,
        created_at: now_ms(),
        last_played: None,
        java_path: None,
        jvm_args: String::new(),
        game_width: 1280,
        game_height: 720,
        fullscreen: false,
        installed_version: None,
    };
    let dir = profiles_dir(&app)?.join(folder_name(name, &id));
    create_profile_folders(&dir).map_err(|e| format!("Could not create profile folders: {e}"))?;
    fs::write(dir.join("profile.json"), serde_json::to_vec_pretty(&profile).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    profiles.push(profile.clone());
    if let Err(e) = write_profiles(&app, &profiles) {
        let _ = fs::remove_dir_all(&dir);
        return Err(e);
    }
    Ok(profile)
}

#[tauri::command]
fn update_profile(app: AppHandle, profile: Profile) -> Result<Profile, String> {
    if profile.name.trim().is_empty() || profile.name.len() > 48 {
        return Err("Profile name must contain 1–48 characters.".into());
    }
    if !(2..=32).contains(&profile.ram_gb) {
        return Err("Memory allocation must be between 2 and 32 GB.".into());
    }
    let mut profiles = read_profiles(&app)?;
    let Some(index) = profiles.iter().position(|p| p.id == profile.id) else {
        return Err("Profile not found.".into());
    };
    let previous = profiles[index].clone();
    let mut updated = profile;
    if previous.minecraft_version != updated.minecraft_version || previous.loader != updated.loader {
        // A different game version or loader is a different installation target.
        // Do not let PLAY accidentally launch the previous installation.
        updated.installed_version = None;
    }
    profiles[index] = updated.clone();
    write_profiles(&app, &profiles)?;
    let path = locate_profile_dir(&app, &updated.id)?;
    fs::write(path.join("profile.json"), serde_json::to_vec_pretty(&updated).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    Ok(updated)
}

fn locate_profile_dir(app: &AppHandle, id: &str) -> Result<PathBuf, String> {
    let profiles = profiles_dir(app)?;
    let entries = fs::read_dir(&profiles).map_err(|e| e.to_string())?;
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() && path.file_name().and_then(|n| n.to_str()).map(|n| n.ends_with(&format!("-{id}"))).unwrap_or(false) {
            return Ok(path);
        }
    }
    Err("Profile folder not found.".into())
}

fn copy_dir(source: &Path, destination: &Path) -> io::Result<()> {
    fs::create_dir_all(destination)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let from = entry.path();
        let to = destination.join(entry.file_name());
        if from.is_dir() {
            copy_dir(&from, &to)?;
        } else {
            fs::copy(&from, &to)?;
        }
    }
    Ok(())
}

#[tauri::command]
fn duplicate_profile(app: AppHandle, profile_id: String) -> Result<Profile, String> {
    let mut profiles = read_profiles(&app)?;
    let original = profiles.iter().find(|p| p.id == profile_id).cloned().ok_or("Profile not found.")?;
    let id = format!("p{}", now_ms());
    let mut cloned = original.clone();
    cloned.id = id.clone();
    cloned.name = format!("{} Copy", original.name);
    cloned.created_at = now_ms();
    cloned.last_played = None;
    let source = locate_profile_dir(&app, &profile_id)?;
    let destination = profiles_dir(&app)?.join(folder_name(&cloned.name, &id));
    copy_dir(&source, &destination).map_err(|e| format!("Could not duplicate profile: {e}"))?;
    fs::write(destination.join("profile.json"), serde_json::to_vec_pretty(&cloned).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    profiles.push(cloned.clone());
    if let Err(e) = write_profiles(&app, &profiles) {
        let _ = fs::remove_dir_all(&destination);
        return Err(e);
    }
    Ok(cloned)
}

#[tauri::command]
fn delete_profile(app: AppHandle, profile_id: String) -> Result<(), String> {
    let mut profiles = read_profiles(&app)?;
    if !profiles.iter().any(|p| p.id == profile_id) {
        return Err("Profile not found.".into());
    }
    let path = locate_profile_dir(&app, &profile_id)?;
    fs::remove_dir_all(path).map_err(|e| format!("Could not remove profile files: {e}"))?;
    profiles.retain(|p| p.id != profile_id);
    write_profiles(&app, &profiles)
}

#[tauri::command]
fn open_profile_folder(app: AppHandle, profile_id: String) -> Result<(), String> {
    let path = locate_profile_dir(&app, &profile_id)?;
    #[cfg(target_os = "windows")]
    let result = std::process::Command::new("explorer").arg(&path).spawn();
    #[cfg(target_os = "macos")]
    let result = std::process::Command::new("open").arg(&path).spawn();
    #[cfg(all(unix, not(target_os = "macos")))]
    let result = std::process::Command::new("xdg-open").arg(&path).spawn();
    result.map(|_| ()).map_err(|e| format!("Could not open profile folder: {e}"))
}


#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProfileFile {
    pub name: String,
    pub size: u64,
    pub is_directory: bool,
    pub modified_at: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountSummary {
    pub id: String,
    pub name: String,
    pub uuid: String,
    pub skin_url: Option<String>,
    #[serde(default = "default_account_type")]
    pub account_type: String,
}

fn default_account_type() -> String { "microsoft".into() }

fn offline_player_uuid(username: &str) -> String {
    // Java UUID.nameUUIDFromBytes("OfflinePlayer:<name>") used by offline-mode servers.
    let mut digest = Md5::digest(format!("OfflinePlayer:{username}").as_bytes());
    digest[6] = (digest[6] & 0x0f) | 0x30; // UUID version 3
    digest[8] = (digest[8] & 0x3f) | 0x80; // RFC 4122 variant
    let b = digest.as_slice();
    format!("{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15])
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all(serialize = "camelCase", deserialize = "snake_case"))]
pub struct DeviceCode {
    pub device_code: String,
    pub user_code: String,
    pub verification_uri: String,
    pub message: String,
    pub expires_in: u64,
    pub interval: u64,
}

fn category_dir(category: &str) -> Result<&'static str, String> {
    match category {
        "mods" => Ok("mods"),
        "resourcepacks" => Ok("resourcepacks"),
        "shaderpacks" => Ok("shaderpacks"),
        "config" => Ok("config"),
        "saves" => Ok("saves"),
        "logs" => Ok("logs"),
        "screenshots" => Ok("screenshots"),
        _ => Err("Unsupported profile folder.".into()),
    }
}

#[tauri::command]
fn get_profile_files(app: AppHandle, profile_id: String, category: String) -> Result<Vec<ProfileFile>, String> {
    let child = category_dir(&category)?;
    let dir = locate_profile_dir(&app, &profile_id)?.join(child);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let mut files = Vec::new();
    for entry in fs::read_dir(&dir).map_err(|e| e.to_string())? {
        let entry = entry.map_err(|e| e.to_string())?;
        let metadata = entry.metadata().map_err(|e| e.to_string())?;
        let modified_at = metadata.modified().ok().and_then(|t| t.duration_since(UNIX_EPOCH).ok()).map(|d| d.as_secs());
        files.push(ProfileFile {
            name: entry.file_name().to_string_lossy().to_string(),
            size: metadata.len(),
            is_directory: metadata.is_dir(),
            modified_at,
        });
    }
    files.sort_by(|a, b| a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    Ok(files)
}

#[tauri::command]
fn remove_profile_file(app: AppHandle, profile_id: String, category: String, file_name: String) -> Result<(), String> {
    let child = category_dir(&category)?;
    let safe_name = Path::new(&file_name).file_name().and_then(|v| v.to_str()).ok_or("Invalid file name.")?;
    if safe_name != file_name || safe_name.is_empty() || safe_name.contains("..") {
        return Err("Invalid file name.".into());
    }
    let base = locate_profile_dir(&app, &profile_id)?.join(child);
    let target = base.join(safe_name);
    if !target.starts_with(&base) || (!target.is_file() && !target.is_dir()) {
        return Err("File or folder not found.".into());
    }
    if target.is_dir() {
        fs::remove_dir_all(target).map_err(|e| format!("Could not remove folder: {e}"))
    } else {
        fs::remove_file(target).map_err(|e| format!("Could not remove file: {e}"))
    }
}


#[tauri::command]
fn toggle_profile_mod(app: AppHandle, profile_id: String, file_name: String, enabled: bool) -> Result<(), String> {
    let base = locate_profile_dir(&app, &profile_id)?.join("mods");
    let safe_name = Path::new(&file_name).file_name().and_then(|v| v.to_str()).ok_or("Invalid mod file name.")?;
    if safe_name != file_name || safe_name.is_empty() || safe_name.contains("..") {
        return Err("Invalid mod file name.".into());
    }
    let current = base.join(safe_name);
    if !current.is_file() { return Err("Mod file not found.".into()); }
    let next_name = if enabled {
        safe_name.strip_suffix(".disabled").ok_or("This mod is already enabled.")?.to_string()
    } else {
        if !safe_name.to_lowercase().ends_with(".jar") { return Err("Only JAR mod files can be toggled.".into()); }
        format!("{safe_name}.disabled")
    };
    let next = base.join(next_name);
    if next.exists() { return Err("A file with the target name already exists.".into()); }
    fs::rename(current, next).map_err(|e| format!("Could not change mod state: {e}"))
}

fn safe_profile_text_path(app: &AppHandle, profile_id: &str, file_name: &str) -> Result<PathBuf, String> {
    let safe_name = Path::new(file_name).file_name().and_then(|v| v.to_str()).ok_or("Invalid file name.")?;
    if safe_name != file_name || safe_name.is_empty() || safe_name.contains("..") {
        return Err("Invalid file name.".into());
    }
    let extension = Path::new(safe_name).extension().and_then(|v| v.to_str()).unwrap_or("").to_ascii_lowercase();
    if !["json", "txt", "properties", "toml", "cfg", "yml", "yaml"].contains(&extension.as_str()) {
        return Err("Only text configuration files can be edited here.".into());
    }
    Ok(locate_profile_dir(app, profile_id)?.join("config").join(safe_name))
}

#[tauri::command]
fn read_profile_text_file(app: AppHandle, profile_id: String, file_name: String) -> Result<String, String> {
    let path = safe_profile_text_path(&app, &profile_id, &file_name)?;
    let metadata = fs::metadata(&path).map_err(|e| format!("Could not read file: {e}"))?;
    if metadata.len() > 2 * 1024 * 1024 { return Err("This configuration file is larger than the 2 MB editor limit. Open it in your preferred editor instead.".into()); }
    fs::read_to_string(path).map_err(|e| format!("Could not read configuration text: {e}"))
}

#[tauri::command]
fn write_profile_text_file(app: AppHandle, profile_id: String, file_name: String, contents: String) -> Result<(), String> {
    if contents.len() > 2 * 1024 * 1024 { return Err("The editor has a 2 MB save limit.".into()); }
    let path = safe_profile_text_path(&app, &profile_id, &file_name)?;
    fs::write(path, contents).map_err(|e| format!("Could not save configuration file: {e}"))
}

#[tauri::command]
fn open_profile_category(app: AppHandle, profile_id: String, category: String) -> Result<(), String> {
    let child = category_dir(&category)?;
    let path = locate_profile_dir(&app, &profile_id)?.join(child);
    fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    #[cfg(target_os = "windows")]
    let result = std::process::Command::new("explorer").arg(&path).spawn();
    #[cfg(target_os = "macos")]
    let result = std::process::Command::new("open").arg(&path).spawn();
    #[cfg(all(unix, not(target_os = "macos")))]
    let result = std::process::Command::new("xdg-open").arg(&path).spawn();
    result.map(|_| ()).map_err(|e| format!("Could not open folder: {e}"))
}


#[tauri::command]
async fn search_modrinth(query: String, project_type: String, minecraft_version: String, loader: String, sort: String) -> Result<serde_json::Value, String> {
    if !["mod", "resourcepack", "shader", "modpack"].contains(&project_type.as_str()) {
        return Err("Unsupported Modrinth project type.".into());
    }
    let sort = if ["relevance", "downloads", "follows", "newest", "updated"].contains(&sort.as_str()) { sort } else { "downloads".into() };
    tauri::async_runtime::spawn_blocking(move || {
        let mut facets: Vec<Vec<String>> = vec![vec![format!("project_type:{project_type}")]];
        if !minecraft_version.trim().is_empty() { facets.push(vec![format!("versions:{}", minecraft_version.trim())]); }
        if project_type == "mod" && !loader.trim().is_empty() && loader != "Vanilla" {
            facets.push(vec![format!("categories:{}", loader.to_lowercase())]);
        }
        let facets_json = serde_json::to_string(&facets).map_err(|e| e.to_string())?;
        let client = reqwest::blocking::Client::builder().timeout(Duration::from_secs(25))
            .user_agent("VOID-CLIENT/0.6.3 (personal Minecraft launcher)")
            .build().map_err(|e| e.to_string())?;
        let response = client.get("https://api.modrinth.com/v2/search")
            .query(&[("query", query.as_str()), ("facets", facets_json.as_str()), ("index", sort.as_str()), ("limit", "24")])
            .send().map_err(|e| format!("Could not reach Modrinth: {e}"))?;
        let status = response.status();
        let value: serde_json::Value = response.json().map_err(|e| e.to_string())?;
        if !status.is_success() {
            return Err(value.get("error").and_then(|v| v.as_str()).unwrap_or("Modrinth rejected the search.").to_string());
        }
        Ok(value)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn install_remote_file(
    app: AppHandle,
    profile_id: String,
    category: String,
    file_name: String,
    url: String,
    expected_sha512: Option<String>,
) -> Result<ProfileFile, String> {
    let child = category_dir(&category)?.to_string();
    let safe_name = Path::new(&file_name).file_name().and_then(|v| v.to_str()).ok_or("Invalid file name.")?.to_string();
    if safe_name != file_name || safe_name.is_empty() || safe_name.contains("..") {
        return Err("Invalid file name.".into());
    }
    let parsed = reqwest::Url::parse(&url).map_err(|_| "Invalid download URL.")?;
    if parsed.scheme() != "https" || parsed.host_str() != Some("cdn.modrinth.com") {
        return Err("Downloads are restricted to Modrinth's HTTPS CDN.".into());
    }
    let dir = locate_profile_dir(&app, &profile_id)?.join(child);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let target = dir.join(&safe_name);
    if target.exists() {
        return Err(format!("{safe_name} is already installed in this profile."));
    }
    let temp = dir.join(format!(".{safe_name}.void-download"));
    let result = tauri::async_runtime::spawn_blocking(move || {
        let client = reqwest::blocking::Client::builder()
            .timeout(Duration::from_secs(300))
            .user_agent("VOID-CLIENT/0.6.3 (personal desktop launcher)")
            .build().map_err(|e| e.to_string())?;
        let response = client.get(&url).send().map_err(|e| format!("Download failed: {e}"))?
            .error_for_status().map_err(|e| format!("Download server rejected the request: {e}"))?;
        if response.url().scheme() != "https" || response.url().host_str() != Some("cdn.modrinth.com") {
            return Err("Download redirected outside Modrinth's HTTPS CDN; the file was not installed.".into());
        }
        if response.content_length().unwrap_or(0) > 512 * 1024 * 1024 {
            return Err("This file is larger than VOID CLIENT's 512 MB per-file safety limit.".into());
        }
        let bytes = response.bytes().map_err(|e| format!("Could not read downloaded file: {e}"))?;
        if bytes.len() > 512 * 1024 * 1024 {
            return Err("This file is larger than VOID CLIENT's 512 MB per-file safety limit.".into());
        }
        if let Some(expected) = expected_sha512.as_deref() {
            let mut hasher = Sha512::new();
            hasher.update(&bytes);
            let actual = hex::encode(hasher.finalize());
            if actual.eq_ignore_ascii_case(expected) == false {
                return Err("Downloaded file failed its SHA-512 integrity check.".into());
            }
        }
        fs::write(&temp, &bytes).map_err(|e| format!("Could not write download: {e}"))?;
        fs::rename(&temp, &target).map_err(|e| {
            let _ = fs::remove_file(&temp);
            format!("Could not finish installing file: {e}")
        })?;
        let metadata = fs::metadata(&target).map_err(|e| e.to_string())?;
        Ok(ProfileFile { name: safe_name, size: metadata.len(), is_directory: false, modified_at: Some(now_ms() / 1000) })
    }).await.map_err(|e| e.to_string())?;
    result
}

fn accounts_file(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(root_dir(app)?.join("accounts.json"))
}

fn read_accounts(app: &AppHandle) -> Result<Vec<AccountSummary>, String> {
    let path = accounts_file(app)?;
    if !path.exists() { return Ok(Vec::new()); }
    serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?).map_err(|e| format!("Could not read accounts: {e}"))
}

fn write_accounts(app: &AppHandle, accounts: &[AccountSummary]) -> Result<(), String> {
    fs::write(accounts_file(app)?, serde_json::to_vec_pretty(accounts).map_err(|e| e.to_string())?).map_err(|e| e.to_string())
}

#[tauri::command]
fn get_accounts(app: AppHandle) -> Result<Vec<AccountSummary>, String> { read_accounts(&app) }

#[tauri::command]
fn add_offline_account(app: AppHandle, username: String) -> Result<AccountSummary, String> {
    let username = username.trim();
    if !(3..=16).contains(&username.len()) || !username.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Err("Offline username must be 3–16 characters and use only A–Z, 0–9 or underscores.".into());
    }
    let mut accounts = read_accounts(&app)?;
    if let Some(existing) = accounts.iter().find(|a| a.account_type == "offline" && a.name == username) {
        return Ok(existing.clone());
    }
    let uuid = offline_player_uuid(username);
    let summary = AccountSummary {
        id: format!("offline-{}", uuid.replace('-', "")),
        name: username.to_string(),
        uuid,
        skin_url: None,
        account_type: "offline".into(),
    };
    accounts.push(summary.clone());
    write_accounts(&app, &accounts)?;
    Ok(summary)
}

#[tauri::command]
fn open_external_url(url: String) -> Result<(), String> {
    // Only allow known HTTPS destinations used by launcher sign-in and integrations.
    let parsed = reqwest::Url::parse(&url).map_err(|_| "The external link is not a valid URL.".to_string())?;
    let host = parsed.host_str().unwrap_or_default().to_ascii_lowercase();
    let allowed_hosts = [
        "microsoft.com", "www.microsoft.com", "login.microsoftonline.com",
        "entra.microsoft.com", "aka.ms", "modrinth.com", "www.modrinth.com",
        "curseforge.com", "www.curseforge.com", "console.curseforge.com",
        "support.curseforge.com", "playit.gg", "www.playit.gg",
    ];
    if parsed.scheme() != "https"
        || !allowed_hosts.contains(&host.as_str())
        || !parsed.username().is_empty()
        || parsed.password().is_some()
        || parsed.port().is_some_and(|port| port != 443)
    {
        return Err("VOID CLIENT blocked this external link because its HTTPS host is not on the allowlist.".into());
    }

    #[cfg(target_os = "windows")]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        Command::new("rundll32.exe")
            .args(["url.dll,FileProtocolHandler", parsed.as_str()])
            .creation_flags(CREATE_NO_WINDOW)
            .spawn()
            .map_err(|e| format!("Windows could not open your default browser: {e}"))?;
        Ok(())
    }
    #[cfg(target_os = "macos")]
    {
        Command::new("open").arg(parsed.as_str()).spawn()
            .map_err(|e| format!("Could not open your default browser: {e}"))?;
        Ok(())
    }
    #[cfg(all(unix, not(target_os = "macos")))]
    {
        Command::new("xdg-open").arg(parsed.as_str()).spawn()
            .map_err(|e| format!("Could not open your default browser: {e}"))?;
        Ok(())
    }
}

#[tauri::command]
fn is_microsoft_login_configured(app: AppHandle) -> bool { microsoft_client_id(&app).is_ok() }

#[tauri::command]
async fn begin_microsoft_login(app: AppHandle) -> Result<DeviceCode, String> {
    let client_id = microsoft_client_id(&app)?;
    tauri::async_runtime::spawn_blocking(move || {
        let client = reqwest::blocking::Client::builder().timeout(Duration::from_secs(30)).build().map_err(|e| e.to_string())?;
        let response = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode")
            .header(reqwest::header::ACCEPT, "application/json")
            .form(&[("client_id", client_id.as_str()), ("scope", "XboxLive.signin offline_access")])
            .send().map_err(|e| format!("Could not contact Microsoft sign-in: {e}"))?;
        let status = response.status();
        let response_text = response.text().map_err(|e| format!("Could not read Microsoft's sign-in response: {e}"))?;
        let value: serde_json::Value = serde_json::from_str(&response_text).map_err(|e| {
            format!("Microsoft returned an unreadable device-code response (HTTP {status}): {e}. Response: {}", response_text.chars().take(400).collect::<String>())
        })?;
        if !status.is_success() {
            let code = value.get("error").and_then(|v| v.as_str()).unwrap_or("unknown_error");
            let detail = value.get("error_description").and_then(|v| v.as_str()).unwrap_or("Microsoft rejected the device sign-in request.");
            let trace = value.get("trace_id").and_then(|v| v.as_str()).unwrap_or_default();
            let correlation = value.get("correlation_id").and_then(|v| v.as_str()).unwrap_or_default();
            return Err(format!("Microsoft device sign-in was rejected (HTTP {status}, {code}): {detail} Trace: {trace}; correlation: {correlation}"));
        }
        serde_json::from_value(value).map_err(|e| format!("Unexpected Microsoft device-code response: {e}"))
    }).await.map_err(|e| e.to_string())?
}

fn auth_service_error(value: &serde_json::Value, status: reqwest::StatusCode) -> String {
    let xerr = value.get("XErr").and_then(|v| v.as_i64().map(|n| n.to_string()).or_else(|| v.as_str().map(str::to_owned)));
    if let Some(code) = xerr.as_deref() {
        let message = match code {
            "2148916233" => "This Microsoft account has no Xbox profile. Sign in at xbox.com and complete Xbox profile setup, then try again.",
            "2148916235" => "Xbox Live is unavailable for this account or region. Check Xbox account availability and regional settings.",
            "2148916238" => "This account needs a parent or guardian to complete Xbox family setup before it can use Minecraft services.",
            _ => "Xbox security rejected the account. Check the Xbox account's profile, age and privacy settings.",
        };
        return format!("{message} (XErr {code}, HTTP {status}).");
    }
    for key in ["errorMessage", "Message", "error_description", "error"] {
        if let Some(detail) = value.get(key).and_then(|v| v.as_str()).filter(|s| !s.trim().is_empty()) {
            return format!("{detail} (HTTP {status}).");
        }
    }
    format!("The authentication service rejected the request (HTTP {status}).")
}

fn post_json(client: &reqwest::blocking::Client, url: &str, body: serde_json::Value) -> Result<serde_json::Value, String> {
    let response = client.post(url)
        .header(reqwest::header::ACCEPT, "application/json")
        .json(&body)
        .send().map_err(|e| format!("Request failed: {e}"))?;
    let status = response.status();
    let value: serde_json::Value = response.json().map_err(|e| format!("Authentication service returned invalid JSON: {e}"))?;
    if !status.is_success() { return Err(auth_service_error(&value, status)); }
    Ok(value)
}

#[tauri::command]
async fn complete_microsoft_login(app: AppHandle, device_code: String, interval: u64, expires_in: u64) -> Result<AccountSummary, String> {
    let client_id = microsoft_client_id(&app)?;
    tauri::async_runtime::spawn_blocking(move || {
        let client = reqwest::blocking::Client::builder().timeout(Duration::from_secs(30)).build().map_err(|e| e.to_string())?;
        let started = SystemTime::now();
        let mut poll_interval = interval.max(5);
        let token_value = loop {
            if started.elapsed().unwrap_or_default().as_secs() > expires_in {
                return Err("Microsoft sign-in code expired. Start sign-in again.".into());
            }
            let response = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token")
                .header(reqwest::header::ACCEPT, "application/json")
                .form(&[
                    ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
                    ("client_id", client_id.as_str()),
                    ("device_code", device_code.as_str()),
                ]).send().map_err(|e| format!("Could not poll Microsoft sign-in: {e}"))?;
            let status = response.status();
            let value: serde_json::Value = response.json().map_err(|e| e.to_string())?;
            if status.is_success() { break value; }
            match value.get("error").and_then(|v| v.as_str()).unwrap_or("") {
                "authorization_pending" => thread::sleep(Duration::from_secs(poll_interval.max(1))),
                "slow_down" => { poll_interval += 5; thread::sleep(Duration::from_secs(poll_interval)); },
                "authorization_declined" | "access_denied" => return Err("Microsoft sign-in was declined.".into()),
                "expired_token" => return Err("Microsoft sign-in code expired. Start sign-in again.".into()),
                _ => return Err(value.get("error_description").and_then(|v| v.as_str()).unwrap_or("Microsoft sign-in failed.").to_string()),
            }
        };
        let microsoft_token = token_value.get("access_token").and_then(|v| v.as_str()).ok_or("Microsoft did not return an access token.")?;
        let refresh_token = token_value.get("refresh_token").and_then(|v| v.as_str()).ok_or("Microsoft did not return a refresh token.")?;
        let xbox = post_json(&client, "https://user.auth.xboxlive.com/user/authenticate", serde_json::json!({
            "Properties": { "AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": format!("d={microsoft_token}") },
            "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"
        }))?;
        let xbox_token = xbox.get("Token").and_then(|v| v.as_str()).ok_or("Xbox Live did not return a token.")?;
        let xsts = post_json(&client, "https://xsts.auth.xboxlive.com/xsts/authorize", serde_json::json!({
            "Properties": { "SandboxId": "RETAIL", "UserTokens": [xbox_token] },
            "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"
        }))?;
        let xsts_token = xsts.get("Token").and_then(|v| v.as_str()).ok_or("Xbox security did not return a token.")?;
        let user_hash = xsts.pointer("/DisplayClaims/xui/0/uhs").and_then(|v| v.as_str()).ok_or("Xbox security did not return a user hash.")?;
        let minecraft = post_json(&client, "https://api.minecraftservices.com/authentication/login_with_xbox", serde_json::json!({
            "identityToken": format!("XBL3.0 x={user_hash};{xsts_token}")
        }))?;
        let minecraft_token = minecraft.get("access_token").and_then(|v| v.as_str()).ok_or("Minecraft Services did not return an access token.")?;
        let profile_response = client.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(minecraft_token)
            .send().map_err(|e| format!("Could not retrieve Minecraft profile: {e}"))?;
        if !profile_response.status().is_success() {
            let status = profile_response.status();
            let detail = profile_response.text().unwrap_or_default();
            return Err(if status == reqwest::StatusCode::FORBIDDEN {
                format!("Minecraft Services returned 403 Forbidden. The Microsoft app registration may not be approved for Minecraft Services API access, or this account is not entitled to Java Edition. Details: {}", detail.chars().take(500).collect::<String>())
            } else if status == reqwest::StatusCode::NOT_FOUND {
                "Microsoft sign-in succeeded, but this account has no Minecraft Java profile. Sign in with the Microsoft account that owns Java Edition.".into()
            } else {
                format!("Minecraft profile lookup failed (HTTP {status}). {}", detail.chars().take(500).collect::<String>())
            });
        }
        let game_profile: serde_json::Value = profile_response.json().map_err(|e| e.to_string())?;
        let id = game_profile.get("id").and_then(|v| v.as_str()).ok_or("Minecraft profile UUID is missing.")?.to_string();
        let name = game_profile.get("name").and_then(|v| v.as_str()).ok_or("Minecraft profile name is missing.")?.to_string();
        let skin_url = game_profile.get("skins").and_then(|v| v.as_array()).and_then(|arr| arr.first())
            .and_then(|skin| skin.get("url")).and_then(|v| v.as_str()).map(|v| v.to_string());
        let summary = AccountSummary { id: id.clone(), name, uuid: id.clone(), skin_url, account_type: "microsoft".into() };
        let entry = keyring::Entry::new("com.voidclient.launcher", &id).map_err(|e| format!("Could not access Windows Credential Manager: {e}"))?;
        entry.set_password(refresh_token).map_err(|e| format!("Could not securely save the Microsoft session: {e}"))?;
        let mut accounts = read_accounts(&app)?;
        accounts.retain(|account| account.id != id);
        accounts.push(summary.clone());
        write_accounts(&app, &accounts)?;
        Ok(summary)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
async fn refresh_microsoft_session(app: AppHandle, account_id: String) -> Result<AccountSummary, String> {
    let client_id = microsoft_client_id(&app)?;
    tauri::async_runtime::spawn_blocking(move || {
        let entry = keyring::Entry::new("com.voidclient.launcher", &account_id)
            .map_err(|e| format!("Could not access Windows Credential Manager: {e}"))?;
        let saved_refresh = entry.get_password()
            .map_err(|e| format!("No saved Microsoft session was found for this account: {e}"))?;
        let client = reqwest::blocking::Client::builder().timeout(Duration::from_secs(30)).build().map_err(|e| e.to_string())?;
        let response = client.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token")
            .header(reqwest::header::ACCEPT, "application/json")
            .form(&[
                ("client_id", client_id.as_str()),
                ("grant_type", "refresh_token"),
                ("refresh_token", saved_refresh.as_str()),
                ("scope", "XboxLive.signin offline_access"),
            ])
            .send().map_err(|e| format!("Could not renew Microsoft session: {e}"))?;
        let status = response.status();
        let token_value: serde_json::Value = response.json().map_err(|e| e.to_string())?;
        if !status.is_success() {
            return Err(token_value.get("error_description").and_then(|v| v.as_str())
                .unwrap_or("Microsoft could not renew this session. Sign in again.").to_string());
        }
        let microsoft_token = token_value.get("access_token").and_then(|v| v.as_str()).ok_or("Microsoft did not return an access token.")?;
        let refreshed_token = token_value.get("refresh_token").and_then(|v| v.as_str()).unwrap_or(saved_refresh.as_str());
        let xbox = post_json(&client, "https://user.auth.xboxlive.com/user/authenticate", serde_json::json!({
            "Properties": { "AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": format!("d={microsoft_token}") },
            "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"
        }))?;
        let xbox_token = xbox.get("Token").and_then(|v| v.as_str()).ok_or("Xbox Live did not return a token.")?;
        let xsts = post_json(&client, "https://xsts.auth.xboxlive.com/xsts/authorize", serde_json::json!({
            "Properties": { "SandboxId": "RETAIL", "UserTokens": [xbox_token] },
            "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"
        }))?;
        let xsts_token = xsts.get("Token").and_then(|v| v.as_str()).ok_or("Xbox security did not return a token.")?;
        let user_hash = xsts.pointer("/DisplayClaims/xui/0/uhs").and_then(|v| v.as_str()).ok_or("Xbox security did not return a user hash.")?;
        let minecraft = post_json(&client, "https://api.minecraftservices.com/authentication/login_with_xbox", serde_json::json!({
            "identityToken": format!("XBL3.0 x={user_hash};{xsts_token}")
        }))?;
        let minecraft_token = minecraft.get("access_token").and_then(|v| v.as_str()).ok_or("Minecraft Services did not return an access token.")?;
        let profile_response = client.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(minecraft_token)
            .send().map_err(|e| format!("Could not retrieve Minecraft profile: {e}"))?;
        if !profile_response.status().is_success() {
            let status = profile_response.status();
            let detail = profile_response.text().unwrap_or_default();
            return Err(if status == reqwest::StatusCode::FORBIDDEN {
                format!("Minecraft Services returned 403 Forbidden. The app registration may need Minecraft API approval, or this account may lack Java Edition entitlement. Details: {}", detail.chars().take(500).collect::<String>())
            } else {
                format!("Minecraft profile refresh failed (HTTP {status}). {}", detail.chars().take(500).collect::<String>())
            });
        }
        let game_profile: serde_json::Value = profile_response.json().map_err(|e| e.to_string())?;
        let id = game_profile.get("id").and_then(|v| v.as_str()).ok_or("Minecraft profile UUID is missing.")?.to_string();
        if id != account_id { return Err("The Microsoft session resolved to a different Minecraft account. Please remove and reconnect the account.".into()); }
        let name = game_profile.get("name").and_then(|v| v.as_str()).ok_or("Minecraft profile name is missing.")?.to_string();
        let skin_url = game_profile.get("skins").and_then(|v| v.as_array()).and_then(|arr| arr.first())
            .and_then(|skin| skin.get("url")).and_then(|v| v.as_str()).map(|v| v.to_string());
        entry.set_password(refreshed_token).map_err(|e| format!("Session renewed, but could not update the Windows credential: {e}"))?;
        let summary = AccountSummary { id: id.clone(), name, uuid: id, skin_url, account_type: "microsoft".into() };
        let mut accounts = read_accounts(&app)?;
        if let Some(existing) = accounts.iter_mut().find(|account| account.id == summary.id) { *existing = summary.clone(); }
        write_accounts(&app, &accounts)?;
        Ok(summary)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
fn remove_account(app: AppHandle, account_id: String) -> Result<(), String> {
    let mut accounts = read_accounts(&app)?;
    let account = accounts.iter().find(|account| account.id == account_id)
        .ok_or("Account not found.")?;
    if account.account_type != "offline" {
        let entry = keyring::Entry::new("com.voidclient.launcher", &account_id).map_err(|e| e.to_string())?;
        entry.delete_credential().map_err(|e| format!("Could not remove the saved Windows credential: {e}"))?;
    }
    accounts.retain(|account| account.id != account_id);
    write_accounts(&app, &accounts)?;
    let settings_path = root_dir(&app)?.join("settings.json");
    if settings_path.exists() {
        let mut settings: LauncherSettings = serde_json::from_slice(&fs::read(&settings_path).map_err(|e| e.to_string())?)
            .map_err(|e| format!("Could not read launcher settings: {e}"))?;
        if settings.selected_account_id.as_deref() == Some(account_id.as_str()) {
            settings.selected_account_id = None;
            fs::write(&settings_path, serde_json::to_vec_pretty(&settings).map_err(|e| e.to_string())?)
                .map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

#[tauri::command]
fn get_settings(app: AppHandle) -> Result<LauncherSettings, String> {
    let path = root_dir(&app)?.join("settings.json");
    if !path.exists() {
        return Ok(LauncherSettings::default());
    }
    let bytes = fs::read(path).map_err(|e| e.to_string())?;
    serde_json::from_slice(&bytes).map_err(|e| format!("Could not read settings: {e}"))
}

#[tauri::command]
fn save_settings(app: AppHandle, settings: LauncherSettings) -> Result<(), String> {
    let path = root_dir(&app)?.join("settings.json");
    fs::write(path, serde_json::to_vec_pretty(&settings).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn get_storage_path(app: AppHandle) -> Result<String, String> {
    Ok(root_dir(&app)?.to_string_lossy().to_string())
}

mod engine;
mod servers;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            get_profiles,
            create_profile,
            update_profile,
            duplicate_profile,
            delete_profile,
            open_profile_folder,
            get_profile_files,
            remove_profile_file,
            open_profile_category,
            toggle_profile_mod,
            read_profile_text_file,
            write_profile_text_file,
            install_remote_file,
            search_modrinth,
            get_accounts,
            add_offline_account,
            is_microsoft_login_configured,
            open_external_url,
            begin_microsoft_login,
            complete_microsoft_login,
            refresh_microsoft_session,
            remove_account,
            get_settings,
            save_settings,
            get_storage_path,
            engine::list_minecraft_versions,
            engine::install_vanilla,
            engine::install_profile_loader,
            engine::launch_profile,
            engine::diagnose_profile,
            engine::detect_java_runtimes,
            engine::install_java_runtime,
            engine::get_engine_status,
            engine::set_curseforge_api_key,
            engine::has_curseforge_api_key,
            engine::search_curseforge,
            engine::install_curseforge_mod,
            engine::install_modrinth_project,
            engine::install_modrinth_modpack,
            engine::install_modrinth_pack_file,
            engine::install_curseforge_modpack,
            servers::get_servers,
            servers::create_server,
            servers::update_server,
            servers::set_server_eula,
            servers::install_server,
            servers::reinstall_server,
            servers::start_server,
            servers::send_server_command,
            servers::stop_server,
            servers::kill_server,
            servers::delete_server,
            servers::get_server_files,
            servers::remove_server_file,
            servers::toggle_server_mod,
            servers::read_server_text_file,
            servers::write_server_text_file,
            servers::open_server_folder,
            servers::search_server_mods,
            servers::install_server_mod,
            servers::install_playit_with_winget,
            servers::start_playit_agent,
            servers::stop_playit_agent,
            servers::is_playit_running
        ])
        .run(tauri::generate_context!())
        .expect("error while running VOID CLIENT");
}
