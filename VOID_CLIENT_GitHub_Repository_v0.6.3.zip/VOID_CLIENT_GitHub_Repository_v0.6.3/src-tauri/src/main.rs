#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    void_client_lib::run();
}
