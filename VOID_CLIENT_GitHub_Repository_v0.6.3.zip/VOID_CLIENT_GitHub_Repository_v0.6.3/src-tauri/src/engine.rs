use keyring::Entry;
use reqwest::blocking::Client;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use sha1::{Digest as Sha1Digest, Sha1};
use sha2::Sha512;
use std::{
    collections::{HashMap, HashSet},
    fs,
    io::{BufRead, BufReader, Cursor, Read, Write},
    path::{Component, Path, PathBuf},
    process::{Command, Stdio},
    sync::{atomic::{AtomicUsize, Ordering}, Mutex},
    thread,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter, Manager};
use zip::ZipArchive;

// Keep Java helper processes from flashing a separate Windows console. Their
// stdout/stderr remain redirected so the launcher can display them in its
// built-in live Console view.
#[cfg(target_os = "windows")]
fn hide_console_window(command: &mut Command) {
    use std::os::windows::process::CommandExt;
    const CREATE_NO_WINDOW: u32 = 0x0800_0000;
    command.creation_flags(CREATE_NO_WINDOW);
}

#[cfg(not(target_os = "windows"))]
fn hide_console_window(_command: &mut Command) {}

const MOJANG_MANIFEST: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
const USER_AGENT: &str = "VOID-CLIENT/0.6.3 (personal Minecraft launcher)";
const MODRINTH_FILE_HOSTS: &[&str] = &["cdn.modrinth.com", "github.com", "raw.githubusercontent.com", "gitlab.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com", "github-releases.githubusercontent.com"];
const CURSEFORGE_FILE_HOSTS: &[&str] = &["media.forgecdn.net", "edge.forgecdn.net", "www.curseforge.com"];

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GameVersion {
    pub id: String,
    pub version_type: String,
    pub release_time: Option<String>,
    pub url: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct JavaRuntime {
    pub major: u32,
    pub path: String,
    pub source: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EngineStatus {
    pub installed: bool,
    pub game_version: String,
    pub installed_version: Option<String>,
    pub java_required: u32,
    pub java_found: bool,
    pub loader: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
struct StoredProfile {
    id: String,
    name: String,
    minecraft_version: String,
    loader: String,
    ram_gb: u8,
    created_at: u64,
    last_played: Option<u64>,
    java_path: Option<String>,
    jvm_args: String,
    game_width: u16,
    game_height: u16,
    fullscreen: bool,
    #[serde(default)]
    installed_version: Option<String>,
}

fn now_ms() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis() as u64
}

fn root_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let root = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    Ok(root)
}

fn profiles_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let path = root_dir(app)?.join("profiles");
    fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    Ok(path)
}

fn profiles_file(app: &AppHandle) -> Result<PathBuf, String> { Ok(root_dir(app)?.join("profiles.json")) }
fn accounts_file(app: &AppHandle) -> Result<PathBuf, String> { Ok(root_dir(app)?.join("accounts.json")) }
fn settings_file(app: &AppHandle) -> Result<PathBuf, String> { Ok(root_dir(app)?.join("settings.json")) }

fn load_profiles(app: &AppHandle) -> Result<Vec<StoredProfile>, String> {
    let path = profiles_file(app)?;
    if !path.exists() { return Ok(Vec::new()); }
    serde_json::from_slice(&fs::read(path).map_err(|e| e.to_string())?)
        .map_err(|e| format!("Could not read profiles: {e}"))
}

fn save_profiles(app: &AppHandle, profiles: &[StoredProfile]) -> Result<(), String> {
    fs::write(profiles_file(app)?, serde_json::to_vec_pretty(profiles).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())
}

fn update_profile(app: &AppHandle, updated: &StoredProfile) -> Result<(), String> {
    let mut profiles = load_profiles(app)?;
    let Some(index) = profiles.iter().position(|p| p.id == updated.id) else { return Err("Profile not found.".into()); };
    profiles[index] = updated.clone();
    save_profiles(app, &profiles)?;
    let dir = locate_profile_dir(app, &updated.id)?;
    fs::write(dir.join("profile.json"), serde_json::to_vec_pretty(updated).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())
}

fn locate_profile_dir(app: &AppHandle, id: &str) -> Result<PathBuf, String> {
    if id.is_empty() || !id.chars().all(|c| c.is_ascii_alphanumeric() || c == '-' || c == '_') {
        return Err("Invalid profile identifier.".into());
    }
    for entry in fs::read_dir(profiles_dir(app)?).map_err(|e| e.to_string())?.flatten() {
        let path = entry.path();
        if path.is_dir() && path.file_name().and_then(|n| n.to_str()).map(|n| n.ends_with(&format!("-{id}"))).unwrap_or(false) {
            return Ok(path);
        }
    }
    Err("Profile folder not found.".into())
}

fn client() -> Result<Client, String> {
    Client::builder().timeout(Duration::from_secs(300)).user_agent(USER_AGENT)
        .build().map_err(|e| format!("Could not initialize HTTP client: {e}"))
}

fn get_json(client: &Client, url: &str) -> Result<Value, String> {
    let response = client.get(url).send().map_err(|e| format!("Could not download metadata: {e}"))?;
    let status = response.status();
    let body: Value = response.json().map_err(|e| format!("Invalid JSON from {url}: {e}"))?;
    if !status.is_success() {
        return Err(body.get("error").and_then(Value::as_str).unwrap_or("Metadata server returned an error.").to_string());
    }
    Ok(body)
}

fn emit_progress(app: &AppHandle, profile_id: &str, stage: &str, done: u64, total: u64, detail: &str) {
    let _ = app.emit("void-engine-progress", json!({
        "profileId": profile_id, "stage": stage, "done": done, "total": total,
        "percent": if total == 0 { 0 } else { ((done as f64 / total as f64) * 100.0).round() as u8 },
        "detail": detail
    }));
}

fn safe_version_id(id: &str) -> bool {
    !id.is_empty() && id.len() <= 80 && id.chars().all(|c| c.is_ascii_alphanumeric() || matches!(c, '.' | '_' | '-' | '+'))
}

fn safe_relative_path(value: &str) -> Result<PathBuf, String> {
    let path = Path::new(value);
    if path.as_os_str().is_empty() { return Err("Empty archive path.".into()); }
    for component in path.components() {
        match component {
            Component::Normal(_) => {},
            _ => return Err(format!("Unsafe archive path rejected: {value}")),
        }
    }
    Ok(path.to_path_buf())
}

fn sha1_hex(bytes: &[u8]) -> String {
    let mut hasher = Sha1::new();
    hasher.update(bytes);
    hex::encode(hasher.finalize())
}

fn download_bytes(client: &Client, url: &str, max_bytes: u64) -> Result<Vec<u8>, String> {
    let parsed = reqwest::Url::parse(url).map_err(|_| "Invalid download URL.".to_string())?;
    if parsed.scheme() != "https" { return Err("Only HTTPS downloads are allowed.".into()); }
    let response = client.get(url).send().map_err(|e| format!("Download failed: {e}"))?
        .error_for_status().map_err(|e| format!("Download server returned an error: {e}"))?;
    if response.url().scheme() != "https" { return Err("Download redirected to a non-HTTPS URL; it was blocked.".into()); }
    if response.content_length().unwrap_or(0) > max_bytes { return Err("Download exceeds the safety size limit.".into()); }
    let mut limited = response.take(max_bytes.saturating_add(1));
    let mut bytes = Vec::new();
    limited.read_to_end(&mut bytes).map_err(|e| format!("Could not read download: {e}"))?;
    if bytes.len() as u64 > max_bytes { return Err("Download exceeds the safety size limit.".into()); }
    Ok(bytes)
}

fn restricted_download_client(allowed_hosts: &'static [&'static str]) -> Result<Client, String> {
    Client::builder()
        .timeout(Duration::from_secs(300))
        .user_agent(USER_AGENT)
        .redirect(reqwest::redirect::Policy::custom(move |attempt| {
            let url = attempt.url();
            let allowed = url.scheme() == "https"
                && allowed_hosts.iter().any(|host| url.host_str() == Some(*host));
            if allowed && attempt.previous().len() < 5 { attempt.follow() } else { attempt.stop() }
        }))
        .build()
        .map_err(|e| format!("Could not initialize restricted download client: {e}"))
}

fn read_limited_response(response: reqwest::blocking::Response, max_bytes: u64) -> Result<Vec<u8>, String> {
    if response.url().scheme() != "https" { return Err("Download redirected to a non-HTTPS URL; it was blocked.".into()); }
    if response.content_length().unwrap_or(0) > max_bytes { return Err("Download exceeds the safety size limit.".into()); }
    let mut limited = response.take(max_bytes.saturating_add(1));
    let mut bytes = Vec::new();
    limited.read_to_end(&mut bytes).map_err(|e| format!("Could not read download: {e}"))?;
    if bytes.len() as u64 > max_bytes { return Err("Download exceeds the safety size limit.".into()); }
    Ok(bytes)
}

fn download_from_allowed_hosts(url: &str, max_bytes: u64, allowed_hosts: &'static [&'static str]) -> Result<Vec<u8>, String> {
    let parsed = reqwest::Url::parse(url).map_err(|_| "Invalid download URL.".to_string())?;
    if parsed.scheme() != "https" || !allowed_hosts.iter().any(|host| parsed.host_str() == Some(*host)) {
        return Err("Download URL is outside the provider's permitted HTTPS hosts.".into());
    }
    let http = restricted_download_client(allowed_hosts)?;
    let response = http.get(url).send().map_err(|e| format!("Download failed: {e}"))?
        .error_for_status().map_err(|e| format!("Download server returned an error: {e}"))?;
    let final_host = response.url().host_str().unwrap_or("");
    if response.url().scheme() != "https" || !allowed_hosts.iter().any(|host| *host == final_host) {
        return Err("Download redirect left the provider's permitted HTTPS hosts; it was blocked.".into());
    }
    read_limited_response(response, max_bytes)
}

fn download_curseforge_bytes(url: &str, api_key: &str, max_bytes: u64) -> Result<Vec<u8>, String> {
    let parsed = reqwest::Url::parse(url).map_err(|_| "CurseForge returned an invalid download URL.".to_string())?;
    if parsed.scheme() != "https" || !CURSEFORGE_FILE_HOSTS.iter().any(|host| Some(*host) == parsed.host_str()) {
        return Err("CurseForge returned a download URL outside its permitted HTTPS file hosts.".into());
    }
    let http = restricted_download_client(CURSEFORGE_FILE_HOSTS)?;
    // CurseForge requires the API key header on direct CDN downloads as of July 2026.
    let response = http.get(url).header("x-api-key", api_key).send()
        .map_err(|e| format!("CurseForge download failed: {e}"))?
        .error_for_status().map_err(|e| format!("CurseForge file server returned an error: {e}"))?;
    let final_host = response.url().host_str().unwrap_or("");
    if response.url().scheme() != "https" || !CURSEFORGE_FILE_HOSTS.iter().any(|host| *host == final_host) {
        return Err("CurseForge download redirected outside its permitted HTTPS file hosts; it was blocked.".into());
    }
    read_limited_response(response, max_bytes)
}

fn download_to(client: &Client, url: &str, target: &Path, expected_sha1: Option<&str>) -> Result<(), String> {
    if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    if target.exists() {
        if let Some(expected) = expected_sha1 {
            let bytes = fs::read(target).map_err(|e| e.to_string())?;
            if sha1_hex(&bytes).eq_ignore_ascii_case(expected) { return Ok(()); }
        } else if fs::metadata(target).map(|m| m.len() > 0).unwrap_or(false) { return Ok(()); }
    }
    let bytes = download_bytes(client, url, 1024 * 1024 * 1024)?;
    if let Some(expected) = expected_sha1 {
        if !sha1_hex(&bytes).eq_ignore_ascii_case(expected) {
            return Err(format!("SHA-1 verification failed for {}.", target.display()));
        }
    }
    let temp = target.with_extension(format!("{}.void-part", target.extension().and_then(|e| e.to_str()).unwrap_or("tmp")));
    fs::write(&temp, &bytes).map_err(|e| e.to_string())?;
    fs::rename(&temp, target).map_err(|e| { let _ = fs::remove_file(&temp); e.to_string() })?;
    Ok(())
}

fn version_dir(game_dir: &Path, id: &str) -> PathBuf { game_dir.join("versions").join(id) }
fn library_path_from_coordinate(coordinate: &str) -> Result<PathBuf, String> {
    let (coordinate, extension) = coordinate.split_once('@').unwrap_or((coordinate, "jar"));
    let pieces: Vec<&str> = coordinate.split(':').collect();
    if pieces.len() < 3 || pieces.len() > 4 { return Err(format!("Unsupported Maven coordinate: {coordinate}")); }
    let group = pieces[0].replace('.', "/");
    let artifact = pieces[1];
    let version = pieces[2];
    let classifier = pieces.get(3).map(|s| format!("-{s}")).unwrap_or_default();
    Ok(PathBuf::from(group).join(artifact).join(version).join(format!("{artifact}-{version}{classifier}.{extension}")))
}

fn maven_url(base: &str, coordinate: &str) -> Result<(String, PathBuf), String> {
    let path = library_path_from_coordinate(coordinate)?;
    let base = if base.ends_with('/') { base.to_string() } else { format!("{base}/") };
    let url = format!("{}{}", base, path.to_string_lossy().replace('\\', "/"));
    Ok((url, path))
}

fn feature_rules_match(features: &Value) -> bool {
    let Some(features) = features.as_object() else { return true; };
    features.iter().all(|(name, expected)| {
        let actual = match name.as_str() {
            // VOID CLIENT does not use demo-account launch mode and supplies a custom resolution.
            "is_demo_user" => false,
            "has_custom_resolution" => true,
            // Quick-play options are not currently exposed by the profile UI.
            "has_quick_plays_support" | "is_quick_play_singleplayer" |
            "is_quick_play_multiplayer" | "is_quick_play_realms" => false,
            // Unknown feature flags must not accidentally enable arguments.
            _ => false,
        };
        expected.as_bool() == Some(actual)
    })
}

fn rule_allows(entry: &Value) -> bool {
    let Some(rules) = entry.get("rules").and_then(Value::as_array) else { return true; };
    let mut allowed = false;
    for rule in rules {
        let os = rule.get("os");
        let mut matches = true;
        if let Some(name) = os.and_then(|o| o.get("name")).and_then(Value::as_str) { matches &= name == "windows"; }
        if let Some(arch) = os.and_then(|o| o.get("arch")).and_then(Value::as_str) {
            let actual = if cfg!(target_arch = "x86_64") { "x86_64" } else { "x86" };
            matches &= arch == actual || (arch == "x86" && actual == "x86");
        }
        if matches { matches &= feature_rules_match(&rule["features"]); }
        if matches {
            allowed = rule.get("action").and_then(Value::as_str) == Some("allow");
        }
    }
    allowed
}

fn artifact_for_library(library: &Value) -> Option<(String, String, Option<String>)> {
    if let Some(artifact) = library.pointer("/downloads/artifact") {
        let url = artifact.get("url")?.as_str()?.to_string();
        let path = artifact.get("path")?.as_str()?.to_string();
        let sha1 = artifact.get("sha1").and_then(Value::as_str).map(str::to_string);
        return Some((url, path, sha1));
    }
    None
}

fn download_library(client: &Client, game_dir: &Path, library: &Value) -> Result<Option<PathBuf>, String> {
    if !rule_allows(library) { return Ok(None); }
    let libraries_dir = game_dir.join("libraries");
    if let Some((url, relative, sha1)) = artifact_for_library(library) {
        let relative = safe_relative_path(&relative)?;
        let target = libraries_dir.join(relative);
        download_to(client, &url, &target, sha1.as_deref())?;
        return Ok(Some(target));
    }
    let Some(name) = library.get("name").and_then(Value::as_str) else { return Ok(None); };
    let base = library.get("url").and_then(Value::as_str).unwrap_or("https://libraries.minecraft.net/");
    let (url, relative) = maven_url(base, name)?;
    let target = libraries_dir.join(relative);
    if !target.exists() { download_to(client, &url, &target, None)?; }
    Ok(Some(target))
}

fn native_classifier(library: &Value) -> Option<String> {
    let template = library.pointer("/natives/windows")?.as_str()?;
    let arch = if cfg!(target_arch = "x86_64") { "64" } else { "32" };
    Some(template.replace("${arch}", arch))
}

fn extract_native(bytes: &[u8], destination: &Path, excludes: &[String]) -> Result<(), String> {
    fs::create_dir_all(destination).map_err(|e| e.to_string())?;
    let mut archive = ZipArchive::new(Cursor::new(bytes)).map_err(|e| format!("Invalid native archive: {e}"))?;
    for index in 0..archive.len() {
        let mut item = archive.by_index(index).map_err(|e| e.to_string())?;
        if item.is_dir() { continue; }
        let name = item.name().replace('\\', "/");
        if name.starts_with("META-INF/") || excludes.iter().any(|prefix| name.starts_with(prefix)) { continue; }
        let relative = safe_relative_path(&name)?;
        let target = destination.join(relative);
        if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
        let mut bytes = Vec::new();
        item.read_to_end(&mut bytes).map_err(|e| e.to_string())?;
        fs::write(target, bytes).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn install_vanilla_inner(app: &AppHandle, profile_id: &str, mc_version: &str) -> Result<String, String> {
    if !safe_version_id(mc_version) { return Err("Invalid Minecraft version identifier.".into()); }
    let game_dir = locate_profile_dir(app, profile_id)?;
    let http = client()?;
    emit_progress(app, profile_id, "metadata", 0, 1, &format!("Resolving Minecraft {mc_version}"));
    let manifest = get_json(&http, MOJANG_MANIFEST)?;
    let version_entry = manifest.get("versions").and_then(Value::as_array)
        .and_then(|versions| versions.iter().find(|v| v.get("id").and_then(Value::as_str) == Some(mc_version)))
        .ok_or_else(|| format!("Minecraft version {mc_version} is not present in Mojang's version manifest."))?;
    let version_url = version_entry.get("url").and_then(Value::as_str).ok_or("Mojang version metadata URL is missing.")?;
    let metadata = get_json(&http, version_url)?;
    let id = metadata.get("id").and_then(Value::as_str).unwrap_or(mc_version).to_string();
    let json_dir = version_dir(&game_dir, &id);
    fs::create_dir_all(&json_dir).map_err(|e| e.to_string())?;
    fs::write(json_dir.join(format!("{id}.json")), serde_json::to_vec_pretty(&metadata).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;

    let client_download = metadata.pointer("/downloads/client").ok_or("Mojang metadata has no client download for this version.")?;
    let client_url = client_download.get("url").and_then(Value::as_str).ok_or("Client download URL is missing.")?;
    let client_sha1 = client_download.get("sha1").and_then(Value::as_str);
    emit_progress(app, profile_id, "client", 0, 1, "Downloading Minecraft client");
    download_to(&http, client_url, &json_dir.join(format!("{id}.jar")), client_sha1)?;

    let libraries = metadata.get("libraries").and_then(Value::as_array).cloned().unwrap_or_default();
    let total_libraries = libraries.len() as u64;
    for (index, library) in libraries.iter().enumerate() {
        if let Some(native_name) = native_classifier(library) {
            if let Some(native) = library.pointer("/downloads/classifiers").and_then(|c| c.get(&native_name)) {
                if rule_allows(library) {
                    if let (Some(url), Some(path)) = (native.get("url").and_then(Value::as_str), native.get("path").and_then(Value::as_str)) {
                        let target = game_dir.join("libraries").join(safe_relative_path(path)?);
                        download_to(&http, url, &target, native.get("sha1").and_then(Value::as_str))?;
                        let bytes = fs::read(&target).map_err(|e| e.to_string())?;
                        let excludes = library.pointer("/extract/exclude").and_then(Value::as_array).map(|a| a.iter().filter_map(Value::as_str).map(str::to_string).collect::<Vec<_>>()).unwrap_or_default();
                        extract_native(&bytes, &json_dir.join("natives"), &excludes)?;
                    }
                }
            }
        }
        let _ = download_library(&http, &game_dir, library)?;
        emit_progress(app, profile_id, "libraries", index as u64 + 1, total_libraries, "Installing Minecraft libraries");
    }

    if let Some(asset_index) = metadata.get("assetIndex") {
        if let (Some(index_id), Some(url)) = (asset_index.get("id").and_then(Value::as_str), asset_index.get("url").and_then(Value::as_str)) {
            let index_path = game_dir.join("assets").join("indexes").join(format!("{index_id}.json"));
            download_to(&http, url, &index_path, asset_index.get("sha1").and_then(Value::as_str))?;
            let asset_json: Value = serde_json::from_slice(&fs::read(&index_path).map_err(|e| e.to_string())?)
                .map_err(|e| format!("Invalid asset index: {e}"))?;
            let objects = asset_json.get("objects").and_then(Value::as_object).ok_or("Asset index has no objects list.")?;
            let items: Vec<(String, String)> = objects.values().filter_map(|obj| {
                let hash = obj.get("hash")?.as_str()?;
                if hash.len() != 40 || !hash.chars().all(|c| c.is_ascii_hexdigit()) { return None; }
                Some((hash.to_string(), format!("https://resources.download.minecraft.net/{}/{}", &hash[0..2], hash)))
            }).collect();
            let total = items.len();
            let next = AtomicUsize::new(0);
            let done = AtomicUsize::new(0);
            let errors = Mutex::new(Vec::<String>::new());
            emit_progress(app, profile_id, "assets", 0, total as u64, "Downloading game assets");
            thread::scope(|scope| {
                for _ in 0..8 {
                    let http = http.clone();
                    let items = &items;
                    let next = &next;
                    let done = &done;
                    let errors = &errors;
                    let game_dir = &game_dir;
                    let app = app.clone();
                    let profile_id = profile_id.to_string();
                    scope.spawn(move || loop {
                        let index = next.fetch_add(1, Ordering::Relaxed);
                        if index >= items.len() { break; }
                        let (hash, url) = &items[index];
                        let target = game_dir.join("assets").join("objects").join(&hash[0..2]).join(hash);
                        if let Err(error) = download_to(&http, url, &target, Some(hash)) {
                            if let Ok(mut list) = errors.lock() { list.push(format!("asset {hash}: {error}")); }
                        }
                        let n = done.fetch_add(1, Ordering::Relaxed) + 1;
                        if n % 48 == 0 || n == items.len() {
                            emit_progress(&app, &profile_id, "assets", n as u64, items.len() as u64, "Downloading game assets");
                        }
                    });
                }
            });
            let failures = errors.into_inner().unwrap_or_default();
            if !failures.is_empty() {
                return Err(format!("{} game asset(s) failed to download. First error: {}", failures.len(), failures[0]));
            }
            if asset_json.get("map_to_resources").and_then(Value::as_bool) == Some(true) {
                let virtual_dir = game_dir.join("assets").join("virtual").join("legacy");
                fs::create_dir_all(&virtual_dir).map_err(|e| e.to_string())?;
                for (name, obj) in objects {
                    if let Some(hash) = obj.get("hash").and_then(Value::as_str) {
                        let source = game_dir.join("assets").join("objects").join(&hash[0..2]).join(hash);
                        let target = virtual_dir.join(safe_relative_path(name)?);
                        if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
                        if source.exists() && !target.exists() { let _ = fs::copy(source, target); }
                    }
                }
            }
        }
    }
    if let Some(logging) = metadata.pointer("/logging/client/file") {
        if let (Some(url), Some(id)) = (logging.get("url").and_then(Value::as_str), logging.get("id").and_then(Value::as_str)) {
            let path = game_dir.join("assets").join("log_configs").join(id);
            let _ = download_to(&http, url, &path, logging.get("sha1").and_then(Value::as_str));
        }
    }
    emit_progress(app, profile_id, "complete", 1, 1, &format!("Minecraft {mc_version} installed"));
    Ok(id)
}

fn java_executable(path: &Path) -> bool {
    if path.is_file() {
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("").to_ascii_lowercase();
        return name == "java.exe" || name == "java";
    }
    false
}

fn java_major(path: &Path) -> Option<u32> {
    let mut command = Command::new(path);
    command.arg("-version").stdout(Stdio::null()).stderr(Stdio::piped());
    hide_console_window(&mut command);
    let output = command.output().ok()?;
    let text = String::from_utf8_lossy(&output.stderr);
    let marker = text.split('"').nth(1)?;
    let first = marker.split('.').next()?;
    let major = first.parse::<u32>().ok()?;
    if major == 1 { marker.split('.').nth(1)?.parse().ok() } else { Some(major) }
}

fn runtime_candidates(app: &AppHandle) -> Vec<PathBuf> {
    let mut candidates = Vec::new();
    if let Ok(root) = root_dir(app) {
        let runtimes = root.join("runtimes");
        let mut stack = vec![runtimes];
        while let Some(dir) = stack.pop() {
            if let Ok(entries) = fs::read_dir(dir) {
                for entry in entries.flatten() {
                    let path = entry.path();
                    if path.is_dir() { stack.push(path); }
                    else if path.file_name().and_then(|n| n.to_str()).map(|n| n.eq_ignore_ascii_case("java.exe")).unwrap_or(false) { candidates.push(path); }
                }
            }
        }
    }
    if let Ok(home) = std::env::var("JAVA_HOME") { candidates.push(PathBuf::from(home).join("bin").join("java.exe")); }
    if let Ok(path) = std::env::var("PATH") {
        for dir in std::env::split_paths(&path) { candidates.push(dir.join("java.exe")); }
    }
    candidates
}

#[tauri::command]
pub fn detect_java_runtimes(app: AppHandle) -> Result<Vec<JavaRuntime>, String> {
    let mut found = Vec::new();
    let mut seen = HashSet::new();
    for path in runtime_candidates(&app) {
        if !java_executable(&path) || !seen.insert(path.clone()) { continue; }
        if let Some(major) = java_major(&path) {
            let source = if path.to_string_lossy().contains("runtimes") { "VOID CLIENT runtime" } else { "System Java" };
            found.push(JavaRuntime { major, path: path.to_string_lossy().to_string(), source: source.into() });
        }
    }
    found.sort_by_key(|r| r.major);
    Ok(found)
}

fn install_java_inner(app: &AppHandle, major: u32) -> Result<JavaRuntime, String> {
    if ![8, 17, 21, 25].contains(&major) { return Err("Supported Java runtime versions are 8, 17, 21 and 25.".into()); }
    let root = root_dir(app)?.join("runtimes").join(format!("temurin-{major}"));
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let http = client()?;
    let url = format!("https://api.adoptium.net/v3/binary/latest/{major}/ga/windows/x64/jre/hotspot/normal/eclipse?project=jre");
    emit_progress(app, "runtime", "java", 0, 1, &format!("Downloading Temurin Java {major}"));
    let bytes = download_bytes(&http, &url, 500 * 1024 * 1024)?;
    let mut archive = ZipArchive::new(Cursor::new(bytes)).map_err(|e| format!("Invalid Java runtime archive: {e}"))?;
    for index in 0..archive.len() {
        let mut file = archive.by_index(index).map_err(|e| e.to_string())?;
        let name = file.name().replace('\\', "/");
        if name.ends_with('/') { continue; }
        let relative = safe_relative_path(&name)?;
        let target = root.join(relative);
        if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
        let mut content = Vec::new();
        file.read_to_end(&mut content).map_err(|e| e.to_string())?;
        fs::write(target, content).map_err(|e| e.to_string())?;
    }
    let java = find_java_executable(&root).ok_or("Java archive was extracted, but java.exe was not found.")?;
    emit_progress(app, "runtime", "complete", 1, 1, &format!("Java {major} installed"));
    Ok(JavaRuntime { major, path: java.to_string_lossy().to_string(), source: "VOID CLIENT runtime".into() })
}

fn find_java_executable(root: &Path) -> Option<PathBuf> {
    let mut stack = vec![root.to_path_buf()];
    while let Some(dir) = stack.pop() {
        for entry in fs::read_dir(dir).ok()?.flatten() {
            let path = entry.path();
            if path.is_dir() { stack.push(path); }
            else if path.file_name().and_then(|n| n.to_str()).map(|n| n.eq_ignore_ascii_case("java.exe")).unwrap_or(false) { return Some(path); }
        }
    }
    None
}

#[tauri::command]
pub async fn install_java_runtime(app: AppHandle, major: u32) -> Result<JavaRuntime, String> {
    tauri::async_runtime::spawn_blocking(move || install_java_inner(&app, major)).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn list_minecraft_versions(kind: String) -> Result<Vec<GameVersion>, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let http = client()?;
        let manifest = get_json(&http, MOJANG_MANIFEST)?;
        let filter = kind.to_lowercase();
        let versions = manifest.get("versions").and_then(Value::as_array).ok_or("Mojang version manifest is malformed.")?;
        let mut output = Vec::new();
        for version in versions {
            let version_type = version.get("type").and_then(Value::as_str).unwrap_or("release");
            if filter != "all" && version_type != filter { continue; }
            if let Some(id) = version.get("id").and_then(Value::as_str) {
                output.push(GameVersion { id: id.to_string(), version_type: version_type.to_string(), release_time: version.get("releaseTime").and_then(Value::as_str).map(str::to_string), url: version.get("url").and_then(Value::as_str).unwrap_or("").to_string() });
            }
        }
        Ok(output)
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn install_vanilla(app: AppHandle, profile_id: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let mut profiles = load_profiles(&app)?;
        let index = profiles.iter().position(|p| p.id == profile_id).ok_or("Profile not found.")?;
        let mc = profiles[index].minecraft_version.clone();
        let id = install_vanilla_inner(&app, &profile_id, &mc)?;
        profiles[index].installed_version = Some(id.clone());
        save_profiles(&app, &profiles)?;
        let dir = locate_profile_dir(&app, &profile_id)?;
        fs::write(dir.join("profile.json"), serde_json::to_vec_pretty(&profiles[index]).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
        Ok(format!("Minecraft {} installed successfully.", mc))
    }).await.map_err(|e| e.to_string())?
}

fn required_java_for_version_id(version_id: &str) -> u32 {
    let parts: Vec<u32> = version_id.split('.').filter_map(|part| part.parse::<u32>().ok()).collect();
    if parts.len() >= 2 && parts[0] == 1 {
        let minor = parts[1];
        let patch = parts.get(2).copied().unwrap_or(0);
        if minor >= 21 || (minor == 20 && patch >= 5) { 21 }
        else if minor >= 17 { 17 }
        else { 8 }
    } else { 21 }
}

fn get_required_java(metadata: &Value) -> u32 {
    metadata.pointer("/javaVersion/majorVersion").and_then(Value::as_u64)
        .map(|value| value as u32)
        .or_else(|| metadata.get("id").and_then(Value::as_str).map(required_java_for_version_id))
        .unwrap_or(21)
}

fn get_java_for_profile(app: &AppHandle, profile: &StoredProfile, required: u32) -> Result<PathBuf, String> {
    if let Some(custom) = profile.java_path.as_deref() {
        let path = PathBuf::from(custom);
        if java_executable(&path) && java_major(&path).map(|v| v >= required).unwrap_or(false) { return Ok(path); }
        return Err(format!("The Java executable selected for this profile is missing or too old. Minecraft requires Java {required} or newer."));
    }
    let mut candidates = runtime_candidates(app);
    candidates.sort();
    for path in &candidates {
        if java_executable(path) && java_major(path).map(|v| v == required).unwrap_or(false) { return Ok(path.clone()); }
    }
    for path in &candidates {
        if java_executable(path) && java_major(path).map(|v| v >= required).unwrap_or(false) { return Ok(path.clone()); }
    }
    Err(format!("Java {required} or newer is required but was not found. Open the Java manager and install Java {required}.") )
}

fn collect_version_chain(game_dir: &Path, version_id: &str) -> Result<Vec<Value>, String> {
    let mut result = Vec::new();
    let mut current = version_id.to_string();
    let mut seen = HashSet::new();
    loop {
        if !seen.insert(current.clone()) { return Err("Minecraft version inheritance loop detected.".into()); }
        let path = version_dir(game_dir, &current).join(format!("{current}.json"));
        let bytes = fs::read(&path).map_err(|_| format!("Version {current} is not installed. Install it before launching."))?;
        let json: Value = serde_json::from_slice(&bytes).map_err(|e| format!("Invalid version metadata: {e}"))?;
        let parent = json.get("inheritsFrom").and_then(Value::as_str).map(str::to_string);
        result.push(json);
        if let Some(parent_id) = parent { current = parent_id; } else { break; }
        if result.len() > 5 { return Err("Version inheritance chain is unexpectedly deep.".into()); }
    }
    Ok(result)
}

fn arguments_from_json(value: Option<&Value>, placeholders: &HashMap<String, String>) -> Vec<String> {
    let mut output = Vec::new();
    let Some(items) = value.and_then(Value::as_array) else { return output; };
    for item in items {
        let raw_values: Vec<String> = if let Some(text) = item.as_str() {
            vec![text.to_string()]
        } else if item.is_object() && rule_allows(item) {
            match item.get("value") {
                Some(Value::String(text)) => vec![text.clone()],
                Some(Value::Array(values)) => values.iter().filter_map(Value::as_str).map(str::to_string).collect(),
                _ => Vec::new(),
            }
        } else { Vec::new() };
        for raw in raw_values {
            let mut text = raw;
            for (key, value) in placeholders { text = text.replace(&format!("${{{key}}}"), value); }
            output.push(text);
        }
    }
    output
}

fn xbox_auth_error(value: &Value, status: reqwest::StatusCode) -> String {
    let xerr = value.get("XErr").and_then(|v| v.as_i64().map(|n| n.to_string()).or_else(|| v.as_str().map(str::to_owned)));
    if let Some(code) = xerr {
        let message = match code.as_str() {
            "2148916233" => "This Microsoft account has no Xbox profile. Complete Xbox profile setup at xbox.com.",
            "2148916235" => "Xbox Live is unavailable for this account or region.",
            "2148916238" => "This account needs a parent or guardian to complete Xbox family setup.",
            _ => "Xbox security rejected this account. Check its age, privacy and Xbox profile settings.",
        };
        return format!("{message} (XErr {code}, HTTP {status}).");
    }
    let detail = ["errorMessage", "Message", "error_description", "error"]
        .iter().find_map(|key| value.get(*key).and_then(Value::as_str)).unwrap_or("No detail was returned.");
    format!("Xbox/Minecraft authentication failed (HTTP {status}): {detail}")
}

fn get_minecraft_session(_app: &AppHandle, account_id: &str, client_id: &str) -> Result<(String, String, String), String> {
    let entry = Entry::new("com.voidclient.launcher", account_id).map_err(|e| e.to_string())?;
    let saved_refresh = entry.get_password().map_err(|_| "No saved Microsoft session was found. Sign in again from Accounts.".to_string())?;
    let http = client()?;
    let token_response = http.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token")
        .header(reqwest::header::ACCEPT, "application/json")
        .form(&[("client_id", client_id), ("grant_type", "refresh_token"), ("refresh_token", saved_refresh.as_str()), ("scope", "XboxLive.signin offline_access")])
        .send().map_err(|e| format!("Could not renew Microsoft session: {e}"))?;
    let status = token_response.status();
    let token_json: Value = token_response.json().map_err(|e| e.to_string())?;
    if !status.is_success() { return Err(token_json.get("error_description").and_then(Value::as_str).unwrap_or("Microsoft session expired. Sign in again.").to_string()); }
    let microsoft_token = token_json.get("access_token").and_then(Value::as_str).ok_or("Microsoft did not return an access token.")?;
    let new_refresh = token_json.get("refresh_token").and_then(Value::as_str).unwrap_or(saved_refresh.as_str());
    let xbox = http.post("https://user.auth.xboxlive.com/user/authenticate")
        .header(reqwest::header::ACCEPT, "application/json")
        .json(&json!({
        "Properties": { "AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": format!("d={microsoft_token}") },
        "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"
    })).send().map_err(|e| e.to_string())?;
    let xbox_status = xbox.status(); let xbox_json: Value = xbox.json().map_err(|e| e.to_string())?;
    if !xbox_status.is_success() { return Err(xbox_auth_error(&xbox_json, xbox_status)); }
    let xbox_token = xbox_json.get("Token").and_then(Value::as_str).ok_or("Xbox Live token is missing.")?;
    let xsts = http.post("https://xsts.auth.xboxlive.com/xsts/authorize")
        .header(reqwest::header::ACCEPT, "application/json")
        .json(&json!({
        "Properties": { "SandboxId": "RETAIL", "UserTokens": [xbox_token] },
        "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"
    })).send().map_err(|e| e.to_string())?;
    let xsts_status = xsts.status(); let xsts_json: Value = xsts.json().map_err(|e| e.to_string())?;
    if !xsts_status.is_success() { return Err(xbox_auth_error(&xsts_json, xsts_status)); }
    let xsts_token = xsts_json.get("Token").and_then(Value::as_str).ok_or("Xbox XSTS token is missing.")?;
    let user_hash = xsts_json.pointer("/DisplayClaims/xui/0/uhs").and_then(Value::as_str).ok_or("Xbox user hash is missing.")?;
    let xuid = xsts_json.pointer("/DisplayClaims/xui/0/xid").and_then(Value::as_str).unwrap_or("");
    let minecraft = http.post("https://api.minecraftservices.com/authentication/login_with_xbox")
        .header(reqwest::header::ACCEPT, "application/json")
        .json(&json!({ "identityToken": format!("XBL3.0 x={user_hash};{xsts_token}") }))
        .send().map_err(|e| e.to_string())?;
    let mc_status = minecraft.status(); let mc_json: Value = minecraft.json().map_err(|e| e.to_string())?;
    if !mc_status.is_success() { return Err(xbox_auth_error(&mc_json, mc_status)); }
    let mc_token = mc_json.get("access_token").and_then(Value::as_str).ok_or("Minecraft access token is missing.")?.to_string();
    let profile = http.get("https://api.minecraftservices.com/minecraft/profile").bearer_auth(&mc_token)
        .send().map_err(|e| e.to_string())?;
    if !profile.status().is_success() {
        let status = profile.status();
        let detail = profile.text().unwrap_or_default();
        return Err(if status == reqwest::StatusCode::NOT_FOUND {
            "This Microsoft account has no Minecraft Java profile. Check that it owns Java Edition and has completed profile setup.".into()
        } else if status == reqwest::StatusCode::FORBIDDEN {
            format!("Minecraft Services returned HTTP 403. The app registration may need Minecraft Services API approval, or the account may not own Java Edition. {}", detail.chars().take(400).collect::<String>())
        } else {
            format!("Minecraft profile lookup failed (HTTP {status}). {}", detail.chars().take(400).collect::<String>())
        });
    }
    let profile_json: Value = profile.json().map_err(|e| e.to_string())?;
    let actual_id = profile_json.get("id").and_then(Value::as_str).ok_or("Minecraft UUID missing.")?;
    if actual_id != account_id { return Err("The refreshed session belongs to a different Minecraft account.".into()); }
    if let Ok(_) = entry.set_password(new_refresh) { /* keep the latest refresh token */ }
    Ok((mc_token, xuid.to_string(), actual_id.to_string()))
}

#[tauri::command]
fn emit_launch_log(app: &AppHandle, profile_id: &str, profile_name: &str, stream: &str, message: &str) {
    let _ = app.emit("void-launch-log", json!({
        "profileId": profile_id,
        "profileName": profile_name,
        "stream": stream,
        "message": message,
        "timestamp": now_ms()
    }));
}

fn pump_game_output<R: Read + Send + 'static>(
    app: AppHandle,
    profile_id: String,
    profile_name: String,
    stream: &'static str,
    reader: R,
    log_path: PathBuf,
) {
    thread::spawn(move || {
        let mut log_file = fs::OpenOptions::new().create(true).append(true).open(log_path).ok();
        for line in BufReader::new(reader).lines() {
            match line {
                Ok(line) => {
                    if let Some(file) = log_file.as_mut() { let _ = writeln!(file, "{line}"); }
                    emit_launch_log(&app, &profile_id, &profile_name, stream, &line);
                }
                Err(error) => {
                    emit_launch_log(&app, &profile_id, &profile_name, "warning", &format!("Could not read {stream}: {error}"));
                    break;
                }
            }
        }
    });
}

#[tauri::command]
pub async fn launch_profile(app: AppHandle, profile_id: String) -> Result<String, String> {
    let failure_app = app.clone();
    let failure_profile_id = profile_id.clone();
    let result = tauri::async_runtime::spawn_blocking(move || {
        emit_launch_log(&app, &profile_id, "Minecraft", "system", "Preparing Minecraft launch…");
        let mut profiles = load_profiles(&app)?;
        let profile = profiles.iter_mut().find(|p| p.id == profile_id).ok_or("Profile not found.")?;
        let profile_name = profile.name.clone();
        emit_launch_log(&app, &profile_id, &profile_name, "system", "Checking profile installation and Java runtime…");
        let game_dir = locate_profile_dir(&app, &profile_id)?;
        if profile.loader != "Vanilla" && profile.installed_version.is_none() {
            return Err(format!("{} is selected for this profile but is not installed yet. Install the loader first.", profile.loader));
        }
        let version_id = profile.installed_version.clone().unwrap_or_else(|| profile.minecraft_version.clone());
        let chain = collect_version_chain(&game_dir, &version_id)?;
        let leaf = chain.first().ok_or("Installed version metadata is missing.")?;
        let base = chain.last().ok_or("Base game metadata is missing.")?;
        let required_java = get_required_java(base);
        let java = get_java_for_profile(&app, profile, required_java)?;
        emit_launch_log(&app, &profile_id, &profile_name, "system", &format!("Using Java {} at {}", required_java, java.display()));
        let settings: Value = if settings_file(&app)?.exists() { serde_json::from_slice(&fs::read(settings_file(&app)?).map_err(|e| e.to_string())?).unwrap_or(Value::Null) } else { Value::Null };
        let accounts: Vec<Value> = if accounts_file(&app)?.exists() { serde_json::from_slice(&fs::read(accounts_file(&app)?).map_err(|e| e.to_string())?).unwrap_or_default() } else { Vec::new() };
        let selected = settings.get("selectedAccountId").and_then(Value::as_str)
            .or_else(|| accounts.first().and_then(|a| a.get("id").and_then(Value::as_str)))
            .ok_or("Add or select a Microsoft or Offline account on the Accounts page before launching.")?;
        let account = accounts.iter().find(|a| a.get("id").and_then(Value::as_str) == Some(selected)).ok_or("The selected Minecraft account was not found. Reconnect it from Accounts.")?;
        let username = account.get("name").and_then(Value::as_str).ok_or("Minecraft username is missing.")?.to_string();
        let account_type = account.get("accountType").and_then(Value::as_str).unwrap_or("microsoft");
        let (access_token, xuid, uuid, user_type, client_id) = if account_type == "offline" {
            let uuid = account.get("uuid").and_then(Value::as_str)
                .ok_or("Offline account UUID is missing. Remove and add this offline account again.")?.to_string();
            emit_launch_log(&app, &profile_id, &profile_name, "warning", &format!("Launching as local offline identity '{username}'. This is supported for single-player and servers configured for offline-mode; authenticated online servers will reject it."));
            ("0".to_string(), String::new(), uuid, "legacy".to_string(), String::new())
        } else {
            emit_launch_log(&app, &profile_id, &profile_name, "system", &format!("Refreshing Microsoft session for {username}…"));
            let client_id = crate::microsoft_client_id(&app)?;
            let (access_token, xuid, uuid) = get_minecraft_session(&app, selected, &client_id)?;
            emit_launch_log(&app, &profile_id, &profile_name, "system", "Microsoft and Minecraft account verified.");
            (access_token, xuid, uuid, "msa".to_string(), client_id)
        };
        let mut classpath = Vec::new();
        for version in chain.iter().rev() {
            if let Some(libraries) = version.get("libraries").and_then(Value::as_array) {
                for lib in libraries {
                    if !rule_allows(lib) { continue; }
                    if let Some(artifact) = lib.pointer("/downloads/artifact") {
                        if let Some(path) = artifact.get("path").and_then(Value::as_str) { classpath.push(game_dir.join("libraries").join(safe_relative_path(path)?)); }
                    } else if let Some(name) = lib.get("name").and_then(Value::as_str) {
                        let (_, relative) = maven_url(lib.get("url").and_then(Value::as_str).unwrap_or("https://libraries.minecraft.net/"), name)?;
                        classpath.push(game_dir.join("libraries").join(relative));
                    }
                }
            }
        }
        let client_jar = version_dir(&game_dir, &profile.minecraft_version).join(format!("{}.jar", profile.minecraft_version));
        if !client_jar.exists() { return Err("Minecraft client JAR is missing. Reinstall the game version.".into()); }
        classpath.push(client_jar);
        let missing_libraries: Vec<String> = classpath.iter().filter(|path| !path.exists())
            .map(|path| path.to_string_lossy().to_string()).collect();
        if !missing_libraries.is_empty() {
            return Err(format!("{} runtime library file(s) are missing. Reinstall this profile before launching. First missing file: {}", missing_libraries.len(), missing_libraries[0]));
        }
        let classpath = classpath.into_iter().map(|path| path.to_string_lossy().to_string()).collect::<Vec<_>>().join(";");
        let natives_dir = version_dir(&game_dir, &profile.minecraft_version).join("natives");
        fs::create_dir_all(&natives_dir).map_err(|e| e.to_string())?;
        let http = client()?;
        for version in &chain {
            if let Some(libraries) = version.get("libraries").and_then(Value::as_array) {
                for library in libraries {
                    if !rule_allows(library) { continue; }
                    if let Some(classifier_name) = native_classifier(library) {
                        if let Some(native) = library.pointer("/downloads/classifiers").and_then(|items| items.get(&classifier_name)) {
                            if let (Some(url), Some(path)) = (native.get("url").and_then(Value::as_str), native.get("path").and_then(Value::as_str)) {
                                let target = game_dir.join("libraries").join(safe_relative_path(path)?);
                                download_to(&http, url, &target, native.get("sha1").and_then(Value::as_str))?;
                                let native_bytes = fs::read(&target).map_err(|e| e.to_string())?;
                                let excludes = library.pointer("/extract/exclude").and_then(Value::as_array)
                                    .map(|items| items.iter().filter_map(Value::as_str).map(str::to_string).collect::<Vec<_>>())
                                    .unwrap_or_default();
                                extract_native(&native_bytes, &natives_dir, &excludes)?;
                            }
                        }
                    }
                }
            }
        }
        let asset_index = base.pointer("/assetIndex/id").and_then(Value::as_str).unwrap_or(&profile.minecraft_version);
        let main_class = leaf.get("mainClass").or_else(|| base.get("mainClass")).and_then(Value::as_str).ok_or("Minecraft main class is missing.")?;
        let mut placeholders = HashMap::new();
        placeholders.insert("natives_directory".into(), natives_dir.to_string_lossy().to_string());
        placeholders.insert("launcher_name".into(), "VOID-CLIENT".into());
        placeholders.insert("launcher_version".into(), env!("CARGO_PKG_VERSION").into());
        placeholders.insert("classpath".into(), classpath.clone());
        placeholders.insert("classpath_separator".into(), ";".into());
        placeholders.insert("library_directory".into(), game_dir.join("libraries").to_string_lossy().to_string());
        placeholders.insert("auth_player_name".into(), username.clone());
        placeholders.insert("version_name".into(), version_id.clone());
        placeholders.insert("game_directory".into(), game_dir.to_string_lossy().to_string());
        placeholders.insert("assets_root".into(), game_dir.join("assets").to_string_lossy().to_string());
        placeholders.insert("assets_index_name".into(), asset_index.to_string());
        placeholders.insert("auth_uuid".into(), uuid.clone());
        placeholders.insert("auth_access_token".into(), access_token);
        placeholders.insert("user_type".into(), user_type.clone());
        placeholders.insert("user_properties".into(), "{}".into());
        placeholders.insert("version_type".into(), base.get("type").and_then(Value::as_str).unwrap_or("release").to_string());
        placeholders.insert("clientid".into(), client_id.clone());
        placeholders.insert("auth_xuid".into(), xuid);
        placeholders.insert("demo".into(), "false".into());
        placeholders.insert("quickPlayPath".into(), "".into());
        placeholders.insert("quickPlaySingleplayer".into(), "".into());
        placeholders.insert("quickPlayMultiplayer".into(), "".into());
        placeholders.insert("quickPlayRealms".into(), "".into());
        placeholders.insert("resolution_width".into(), profile.game_width.to_string());
        placeholders.insert("resolution_height".into(), profile.game_height.to_string());
        let mut args: Vec<String> = vec!["-Xms512M".into(), format!("-Xmx{}G", profile.ram_gb)];
        if !profile.jvm_args.trim().is_empty() { args.extend(profile.jvm_args.split_whitespace().map(str::to_string)); }
        if let Some(logging) = leaf.pointer("/logging/client/file/id").and_then(Value::as_str) {
            placeholders.insert("path".into(), game_dir.join("assets").join("log_configs").join(logging).to_string_lossy().to_string());
        }
        if let Some(logging) = leaf.pointer("/logging/client/argument").and_then(Value::as_str) {
            let mut argument = logging.to_string();
            for (key, value) in &placeholders { argument = argument.replace(&format!("${{{key}}}"), value); }
            args.push(argument);
        }
        let leaf_jvm = arguments_from_json(leaf.pointer("/arguments/jvm"), &placeholders);
        let base_jvm = arguments_from_json(base.pointer("/arguments/jvm"), &placeholders);
        let mut metadata_jvm = if !leaf_jvm.is_empty() { leaf_jvm } else { base_jvm };
        if !metadata_jvm.iter().any(|a| a == "-cp" || a == "-classpath") {
            metadata_jvm.push("-cp".into()); metadata_jvm.push(classpath);
        }
        args.extend(metadata_jvm);
        args.push(main_class.to_string());
        let game_arguments = arguments_from_json(leaf.pointer("/arguments/game"), &placeholders);
        let game_arguments = if !game_arguments.is_empty() { game_arguments } else { arguments_from_json(base.pointer("/arguments/game"), &placeholders) };
        if !game_arguments.is_empty() {
            args.extend(game_arguments);
        } else if let Some(legacy) = leaf.get("minecraftArguments").or_else(|| base.get("minecraftArguments")).and_then(Value::as_str) {
            for part in legacy.split_whitespace() {
                let mut arg = part.to_string();
                for (key, value) in &placeholders { arg = arg.replace(&format!("${{{key}}}"), value); }
                args.push(arg);
            }
        } else {
            args.extend(vec!["--username".into(), username, "--version".into(), version_id, "--gameDir".into(), game_dir.to_string_lossy().to_string(), "--assetsDir".into(), game_dir.join("assets").to_string_lossy().to_string(), "--assetIndex".into(), asset_index.to_string(), "--uuid".into(), uuid, "--accessToken".into(), placeholders.get("auth_access_token").cloned().unwrap_or_default(), "--userType".into(), user_type.clone()]);
        }
        if profile.fullscreen && !args.iter().any(|arg| arg == "--fullscreen") { args.push("--fullscreen".into()); }
        emit_launch_log(&app, &profile_id, &profile_name, "system", "Starting Java process with the resolved Minecraft arguments…");
        let mut java_command = Command::new(&java);
        java_command.args(args).current_dir(&game_dir)
            .stdout(Stdio::piped()).stderr(Stdio::piped());
        hide_console_window(&mut java_command);
        let mut child = java_command.spawn()
            .map_err(|e| format!("Could not start Minecraft with {}: {e}", java.display()))?;
        let pid = child.id();
        let logs_dir = game_dir.join("logs");
        fs::create_dir_all(&logs_dir).map_err(|e| e.to_string())?;
        if let Some(stdout) = child.stdout.take() {
            pump_game_output(app.clone(), profile_id.clone(), profile_name.clone(), "stdout", stdout, logs_dir.join("launcher-stdout.log"));
        }
        if let Some(stderr) = child.stderr.take() {
            pump_game_output(app.clone(), profile_id.clone(), profile_name.clone(), "stderr", stderr, logs_dir.join("launcher-stderr.log"));
        }
        profile.last_played = Some(now_ms());
        update_profile(&app, profile)?;
        emit_launch_log(&app, &profile_id, &profile_name, "system", &format!("Minecraft process started successfully (PID {pid})."));
        let monitor_app = app.clone();
        let monitor_profile_id = profile_id.clone();
        let monitor_profile_name = profile_name.clone();
        thread::spawn(move || {
            match child.wait() {
                Ok(status) if status.success() => emit_launch_log(&monitor_app, &monitor_profile_id, &monitor_profile_name, "system", &format!("Minecraft closed normally (exit code {}).", status.code().map(|c| c.to_string()).unwrap_or_else(|| "unknown".into()))),
                Ok(status) => emit_launch_log(&monitor_app, &monitor_profile_id, &monitor_profile_name, "error", &format!("Minecraft exited with code {}.", status.code().map(|c| c.to_string()).unwrap_or_else(|| "unknown".into()))),
                Err(error) => emit_launch_log(&monitor_app, &monitor_profile_id, &monitor_profile_name, "error", &format!("Could not wait for Minecraft process: {error}")),
            }
        });
        Ok(format!("Minecraft started (process {pid}). Live output is available in Console."))
    }).await.map_err(|e| e.to_string())?;
    if let Err(error) = &result {
        emit_launch_log(&failure_app, &failure_profile_id, "Minecraft", "error", error);
    }
    result
}


#[tauri::command]
pub async fn diagnose_profile(app: AppHandle, profile_id: String) -> Result<String, String> {
    let failure_app = app.clone();
    let failure_profile_id = profile_id.clone();
    let result = tauri::async_runtime::spawn_blocking(move || {
        emit_launch_log(&app, &profile_id, "Minecraft", "system", "Running local launch checks. This does not require a Microsoft sign-in.");
        let profiles = load_profiles(&app)?;
        let profile = profiles.iter().find(|p| p.id == profile_id).ok_or("Profile not found.")?;
        let profile_name = profile.name.clone();
        let game_dir = locate_profile_dir(&app, &profile_id)?;
        if profile.loader != "Vanilla" && profile.installed_version.is_none() {
            return Err(format!("{} is selected but its loader is not installed yet.", profile.loader));
        }
        let version_id = profile.installed_version.clone().unwrap_or_else(|| profile.minecraft_version.clone());
        let chain = collect_version_chain(&game_dir, &version_id)?;
        let leaf = chain.first().ok_or("Installed version metadata is missing.")?;
        let base = chain.last().ok_or("Base Minecraft metadata is missing.")?;
        let java_required = get_required_java(base);
        emit_launch_log(&app, &profile_id, &profile_name, "system", &format!("Checking Java {java_required}…"));
        let java = get_java_for_profile(&app, profile, java_required)?;
        let mut java_command = Command::new(&java);
        java_command.arg("-version").stdout(Stdio::piped()).stderr(Stdio::piped());
        hide_console_window(&mut java_command);
        let java_output = java_command.output()
            .map_err(|e| format!("Could not run Java at {}: {e}", java.display()))?;
        for line in String::from_utf8_lossy(&java_output.stdout).lines() {
            emit_launch_log(&app, &profile_id, &profile_name, "stdout", line);
        }
        for line in String::from_utf8_lossy(&java_output.stderr).lines() {
            emit_launch_log(&app, &profile_id, &profile_name, "stderr", line);
        }
        if !java_output.status.success() { return Err(format!("Java returned exit code {:?}.", java_output.status.code())); }
        emit_launch_log(&app, &profile_id, &profile_name, "system", "Java runtime check passed.");

        let client_jar = version_dir(&game_dir, &profile.minecraft_version).join(format!("{}.jar", profile.minecraft_version));
        if !client_jar.is_file() { return Err(format!("Minecraft client JAR is missing: {}. Reinstall this profile.", client_jar.display())); }
        emit_launch_log(&app, &profile_id, &profile_name, "system", "Minecraft client JAR is present.");

        let mut missing = Vec::new();
        for version in chain.iter().rev() {
            if let Some(libraries) = version.get("libraries").and_then(Value::as_array) {
                for library in libraries {
                    if !rule_allows(library) { continue; }
                    let path = if let Some(relative) = library.pointer("/downloads/artifact/path").and_then(Value::as_str) {
                        Some(game_dir.join("libraries").join(safe_relative_path(relative)?))
                    } else if let Some(name) = library.get("name").and_then(Value::as_str) {
                        let (_, relative) = maven_url(library.get("url").and_then(Value::as_str).unwrap_or("https://libraries.minecraft.net/"), name)?;
                        Some(game_dir.join("libraries").join(relative))
                    } else { None };
                    if let Some(path) = path { if !path.is_file() { missing.push(path); } }
                }
            }
        }
        if !missing.is_empty() {
            return Err(format!("{} required library file(s) are missing. First missing: {}", missing.len(), missing[0].display()));
        }
        if leaf.get("mainClass").or_else(|| base.get("mainClass")).and_then(Value::as_str).is_none() {
            return Err("Minecraft main class is missing from the installed metadata.".into());
        }
        emit_launch_log(&app, &profile_id, &profile_name, "system", "Minecraft metadata and required libraries passed local checks.");
        emit_launch_log(&app, &profile_id, &profile_name, "warning", "This check does not start the game. Sign in with a Microsoft account that owns Minecraft Java Edition, then press PLAY for a real launch.");
        Ok("Local setup checks passed. Microsoft sign-in is required for an actual game launch.".into())
    }).await.map_err(|e| e.to_string())?;
    if let Err(error) = &result {
        emit_launch_log(&failure_app, &failure_profile_id, "Minecraft", "error", error);
    }
    result
}

fn install_fabric_or_quilt_inner(app: &AppHandle, profile_id: &str, loader: &str, requested_version: Option<&str>) -> Result<String, String> {
    let mut profile_list = load_profiles(app)?;
    let profile_index = profile_list.iter().position(|p| p.id == profile_id).ok_or("Profile not found.")?;
    let mc = profile_list[profile_index].minecraft_version.clone();
    install_vanilla_inner(app, profile_id, &mc)?;
    let http = client()?;
    let base = if loader == "Fabric" { "https://meta.fabricmc.net/v2" } else { "https://meta.quiltmc.org/v3" };
    let versions_url = format!("{base}/versions/loader/{mc}");
    let versions = get_json(&http, &versions_url)?;
    let entries = versions.as_array().ok_or("Loader metadata did not return a version list.")?;
    let selected = if let Some(requested) = requested_version {
        entries.iter().find(|entry| {
            entry.get("loader").and_then(|value| value.get("version")).and_then(Value::as_str) == Some(requested)
        }).ok_or_else(|| format!("{loader} {requested} is not available for Minecraft {mc}."))?
    } else {
        entries.iter().find(|entry| {
            entry.get("loader").and_then(|l| l.get("stable")).and_then(Value::as_bool).unwrap_or(true)
        }).or_else(|| entries.first()).ok_or_else(|| format!("No {loader} loader is available for Minecraft {mc}."))?
    };
    let loader_version = selected.get("loader").and_then(|v| v.get("version")).and_then(Value::as_str)
        .or_else(|| selected.get("version").and_then(Value::as_str)).ok_or("Loader version metadata is missing.")?;
    let profile_url = format!("{base}/versions/loader/{mc}/{loader_version}/profile/json");
    let mut loader_meta = get_json(&http, &profile_url)?;
    let version_id = loader_meta.get("id").and_then(Value::as_str).map(str::to_string)
        .unwrap_or_else(|| format!("{}-loader-{loader_version}-{mc}", loader.to_lowercase()));
    if !safe_version_id(&version_id) { return Err("Loader metadata returned an invalid version identifier.".into()); }
    loader_meta["id"] = Value::String(version_id.clone());
    loader_meta["inheritsFrom"] = Value::String(mc.clone());
    let libs = loader_meta.get("libraries").and_then(Value::as_array).cloned().unwrap_or_default();
    for (idx, lib) in libs.iter().enumerate() {
        let name = lib.get("name").and_then(Value::as_str).ok_or("Loader library has no Maven coordinate.")?;
        let url = lib.get("url").and_then(Value::as_str).unwrap_or(if loader == "Fabric" { "https://maven.fabricmc.net/" } else { "https://maven.quiltmc.org/repository/release/" });
        let (download_url, relative) = maven_url(url, name)?;
        let target = locate_profile_dir(app, profile_id)?.join("libraries").join(relative);
        if !target.exists() { download_to(&http, &download_url, &target, None)?; }
        emit_progress(app, profile_id, "loader", idx as u64 + 1, libs.len() as u64, &format!("Installing {loader} libraries"));
    }
    let game_dir = locate_profile_dir(app, profile_id)?;
    let dir = version_dir(&game_dir, &version_id);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    fs::write(dir.join(format!("{version_id}.json")), serde_json::to_vec_pretty(&loader_meta).map_err(|e| e.to_string())?)
        .map_err(|e| e.to_string())?;
    profile_list[profile_index].installed_version = Some(version_id.clone());
    profile_list[profile_index].loader = loader.to_string();
    save_profiles(app, &profile_list)?;
    fs::write(game_dir.join("profile.json"), serde_json::to_vec_pretty(&profile_list[profile_index]).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    Ok(format!("{loader} {loader_version} installed for Minecraft {mc}."))
}

fn compare_numeric_versions(left: &str, right: &str) -> std::cmp::Ordering {
    let numbers = |value: &str| value.split(|ch: char| !ch.is_ascii_digit())
        .filter(|part| !part.is_empty())
        .filter_map(|part| part.parse::<u64>().ok())
        .collect::<Vec<_>>();
    numbers(left).cmp(&numbers(right)).then_with(|| left.cmp(right))
}

fn get_maven_versions(http: &Client, url: &str) -> Result<Vec<String>, String> {
    let text = http.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?.text().map_err(|e| e.to_string())?;
    let mut output = Vec::new();
    let mut rest = text.as_str();
    while let Some(start) = rest.find("<version>") {
        rest = &rest[start + 9..];
        if let Some(end) = rest.find("</version>") { output.push(rest[..end].trim().to_string()); rest = &rest[end + 10..]; } else { break; }
    }
    Ok(output)
}

fn ensure_java_for_installer(app: &AppHandle, profile: &StoredProfile) -> Result<PathBuf, String> {
    let game_dir = locate_profile_dir(app, &profile.id)?;
    let metadata_path = version_dir(&game_dir, &profile.minecraft_version).join(format!("{}.json", profile.minecraft_version));
    let required = fs::read(&metadata_path).ok()
        .and_then(|bytes| serde_json::from_slice::<Value>(&bytes).ok())
        .map(|metadata| get_required_java(&metadata))
        .unwrap_or_else(|| required_java_for_version_id(&profile.minecraft_version));
    if let Some(custom) = profile.java_path.as_deref() {
        let path = PathBuf::from(custom);
        if java_executable(&path) && java_major(&path).map(|major| major >= required).unwrap_or(false) { return Ok(path); }
    }
    for java in runtime_candidates(app) {
        if java_executable(&java) && java_major(&java).map(|major| major >= required).unwrap_or(false) {
            return Ok(java);
        }
    }
    let runtime_major = [8, 17, 21, 25].into_iter().find(|major| *major >= required)
        .ok_or_else(|| format!("Minecraft requires Java {required}, but VOID CLIENT currently offers Java 8, 17, 21 and 25."))?;
    let runtime = install_java_inner(app, runtime_major)?;
    Ok(PathBuf::from(runtime.path))
}

fn install_forge_family_inner(app: &AppHandle, profile_id: &str, loader: &str, requested_version: Option<&str>) -> Result<String, String> {
    let mut profiles = load_profiles(app)?;
    let profile_index = profiles.iter().position(|p| p.id == profile_id).ok_or("Profile not found.")?;
    let mc = profiles[profile_index].minecraft_version.clone();
    install_vanilla_inner(app, profile_id, &mc)?;
    let http = client()?;
    let (metadata_url, prefix, base, artifact_prefix) = if loader == "Forge" {
        ("https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml", format!("{mc}-"), "https://maven.minecraftforge.net/net/minecraftforge/forge/", "forge")
    } else {
        let parts: Vec<&str> = mc.split('.').collect();
        if parts.len() < 2 { return Err("Could not map this Minecraft version to a NeoForge release line.".into()); }
        let major = parts[1];
        let minor = parts.get(2).copied().unwrap_or("0");
        let prefix = format!("{major}.{minor}.");
        ("https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml", prefix, "https://maven.neoforged.net/releases/net/neoforged/neoforge/", "neoforge")
    };
    let mut versions = get_maven_versions(&http, metadata_url)?;
    versions.retain(|v| v.starts_with(&prefix));
    versions.sort_by(|a, b| compare_numeric_versions(a, b));
    let selected = if let Some(requested) = requested_version {
        let wanted = if loader == "Forge" { format!("{mc}-{requested}") } else { requested.to_string() };
        versions.iter().find(|version| version.as_str() == wanted.as_str()).cloned()
            .ok_or_else(|| format!("{loader} {requested} is not available for Minecraft {mc}."))?
    } else {
        versions.pop().ok_or_else(|| format!("No {loader} installer version was found for Minecraft {mc}."))?
    };
    let installer_name = format!("{artifact_prefix}-{selected}-installer.jar");
    let installer_url = format!("{base}{selected}/{installer_name}");
    let work = root_dir(app)?.join("installers");
    fs::create_dir_all(&work).map_err(|e| e.to_string())?;
    let installer = work.join(&installer_name);
    download_to(&http, &installer_url, &installer, None)?;
    let java = ensure_java_for_installer(app, &profiles[profile_index])?;
    let game_dir = locate_profile_dir(app, profile_id)?;
    emit_progress(app, profile_id, "loader", 0, 1, &format!("Running {loader} installer"));
    let installer_flag = if loader == "NeoForge" { "--install-client" } else { "--installClient" };
    let mut installer_command = Command::new(&java);
    installer_command.arg("-jar").arg(&installer).arg(installer_flag).arg(&game_dir)
        .current_dir(&game_dir).stdout(Stdio::piped()).stderr(Stdio::piped());
    hide_console_window(&mut installer_command);
    let output = installer_command.output()
        .map_err(|e| format!("Could not run {loader} installer: {e}"))?;
    if !output.status.success() {
        let message = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);
        return Err(format!("{loader} installer failed ({}). {}", output.status, if !message.trim().is_empty() { message.to_string() } else { stdout.to_string() }));
    }
    let mut chosen: Option<String> = None;
    for entry in fs::read_dir(game_dir.join("versions")).map_err(|e| e.to_string())?.flatten() {
        let path = entry.path();
        if !path.is_dir() { continue; }
        let id = path.file_name().and_then(|s| s.to_str()).unwrap_or("").to_string();
        if !id.to_lowercase().contains(&loader.to_lowercase()) { continue; }
        let json_path = path.join(format!("{id}.json"));
        if let Ok(data) = fs::read(&json_path) {
            if let Ok(value) = serde_json::from_slice::<Value>(&data) {
                if value.get("inheritsFrom").and_then(Value::as_str) == Some(mc.as_str()) { chosen = Some(id); }
            }
        }
    }
    let version_id = chosen.ok_or_else(|| format!("{loader} installer completed but did not create a detectable client version. Check the installer output and try again."))?;
    profiles[profile_index].installed_version = Some(version_id.clone());
    profiles[profile_index].loader = loader.into();
    save_profiles(app, &profiles)?;
    fs::write(game_dir.join("profile.json"), serde_json::to_vec_pretty(&profiles[profile_index]).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    emit_progress(app, profile_id, "complete", 1, 1, &format!("{loader} installed"));
    Ok(format!("{loader} {selected} installed for Minecraft {mc}."))
}

#[tauri::command]
pub async fn install_profile_loader(app: AppHandle, profile_id: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let profile = load_profiles(&app)?.into_iter().find(|p| p.id == profile_id).ok_or("Profile not found.")?;
        match profile.loader.as_str() {
            "Vanilla" => {
                let installed = install_vanilla_inner(&app, &profile_id, &profile.minecraft_version)?;
                let mut profiles = load_profiles(&app)?;
                if let Some(index) = profiles.iter().position(|p| p.id == profile_id) {
                    profiles[index].installed_version = Some(installed);
                    save_profiles(&app, &profiles)?;
                    let dir = locate_profile_dir(&app, &profile_id)?;
                    fs::write(dir.join("profile.json"), serde_json::to_vec_pretty(&profiles[index]).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
                }
                Ok("Vanilla Minecraft is installed.".into())
            },
            "Fabric" | "Quilt" => install_fabric_or_quilt_inner(&app, &profile_id, &profile.loader, None),
            "Forge" | "NeoForge" => install_forge_family_inner(&app, &profile_id, &profile.loader, None),
            _ => Err("Unsupported mod loader.".into()),
        }
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub fn get_engine_status(app: AppHandle, profile_id: String) -> Result<EngineStatus, String> {
    let profile = load_profiles(&app)?.into_iter().find(|p| p.id == profile_id).ok_or("Profile not found.")?;
    let game_dir = locate_profile_dir(&app, &profile_id)?;
    let version_id = profile.installed_version.clone().unwrap_or_else(|| profile.minecraft_version.clone());
    let path = version_dir(&game_dir, &version_id).join(format!("{version_id}.json"));
    let installed = if profile.loader == "Vanilla" { path.exists() }
        else { profile.installed_version.as_ref().map(|_| path.exists()).unwrap_or(false) };
    let required = if installed {
        collect_version_chain(&game_dir, &version_id).ok()
            .and_then(|chain| chain.last().map(get_required_java))
            .unwrap_or_else(|| required_java_for_version_id(&profile.minecraft_version))
    } else {
        required_java_for_version_id(&profile.minecraft_version)
    };
    let runtimes = detect_java_runtimes(app.clone())?;
    let custom_java_found = profile.java_path.as_deref().map(Path::new)
        .and_then(|path| java_major(path)).map(|major| major >= required).unwrap_or(false);
    Ok(EngineStatus { installed, game_version: profile.minecraft_version, installed_version: profile.installed_version, java_required: required, java_found: custom_java_found || runtimes.iter().any(|r| r.major >= required), loader: profile.loader })
}

fn curseforge_key() -> Result<String, String> {
    Entry::new("com.voidclient.launcher", "curseforge-api-key").map_err(|e| e.to_string())?.get_password()
        .map_err(|_| "Save a CurseForge API key in VOID CLIENT Settings > Integrations first.".into())
}

#[tauri::command]
pub fn set_curseforge_api_key(key: String) -> Result<(), String> {
    if key.trim().len() < 12 { return Err("That does not look like a CurseForge API key.".into()); }
    Entry::new("com.voidclient.launcher", "curseforge-api-key").map_err(|e| e.to_string())?
        .set_password(key.trim()).map_err(|e| format!("Could not securely save CurseForge API key: {e}"))
}

#[tauri::command]
pub fn has_curseforge_api_key() -> bool { curseforge_key().is_ok() }

#[tauri::command]
pub async fn search_curseforge(query: String, class_id: u32, game_version: String, mod_loader_type: u32) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let key = curseforge_key()?;
        let http = client()?;
        let response = http.get("https://api.curseforge.com/v1/mods/search")
            .header("x-api-key", key)
            .query(&[("gameId", "432"), ("classId", &class_id.to_string()), ("searchFilter", &query), ("gameVersion", &game_version), ("modLoaderType", &mod_loader_type.to_string()), ("pageSize", "24"), ("sortField", "6"), ("sortOrder", "desc")])
            .send().map_err(|e| format!("Could not reach CurseForge: {e}"))?;
        let status = response.status();
        let body: Value = response.json().map_err(|e| e.to_string())?;
        if !status.is_success() { return Err(body.pointer("/errors/0/detail").and_then(Value::as_str).unwrap_or("CurseForge API rejected the request. Check your API key and application access.").to_string()); }
        Ok(body)
    }).await.map_err(|e| e.to_string())?
}

fn resolve_modrinth_version(http: &Client, project_id: &str, mc: &str, loader: &str, is_mod: bool) -> Result<Value, String> {
    let mut url = format!("https://api.modrinth.com/v2/project/{project_id}/version?game_versions=%5B%22{}%22%5D", urlencoding_simple(mc));
    if is_mod && loader != "Vanilla" { url.push_str(&format!("&loaders=%5B%22{}%22%5D", loader.to_lowercase())); }
    let value = get_json(http, &url)?;
    let list = value.as_array().ok_or("Modrinth returned an invalid versions list.")?;
    list.first().cloned().ok_or_else(|| format!("No compatible {mc} {loader} version exists for dependency {project_id}."))
}

fn urlencoding_simple(value: &str) -> String { value.replace('%', "%25").replace(' ', "%20").replace('"', "%22") }

fn install_modrinth_version_inner(app: &AppHandle, profile_id: &str, version: Value, category: &str, visiting: &mut HashSet<String>) -> Result<Vec<String>, String> {
    let version_id = version.get("id").and_then(Value::as_str).ok_or("Modrinth version ID is missing.")?.to_string();
    if !visiting.insert(format!("version:{version_id}")) { return Ok(Vec::new()); }
    let files = version.get("files").and_then(Value::as_array).ok_or("Modrinth version has no files.")?;
    let file = files.iter().find(|f| f.get("primary").and_then(Value::as_bool) == Some(true)).or_else(|| files.first()).ok_or("Modrinth version has no downloadable file.")?;
    let url = file.get("url").and_then(Value::as_str).ok_or("Modrinth file URL is missing.")?;
    let filename = file.get("filename").and_then(Value::as_str).ok_or("Modrinth file name is missing.")?;
    let sha512 = file.pointer("/hashes/sha512").and_then(Value::as_str);
    let sha1 = file.pointer("/hashes/sha1").and_then(Value::as_str);
    let bytes = download_from_allowed_hosts(url, 512 * 1024 * 1024, MODRINTH_FILE_HOSTS)?;
    if let Some(expected) = sha1 {
        if !sha1_hex(&bytes).eq_ignore_ascii_case(expected) { return Err(format!("SHA-1 integrity check failed for {filename}.")); }
    }
    if let Some(expected) = sha512 {
        let mut hasher = Sha512::new(); hasher.update(&bytes);
        if !hex::encode(hasher.finalize()).eq_ignore_ascii_case(expected) { return Err(format!("SHA-512 integrity check failed for {filename}.")); }
    }
    let dir = locate_profile_dir(app, profile_id)?.join(category);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let target = dir.join(safe_relative_path(filename)?);
    if !target.exists() { fs::write(&target, bytes).map_err(|e| e.to_string())?; }
    let mut installed = vec![filename.to_string()];
    // Dependency versions are fetched separately from the initially selected project version.
    // Build a client in this scope so required version-id dependencies can be resolved.
    let http = client()?;
    let dependencies = version.get("dependencies").and_then(Value::as_array).cloned().unwrap_or_default();
    for dep in dependencies {
        if dep.get("dependency_type").and_then(Value::as_str) != Some("required") { continue; }
        if let Some(dep_version_id) = dep.get("version_id").and_then(Value::as_str) {
            let version_key = format!("version:{dep_version_id}");
            if visiting.insert(version_key.clone()) {
                let dep_version = get_json(&http, &format!("https://api.modrinth.com/v2/version/{dep_version_id}"))?;
                // Remove the marker before the version installer records the canonical version key.
                visiting.remove(&version_key);
                installed.extend(install_modrinth_version_inner(app, profile_id, dep_version, category, visiting)?);
            }
        } else if let Some(dep_project_id) = dep.get("project_id").and_then(Value::as_str) {
            installed.extend(install_modrinth_project_inner(app, profile_id, dep_project_id, category, visiting)?);
        }
    }
    Ok(installed)
}

fn install_modrinth_project_inner(app: &AppHandle, profile_id: &str, project_id: &str, category: &str, visiting: &mut HashSet<String>) -> Result<Vec<String>, String> {
    let profile = load_profiles(app)?.into_iter().find(|p| p.id == profile_id).ok_or("Profile not found.")?;
    if category == "mods" && profile.loader == "Vanilla" { return Err("Install Fabric, Forge, NeoForge or Quilt before adding mods.".into()); }
    if !visiting.insert(format!("project:{project_id}")) { return Ok(Vec::new()); }
    let http = client()?;
    let version = resolve_modrinth_version(&http, project_id, &profile.minecraft_version, &profile.loader, category == "mods")?;
    install_modrinth_version_inner(app, profile_id, version, category, visiting)
}
#[tauri::command]
pub async fn install_modrinth_project(app: AppHandle, profile_id: String, project_id: String, category: String) -> Result<Vec<String>, String> {
    if !["mods", "resourcepacks", "shaderpacks"].contains(&category.as_str()) { return Err("Unsupported Modrinth install category.".into()); }
    tauri::async_runtime::spawn_blocking(move || install_modrinth_project_inner(&app, &profile_id, &project_id, &category, &mut HashSet::new())).await.map_err(|e| e.to_string())?
}

fn extract_archive_entry(archive: &mut ZipArchive<Cursor<Vec<u8>>>, index: usize, root: &Path, strip_prefix: Option<&str>) -> Result<(), String> {
    let mut file = archive.by_index(index).map_err(|e| e.to_string())?;
    if file.is_dir() { return Ok(()); }
    let original = file.name().replace('\\', "/");
    let mut relative = original.as_str();
    if let Some(prefix) = strip_prefix {
        if !relative.starts_with(prefix) { return Ok(()); }
        relative = &relative[prefix.len()..];
    }
    if relative.is_empty() { return Ok(()); }
    if file.size() > 512 * 1024 * 1024 { return Err("A modpack archive entry exceeds the 512 MiB extraction limit.".into()); }
    let relative = safe_relative_path(relative)?;
    let target = root.join(relative);
    if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    let mut bytes = Vec::with_capacity(file.size() as usize);
    file.take(512 * 1024 * 1024 + 1).read_to_end(&mut bytes).map_err(|e| e.to_string())?;
    if bytes.len() as u64 > 512 * 1024 * 1024 { return Err("A modpack archive entry exceeds the 512 MiB extraction limit.".into()); }
    fs::write(target, bytes).map_err(|e| e.to_string())
}

fn install_modrinth_pack_bytes(app: &AppHandle, profile_id: &str, pack_bytes: Vec<u8>) -> Result<String, String> {
    let mut archive = ZipArchive::new(Cursor::new(pack_bytes)).map_err(|e| format!("Invalid .mrpack archive: {e}"))?;
    let index_bytes = {
        let mut index = archive.by_name("modrinth.index.json").map_err(|_| "This ZIP is not a valid Modrinth .mrpack: modrinth.index.json is missing.")?;
        let mut bytes = Vec::new(); index.read_to_end(&mut bytes).map_err(|e| e.to_string())?; bytes
    };
    let index: Value = serde_json::from_slice(&index_bytes).map_err(|e| format!("Invalid Modrinth pack index: {e}"))?;
    if index.get("formatVersion").and_then(Value::as_u64).unwrap_or(0) != 1 { return Err("Unsupported Modrinth modpack format version.".into()); }
    let dependencies = index.get("dependencies").ok_or("Modrinth pack dependencies are missing.")?;
    let mc = dependencies.get("minecraft").and_then(Value::as_str).ok_or("Modrinth pack does not specify Minecraft version.")?.to_string();
    let loaders = dependencies.as_object().ok_or("Invalid modpack dependencies.")?;
    let mut loader = "Vanilla".to_string();
    let mut loader_version: Option<String> = None;
    for (key, value) in loaders {
        if key == "fabric-loader" { loader = "Fabric".into(); loader_version = value.as_str().map(str::to_string); }
        else if key == "quilt-loader" { loader = "Quilt".into(); loader_version = value.as_str().map(str::to_string); }
        else if key == "forge" { loader = "Forge".into(); loader_version = value.as_str().map(str::to_string); }
        else if key == "neoforge" { loader = "NeoForge".into(); loader_version = value.as_str().map(str::to_string); }
    }
    let mut profiles = load_profiles(app)?;
    let profile_index = profiles.iter().position(|p| p.id == profile_id).ok_or("Profile not found.")?;
    profiles[profile_index].minecraft_version = mc.clone();
    profiles[profile_index].loader = loader.clone();
    profiles[profile_index].installed_version = None;
    save_profiles(app, &profiles)?;
    let game_dir = locate_profile_dir(app, profile_id)?;
    fs::write(game_dir.join("profile.json"), serde_json::to_vec_pretty(&profiles[profile_index]).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    install_vanilla_inner(app, profile_id, &mc)?;
    if loader != "Vanilla" {
        match loader.as_str() {
            "Fabric" | "Quilt" => { install_fabric_or_quilt_inner(app, profile_id, &loader, loader_version.as_deref())?; }
            "Forge" | "NeoForge" => { install_forge_family_inner(app, profile_id, &loader, loader_version.as_deref())?; }
            _ => {}
        }
    }
    let files = index.get("files").and_then(Value::as_array).ok_or("Modrinth pack files are missing.")?;
    for (i, file) in files.iter().enumerate() {
        if file.pointer("/env/client").and_then(Value::as_str) == Some("unsupported") { continue; }
        let path = file.get("path").and_then(Value::as_str).ok_or("A modpack file has no path.")?;
        let relative = safe_relative_path(path)?;
        let urls = file.get("downloads").and_then(Value::as_array).ok_or("A modpack file has no download URLs.")?;
        if urls.is_empty() { return Err(format!("Modpack file {path} has an empty download URL list.")); }
        let mut last_error = None;
        let mut downloaded = None;
        for url in urls.iter().filter_map(Value::as_str) {
            match download_from_allowed_hosts(url, 512 * 1024 * 1024, MODRINTH_FILE_HOSTS) {
                Ok(bytes) => { downloaded = Some(bytes); break; }
                Err(error) => last_error = Some(error),
            }
        }
        let bytes = downloaded.ok_or_else(|| format!("Could not download modpack file {path}: {}", last_error.unwrap_or_else(|| "No valid HTTPS mirror was supplied.".into())))?;
        let sha1_expected = file.pointer("/hashes/sha1").and_then(Value::as_str)
            .ok_or_else(|| format!("Modrinth pack file {path} is missing its required SHA-1 hash."))?;
        let sha512_expected = file.pointer("/hashes/sha512").and_then(Value::as_str)
            .ok_or_else(|| format!("Modrinth pack file {path} is missing its required SHA-512 hash."))?;
        if !sha1_hex(&bytes).eq_ignore_ascii_case(sha1_expected) {
            return Err(format!("SHA-1 integrity check failed for modpack file {path}."));
        }
        let mut hasher = Sha512::new(); hasher.update(&bytes);
        if !hex::encode(hasher.finalize()).eq_ignore_ascii_case(sha512_expected) {
            return Err(format!("SHA-512 integrity check failed for modpack file {path}."));
        }
        let target = game_dir.join(relative);
        if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
        fs::write(target, bytes).map_err(|e| e.to_string())?;
        emit_progress(app, profile_id, "modpack", i as u64 + 1, files.len() as u64, "Installing modpack files");
    }
    // Client overrides and default overrides are applied after indexed files, so pack config wins as authored.
    for prefix in ["overrides/", "client-overrides/"] {
        // ZipArchive owns the cursor; read each entry into safe profile-relative files.
        for i in 0..archive.len() {
            let name = archive.by_index(i).map_err(|e| e.to_string())?.name().replace('\\', "/");
            if !name.starts_with(prefix) { continue; }
            extract_archive_entry(&mut archive, i, &game_dir, Some(prefix))?;
        }
    }
    let profiles = load_profiles(app)?;
    if let Some(profile) = profiles.iter().find(|p| p.id == profile_id) {
        fs::write(game_dir.join("profile.json"), serde_json::to_vec_pretty(profile).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    }
    Ok(format!("Modrinth modpack installed: Minecraft {mc} · {loader}."))
}

#[tauri::command]
pub async fn install_modrinth_modpack(app: AppHandle, profile_id: String, project_id: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let profile = load_profiles(&app)?.into_iter().find(|p| p.id == profile_id).ok_or("Profile not found.")?;
        let http = client()?;
        let url = format!("https://api.modrinth.com/v2/project/{project_id}/version");
        let versions = get_json(&http, &url)?;
        let list = versions.as_array().ok_or("Modrinth did not return modpack versions.")?;
        let selected = list.first().ok_or("This modpack has no published versions.")?;
        let file = selected.get("files").and_then(Value::as_array).and_then(|files| files.iter().find(|f| f.get("primary").and_then(Value::as_bool) == Some(true)).or_else(|| files.first())).ok_or("Modpack release has no files.")?;
        let download = file.get("url").and_then(Value::as_str).ok_or("Modpack download URL is missing.")?;
        let bytes = download_from_allowed_hosts(download, 2 * 1024 * 1024 * 1024, MODRINTH_FILE_HOSTS)?;
        let result = install_modrinth_pack_bytes(&app, &profile_id, bytes)?;
        Ok(format!("{} — {result}", profile.name))
    }).await.map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn install_modrinth_pack_file(app: AppHandle, profile_id: String, file_path: String) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let path = PathBuf::from(file_path);
        let size = fs::metadata(&path).map_err(|e| format!("Could not inspect .mrpack file: {e}"))?.len();
        if size > 2 * 1024 * 1024 * 1024 { return Err("The .mrpack file exceeds the 2 GiB import limit.".into()); }
        let bytes = fs::read(path).map_err(|e| format!("Could not read .mrpack file: {e}"))?;
        install_modrinth_pack_bytes(&app, &profile_id, bytes)
    }).await.map_err(|e| e.to_string())?
}

fn curseforge_get_file(http: &Client, key: &str, mod_id: u64, file_id: u64) -> Result<Value, String> {
    let response = http.get(format!("https://api.curseforge.com/v1/mods/{mod_id}/files/{file_id}"))
        .header("x-api-key", key).send().map_err(|e| e.to_string())?;
    let status = response.status(); let value: Value = response.json().map_err(|e| e.to_string())?;
    if !status.is_success() { return Err(value.pointer("/errors/0/detail").and_then(Value::as_str).unwrap_or("CurseForge rejected a file request.").to_string()); }
    Ok(value.get("data").cloned().unwrap_or(Value::Null))
}

fn curseforge_download_url(http: &Client, key: &str, mod_id: u64, file_id: u64, file: &Value) -> Result<String, String> {
    if let Some(url) = file.get("downloadUrl").and_then(Value::as_str) {
        return Ok(url.to_string());
    }
    let response = http.get(format!("https://api.curseforge.com/v1/mods/{mod_id}/files/{file_id}/download-url"))
        .header("x-api-key", key).send().map_err(|e| format!("Could not resolve CurseForge download URL: {e}"))?;
    let status = response.status();
    let value: Value = response.json().map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(value.pointer("/errors/0/detail").and_then(Value::as_str)
            .unwrap_or("CurseForge could not resolve this file's download URL. The author may have restricted distribution.").to_string());
    }
    value.get("data").and_then(Value::as_str).map(str::to_string)
        .ok_or("CurseForge returned no downloadable URL for this file.".into())
}

fn validate_curseforge_download_url(url: &str) -> Result<(), String> {
    let parsed = reqwest::Url::parse(url).map_err(|_| "CurseForge returned an invalid download URL.")?;
    if parsed.scheme() != "https" || !["media.forgecdn.net", "edge.forgecdn.net", "www.curseforge.com"].contains(&parsed.host_str().unwrap_or("")) {
        return Err("CurseForge returned a download URL outside its permitted HTTPS file hosts.".into());
    }
    Ok(())
}

fn curseforge_loader_type(loader: &str) -> u32 {
    match loader { "Forge" => 1, "Fabric" => 4, "Quilt" => 5, "NeoForge" => 6, _ => 0 }
}

fn install_curseforge_mod_recursive(
    app: &AppHandle,
    profile_id: &str,
    http: &Client,
    key: &str,
    game_version: &str,
    loader_type: u32,
    mod_id: u64,
    file_id: u64,
    visited: &mut HashSet<u64>,
    installed: &mut Vec<String>,
) -> Result<(), String> {
    if !visited.insert(mod_id) { return Ok(()); }
    let file = curseforge_get_file(http, key, mod_id, file_id)?;
    let url = curseforge_download_url(http, key, mod_id, file_id, &file)?;
    validate_curseforge_download_url(&url)?;
    let bytes = download_curseforge_bytes(&url, key, 512 * 1024 * 1024)?;
    if let Some(expected) = file.get("hashes").and_then(Value::as_array).and_then(|hashes| hashes.iter().find(|hash| hash.get("algo").and_then(Value::as_u64) == Some(1)))
        .and_then(|hash| hash.get("value")).and_then(Value::as_str) {
        if !sha1_hex(&bytes).eq_ignore_ascii_case(expected) {
            return Err(format!("CurseForge SHA-1 verification failed for mod file {}.", file_id));
        }
    }
    let filename = file.get("fileName").and_then(Value::as_str).ok_or("CurseForge file name is missing.")?;
    let relative = safe_relative_path(filename)?;
    if relative.extension().and_then(|ext| ext.to_str()).map(|ext| ext.eq_ignore_ascii_case("jar")) != Some(true) {
        return Err(format!("CurseForge returned a non-JAR file for a Minecraft mod: {filename}"));
    }
    let target_dir = locate_profile_dir(app, profile_id)?.join("mods");
    fs::create_dir_all(&target_dir).map_err(|e| e.to_string())?;
    let target = target_dir.join(relative);
    if !target.exists() { fs::write(&target, bytes).map_err(|e| e.to_string())?; }
    installed.push(filename.to_string());
    emit_progress(app, profile_id, "curseforge-mod", installed.len() as u64, 0, &format!("Installed {filename}"));

    let dependencies = file.get("dependencies").and_then(Value::as_array).cloned().unwrap_or_default();
    for dependency in dependencies {
        if dependency.get("relationType").and_then(Value::as_u64) != Some(3) { continue; }
        let dependency_id = match dependency.get("modId").and_then(Value::as_u64) { Some(id) => id, None => continue };
        if visited.contains(&dependency_id) { continue; }
        let type_value = loader_type.to_string();
        let response = http.get(format!("https://api.curseforge.com/v1/mods/{dependency_id}/files"))
            .header("x-api-key", key)
            .query(&[("gameVersion", game_version), ("modLoaderType", type_value.as_str()), ("pageSize", "10"), ("index", "0"), ("sortField", "2"), ("sortOrder", "desc")])
            .send().map_err(|e| format!("Could not resolve required CurseForge dependency {dependency_id}: {e}"))?;
        let status = response.status();
        let listing: Value = response.json().map_err(|e| e.to_string())?;
        if !status.is_success() {
            return Err(listing.pointer("/errors/0/detail").and_then(Value::as_str)
                .unwrap_or("CurseForge dependency lookup failed.").to_string());
        }
        let dependency_file_id = listing.pointer("/data/0/id").and_then(Value::as_u64)
            .ok_or_else(|| format!("No compatible CurseForge file was found for required dependency {dependency_id}."))?;
        install_curseforge_mod_recursive(app, profile_id, http, key, game_version, loader_type,
            dependency_id, dependency_file_id, visited, installed)?;
    }
    Ok(())
}

#[tauri::command]
pub async fn install_curseforge_mod(app: AppHandle, profile_id: String, mod_id: u64, file_id: u64) -> Result<Vec<String>, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let profile = load_profiles(&app)?.into_iter().find(|profile| profile.id == profile_id).ok_or("Profile not found.")?;
        if profile.loader == "Vanilla" { return Err("Install Fabric, Forge, NeoForge or Quilt before adding CurseForge mods.".into()); }
        let key = curseforge_key()?;
        let http = client()?;
        let mut visited = HashSet::new();
        let mut installed = Vec::new();
        install_curseforge_mod_recursive(&app, &profile_id, &http, &key, &profile.minecraft_version,
            curseforge_loader_type(&profile.loader), mod_id, file_id, &mut visited, &mut installed)?;
        Ok(installed)
    }).await.map_err(|e| e.to_string())?
}

fn install_curseforge_pack_bytes(app: &AppHandle, profile_id: &str, bytes: Vec<u8>) -> Result<String, String> {
    let key = curseforge_key()?;
    let http = client()?;
    let mut archive = ZipArchive::new(Cursor::new(bytes)).map_err(|e| format!("Invalid CurseForge modpack ZIP: {e}"))?;
    let manifest_bytes = {
        let mut manifest = archive.by_name("manifest.json").map_err(|_| "This ZIP is not a CurseForge modpack: manifest.json is missing.")?;
        let mut data = Vec::new(); manifest.read_to_end(&mut data).map_err(|e| e.to_string())?; data
    };
    let manifest: Value = serde_json::from_slice(&manifest_bytes).map_err(|e| format!("Invalid CurseForge manifest: {e}"))?;
    let mc = manifest.pointer("/minecraft/version").and_then(Value::as_str).ok_or("CurseForge manifest has no Minecraft version.")?.to_string();
    let loader_id = manifest.pointer("/minecraft/modLoaders/0/id").and_then(Value::as_str).unwrap_or("");
    let (loader, loader_version) = if let Some((prefix, version)) = loader_id.split_once('-') {
        let loader = match prefix.to_ascii_lowercase().as_str() {
            "fabric" => "Fabric", "quilt" => "Quilt", "neoforge" => "NeoForge", "forge" => "Forge", _ => "Vanilla",
        };
        (loader, if loader == "Vanilla" { None } else { Some(version) })
    } else { ("Vanilla", None) };
    let mut profiles = load_profiles(app)?;
    let profile_index = profiles.iter().position(|p| p.id == profile_id).ok_or("Profile not found.")?;
    profiles[profile_index].minecraft_version = mc.clone();
    profiles[profile_index].loader = loader.into();
    profiles[profile_index].installed_version = None;
    save_profiles(app, &profiles)?;
    let game_dir = locate_profile_dir(app, profile_id)?;
    fs::write(game_dir.join("profile.json"), serde_json::to_vec_pretty(&profiles[profile_index]).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    install_vanilla_inner(app, profile_id, &mc)?;
    if loader != "Vanilla" {
        if loader == "Fabric" || loader == "Quilt" { install_fabric_or_quilt_inner(app, profile_id, loader, loader_version)?; }
        else { install_forge_family_inner(app, profile_id, loader, loader_version)?; }
    }
    let files = manifest.get("files").and_then(Value::as_array).ok_or("CurseForge pack has no file list.")?;
    let loader_type = curseforge_loader_type(loader);
    let mut visited_mods = HashSet::new();
    let mut installed_files = Vec::new();
    for (i, entry) in files.iter().enumerate() {
        if entry.get("required").and_then(Value::as_bool) == Some(false) { continue; }
        let mod_id = entry.get("projectID").and_then(Value::as_u64).ok_or("CurseForge pack contains a file without projectID.")?;
        let file_id = entry.get("fileID").and_then(Value::as_u64).ok_or("CurseForge pack contains a file without fileID.")?;
        install_curseforge_mod_recursive(app, profile_id, &http, &key, &mc, loader_type,
            mod_id, file_id, &mut visited_mods, &mut installed_files)?;
        emit_progress(app, profile_id, "curseforge-pack", i as u64 + 1, files.len() as u64, "Installing pack mods and required dependencies");
    }
    let override_root = manifest.get("overrides").and_then(Value::as_str)
        .filter(|value| !value.trim().is_empty()).unwrap_or("overrides");
    let safe_override_root = safe_relative_path(override_root.trim_matches('/'))?;
    let override_prefix = format!("{}/", safe_override_root.to_string_lossy().replace('\\', "/"));
    for index in 0..archive.len() {
        let name = archive.by_index(index).map_err(|e| e.to_string())?.name().replace('\\', "/");
        if name.starts_with(&override_prefix) { extract_archive_entry(&mut archive, index, &game_dir, Some(&override_prefix))?; }
    }
    Ok(format!("CurseForge modpack installed: Minecraft {mc} · {loader}."))
}

#[tauri::command]
pub async fn install_curseforge_modpack(app: AppHandle, profile_id: String, mod_id: u64, file_id: u64) -> Result<String, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let key = curseforge_key()?;
        let http = client()?;
        let info = curseforge_get_file(&http, &key, mod_id, file_id)?;
        let url = curseforge_download_url(&http, &key, mod_id, file_id, &info)?;
        validate_curseforge_download_url(&url)?;
        let bytes = download_curseforge_bytes(&url, &key, 2 * 1024 * 1024 * 1024)?;
        install_curseforge_pack_bytes(&app, &profile_id, bytes)
    }).await.map_err(|e| e.to_string())?
}
