export type Loader = 'Vanilla' | 'Fabric' | 'Forge' | 'NeoForge' | 'Quilt';

export interface Profile {
  id: string;
  name: string;
  minecraftVersion: string;
  loader: Loader;
  ramGb: number;
  createdAt: number;
  lastPlayed: number | null;
  javaPath: string | null;
  jvmArgs: string;
  gameWidth: number;
  gameHeight: number;
  fullscreen: boolean;
  installedVersion?: string | null;
}

export interface LauncherSettings {
  accent: string;
  theme: string;
  gameDirectory: string | null;
  microsoftClientId: string;
  selectedAccountId: string | null;
  maxDownloads: number;
}

export const defaultSettings: LauncherSettings = {
  accent: 'violet',
  theme: 'dark',
  gameDirectory: null,
  microsoftClientId: '',
  selectedAccountId: null,
  maxDownloads: 8,
};


export interface ProfileFile {
  name: string;
  size: number;
  isDirectory: boolean;
  modifiedAt: number | null;
}

export interface AccountSummary {
  id: string;
  name: string;
  uuid: string;
  skinUrl: string | null;
  accountType: 'microsoft' | 'offline';
}

export interface DeviceCode {
  deviceCode: string;
  userCode: string;
  verificationUri: string;
  message: string;
  expiresIn: number;
  interval: number;
}


export interface ModrinthProject {
  project_id: string;
  project_type: string;
  title: string;
  description: string;
  author: string;
  downloads: number;
  icon_url?: string | null;
  slug: string;
  categories?: string[];
}


export interface GameVersion {
  id: string;
  versionType: string;
  releaseTime: string | null;
  url: string;
}

export interface JavaRuntime {
  major: number;
  path: string;
  source: string;
}

export interface EngineStatus {
  installed: boolean;
  gameVersion: string;
  installedVersion: string | null;
  javaRequired: number;
  javaFound: boolean;
  loader: string;
}

export interface EngineProgress {
  profileId: string;
  stage: string;
  done: number;
  total: number;
  percent: number;
  detail: string;
}

export interface CurseForgeMod {
  id: number;
  name: string;
  slug: string;
  summary: string;
  downloadCount: number;
  logo?: { thumbnailUrl?: string };
  latestFiles?: { id: number; fileName: string; downloadUrl?: string | null; gameVersions?: string[] }[];
}

export interface LaunchLogEntry {
  profileId: string;
  profileName: string;
  stream: 'system' | 'stdout' | 'stderr' | 'warning' | 'error' | string;
  message: string;
  timestamp: number;
}

export interface ServerInstance {
  id: string;
  name: string;
  minecraftVersion: string;
  software: 'Vanilla' | 'Fabric' | string;
  ramMb: number;
  cpuThreads: number;
  javaPath: string | null;
  port: number;
  maxPlayers: number;
  motd: string;
  onlineMode: boolean;
  eulaAccepted: boolean;
  installed: boolean;
  createdAt: number;
}

export interface ServerInfo extends ServerInstance {
  isRunning: boolean;
}

export interface ServerFile {
  name: string;
  size: number;
  isDirectory: boolean;
}

export interface ServerModInstallResult {
  installed: string[];
  skipped: string[];
}

export interface ServerLogEntry {
  serverId: string;
  serverName: string;
  stream: string;
  message: string;
  timestamp: number;
}
