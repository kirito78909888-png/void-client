import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity, AlertTriangle, ArrowDownToLine, Check, ChevronDown, CircleHelp, CloudDownload,
  Code2, ExternalLink, File, FileText, Folder, FolderOpen, HardDrive, LoaderCircle,
  Network, Package, Play, Plus, Power, RefreshCw, Search, Server, Settings2, Square,
  Terminal, Trash2, Wrench, X,
} from 'lucide-react';
import type { ModrinthProject, ServerFile, ServerInfo, ServerLogEntry, ServerModInstallResult } from './types';
import { api } from './storage';

type Tab = 'Overview' | 'Console' | 'Files' | 'Mods' | 'Settings' | 'Network';
const folders = ['root', 'mods', 'plugins', 'config', 'world', 'logs', 'backups'];
const fmtBytes = (value: number) => value < 1024 ? `${value} B` : value < 1024 ** 2 ? `${(value / 1024).toFixed(1)} KB` : `${(value / 1024 ** 2).toFixed(1)} MB`;
const prettyTime = (value: number) => new Date(value).toLocaleTimeString();
const nextConfiguredPort = (items: ServerInfo[]) => { const used = new Set(items.map(item => item.port)); for (let port = 25565; port <= 25664; port += 1) if (!used.has(port)) return port; return 25565; };

export function ServersPage({ lines, onNotice }: { lines: ServerLogEntry[]; onNotice: (message: string) => void }) {
  const [servers, setServers] = useState<ServerInfo[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('Overview');
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [newName, setNewName] = useState('My Minecraft Server');
  const [newVersion, setNewVersion] = useState('1.21.11');
  const [newSoftware, setNewSoftware] = useState('Vanilla');
  const [newRam, setNewRam] = useState(4096);
  const [newCpu, setNewCpu] = useState(4);
  const [newPort, setNewPort] = useState(25565);
  const [folder, setFolder] = useState('root');
  const [files, setFiles] = useState<ServerFile[]>([]);
  const [fileBusy, setFileBusy] = useState(false);
  const [editName, setEditName] = useState<string | null>(null);
  const [editContents, setEditContents] = useState('');
  const [modQuery, setModQuery] = useState('');
  const [modHits, setModHits] = useState<ModrinthProject[]>([]);
  const [modSearching, setModSearching] = useState(false);
  const [playitRunning, setPlayitRunning] = useState(false);
  const [serverCommand, setServerCommand] = useState('');
  const [settingsDraft, setSettingsDraft] = useState<ServerInfo | null>(null);

  const selected = servers.find(server => server.id === selectedId) ?? servers[0] ?? null;
  const selectedLines = useMemo(() => lines.filter(line => line.serverId === selected?.id || line.serverId === 'playit'), [lines, selected?.id]);

  const refresh = useCallback(async (quiet = false) => {
    try {
      const [items, playit] = await Promise.all([api.getServers(), api.isPlayitRunning()]);
      setServers(items);
      setPlayitRunning(playit);
      setSelectedId(current => current && items.some(server => server.id === current) ? current : items[0]?.id ?? null);
    } catch (error) {
      if (!quiet) onNotice(error instanceof Error ? error.message : 'Could not load server library.');
    } finally { setLoading(false); }
  }, [onNotice]);

  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    const timer = window.setInterval(() => { void refresh(true); }, 4000);
    return () => window.clearInterval(timer);
  }, [refresh]);
  useEffect(() => { setSettingsDraft(selected ? { ...selected } : null); }, [selected?.id]);
  useEffect(() => {
    if (!selected) { setFiles([]); return; }
    let alive = true;
    setFileBusy(true);
    void api.getServerFiles(selected.id, folder).then(items => { if (alive) setFiles(items); })
      .catch(error => { if (alive) onNotice(error instanceof Error ? error.message : 'Could not read server files.'); })
      .finally(() => { if (alive) setFileBusy(false); });
    return () => { alive = false; };
  }, [selected?.id, folder, onNotice]);

  const runAction = async (label: string, action: () => Promise<unknown>, refreshAfter = true) => {
    setWorking(label);
    try {
      const result = await action();
      if (typeof result === 'string' && result) onNotice(result);
      else onNotice(`${label} completed.`);
      if (refreshAfter) await refresh(true);
      return true;
    } catch (error) {
      onNotice(error instanceof Error ? error.message : `${label} failed.`);
      return false;
    } finally { setWorking(''); }
  };

  const createServer = async () => {
    if (!newName.trim()) { onNotice('Enter a name for this server.'); return; }
    setWorking('Creating server');
    try {
      const server = await api.createServer({ name: newName.trim(), minecraftVersion: newVersion.trim(), software: newSoftware, ramMb: newRam, cpuThreads: newCpu, port: newPort });
      setSelectedId(server.id);
      setCreateOpen(false);
      setTab('Overview');
      await refresh(true);
      onNotice(`Created ${server.name}. Now installing its server software…`);
      setWorking('Installing server');
      const message = await api.installServer(server.id);
      onNotice(message);
      await refresh(true);
    } catch (error) {
      onNotice(error instanceof Error ? error.message : 'Could not create or install the server.');
      await refresh(true);
    } finally { setWorking(''); }
  };

  const loadFiles = async () => {
    if (!selected) return;
    setFileBusy(true);
    try { setFiles(await api.getServerFiles(selected.id, folder)); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not refresh files.'); }
    finally { setFileBusy(false); }
  };

  const openEditor = async (name: string) => {
    if (!selected) return;
    try { setEditContents(await api.readServerTextFile(selected.id, name)); setEditName(name); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not open file.'); }
  };

  const saveEditor = async () => {
    if (!selected || !editName) return;
    const saved = await runAction('Save file', () => api.writeServerTextFile(selected.id, editName, editContents), false);
    if (saved) {
      setEditName(null);
      await loadFiles();
    }
  };

  const searchMods = async () => {
    if (!selected) return;
    setModSearching(true);
    try { setModHits(await api.searchServerMods(modQuery, selected.id)); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Mod search failed.'); }
    finally { setModSearching(false); }
  };

  const saveSettings = async () => {
    if (!selected || !settingsDraft) return;
    await runAction('Save server settings', () => api.updateServer(settingsDraft));
  };

  const setEula = async (accepted: boolean) => {
    if (!selected) return;
    await runAction(accepted ? 'Accept EULA' : 'Revoke EULA acceptance', () => api.setServerEula(selected.id, accepted));
  };

  const tabs: { name: Tab; icon: typeof Activity }[] = [
    { name: 'Overview', icon: Activity }, { name: 'Console', icon: Terminal }, { name: 'Files', icon: Folder },
    { name: 'Mods', icon: Package }, { name: 'Settings', icon: Settings2 }, { name: 'Network', icon: Network },
  ];

  const toggleCreate = () => {
    if (!createOpen) setNewPort(nextConfiguredPort(servers));
    setCreateOpen(value => !value);
  };

  return <div className="servers-page">
    <div className="page-heading"><div><div className="eyebrow">HOST YOUR OWN WORLD</div><h1>Servers</h1><p>Create multiple Minecraft servers, install software, manage files and mods, and expose them through Playit.gg.</p></div><div className="heading-action"><button className="button button-primary" onClick={toggleCreate}><Plus size={15} /> New server</button></div></div>

    {createOpen && <section className="server-create-card settings-card">
      <div className="section-heading"><div><h3>Create a server</h3><p>Each server gets its own directory, world, mods, settings and resource limits.</p></div><button className="icon-button" onClick={() => setCreateOpen(false)}><X size={15} /></button></div>
      <div className="server-form-grid">
        <label className="field"><span>SERVER NAME</span><input value={newName} onChange={e => setNewName(e.target.value)} maxLength={48} /></label>
        <label className="field"><span>MINECRAFT VERSION</span><input value={newVersion} onChange={e => setNewVersion(e.target.value)} /></label>
        <label className="field"><span>SERVER SOFTWARE</span><select value={newSoftware} onChange={e => setNewSoftware(e.target.value)}><option>Vanilla</option><option>Fabric</option></select></label>
        <label className="field"><span>LOCAL PORT</span><input type="number" min={1} max={65535} value={newPort} onChange={e => setNewPort(Number(e.target.value))} /></label>
        <label className="field"><span>RAM ALLOCATION</span><select value={newRam} onChange={e => setNewRam(Number(e.target.value))}><option value={2048}>2 GB</option><option value={4096}>4 GB</option><option value={6144}>6 GB</option><option value={8192}>8 GB</option><option value={12288}>12 GB</option><option value={16384}>16 GB</option><option value={24576}>24 GB</option><option value={32768}>32 GB</option></select></label>
        <label className="field"><span>CPU THREAD HINT</span><input type="number" min={1} max={64} value={newCpu} onChange={e => setNewCpu(Math.max(1, Math.min(64, Number(e.target.value))))} /></label>
      </div>
      <div className="server-create-foot"><span>Software downloads from Mojang or Fabric's official distribution services.</span><button className="button button-primary" onClick={() => void createServer()} disabled={!!working}>{working ? <><LoaderCircle size={13} className="spin" /> {working}</> : <><CloudDownload size={14} /> Create & install</>}</button></div>
    </section>}

    <div className="servers-layout">
      <aside className="server-library-card settings-card">
        <div className="server-library-head"><div><div className="eyebrow">YOUR INSTANCES</div><strong>{servers.length} server{servers.length === 1 ? '' : 's'}</strong></div><button className="icon-button" title="Refresh servers" onClick={() => void refresh()}><RefreshCw size={14} /></button></div>
        {loading ? <div className="inline-loading"><LoaderCircle size={16} className="spin" /> Loading servers…</div> : servers.length === 0 ? <div className="workspace-empty server-empty"><Server size={23} /><strong>No servers yet</strong><p>Create your first private or friends-only Minecraft server.</p><button className="button button-secondary" onClick={() => { setNewPort(nextConfiguredPort(servers)); setCreateOpen(true); }}><Plus size={13} /> Create server</button></div> : <div className="server-list">{servers.map(server => <button key={server.id} className={`server-list-item ${selected?.id === server.id ? 'selected' : ''}`} onClick={() => { setSelectedId(server.id); setTab('Overview'); }}><span className={`server-state-dot ${server.isRunning ? 'running' : ''}`} /><span className="server-list-copy"><strong>{server.name}</strong><small>{server.minecraftVersion} · {server.software}</small></span><span className="server-list-status">{server.isRunning ? 'ONLINE' : server.installed ? 'STOPPED' : 'NOT INSTALLED'}</span></button>)}</div>}
      </aside>

      <section className="server-workspace">
        {!selected ? <div className="empty-state server-empty-state"><div className="empty-icon"><Server size={22} /></div><h3>Your server control room</h3><p>Create your first server to manage its world, mods, configuration, console and public connection.</p><button className="button button-primary" onClick={() => setCreateOpen(true)}><Plus size={14} /> Create server</button></div> : <>
          <div className="server-detail-head"><div className="server-detail-title"><div className="server-detail-emblem"><Server size={21} /></div><div><div className="eyebrow">{selected.minecraftVersion} · {selected.software.toUpperCase()}</div><h2>{selected.name}</h2><span>{selected.isRunning ? 'Server process is running' : selected.installed ? 'Installed and ready' : 'Install required'}</span></div></div><div className="server-head-actions">
            {selected.isRunning ? <button className="button button-secondary" disabled={!!working} onClick={() => void runAction('Stop server', () => api.stopServer(selected.id))}><Square size={13} /> Stop</button> : <button className="button button-primary" disabled={!!working || !selected.installed || !selected.eulaAccepted} onClick={() => void runAction('Start server', () => api.startServer(selected.id))}><Play size={13} /> Start server</button>}
            <button className="button button-secondary" disabled={!!working} onClick={() => void runAction('Reinstall server', () => api.reinstallServer(selected.id))}><Wrench size={13} /> Reinstall</button>
            <button className="icon-button danger-icon" title="Delete server" disabled={!!working} onClick={() => { if (window.confirm(`Delete ${selected.name} and all of its server files, including the world? This cannot be undone.`)) void runAction('Delete server', () => api.deleteServer(selected.id)); }}><Trash2 size={15} /></button>
          </div></div>
          <div className="server-tabs">{tabs.map(item => { const Icon = item.icon; return <button key={item.name} className={tab === item.name ? 'active' : ''} onClick={() => { setTab(item.name); if (item.name === 'Mods') setFolder('mods'); else if (item.name === 'Files') setFolder('root'); }}><Icon size={14} /> {item.name}</button>; })}</div>

          {tab === 'Overview' && <div className="server-overview">
            <div className="server-stat-grid"><div className="server-stat"><span>STATUS</span><strong className={selected.isRunning ? 'server-online-text' : ''}>{selected.isRunning ? 'Running' : selected.installed ? 'Stopped' : 'Not installed'}</strong></div><div className="server-stat"><span>MEMORY LIMIT</span><strong>{(selected.ramMb / 1024).toFixed(0)} GB</strong></div><div className="server-stat"><span>CPU THREAD HINT</span><strong>{selected.cpuThreads} threads</strong></div><div className="server-stat"><span>PORT</span><strong>{selected.port}</strong></div></div>
            <div className="server-content-card"><div className="section-heading"><div><h3>Server setup</h3><p>Accept Mojang's EULA before starting the server.</p></div><span className={`pill ${selected.eulaAccepted ? 'pill-success' : 'pill-muted'}`}>{selected.eulaAccepted ? 'EULA ACCEPTED' : 'EULA REQUIRED'}</span></div>
              <label className="server-eula-row"><input type="checkbox" checked={selected.eulaAccepted} onChange={e => void setEula(e.target.checked)} /><span><strong>I agree to the Minecraft End User License Agreement</strong><small>Read the <a href="https://aka.ms/MinecraftEULA" onClick={e => { e.preventDefault(); void api.openExternalUrl('https://aka.ms/MinecraftEULA').catch(error => onNotice(String(error))); }}>official Minecraft EULA <ExternalLink size={11} /></a>. Starting a server requires acceptance.</small></span></label>
              {!selected.installed && <div className="server-inline-warning"><AlertTriangle size={15} /> Server files have not been installed yet. Use Create & install or reinstall the server software.</div>}
            </div>
            <div className="server-content-card"><div className="section-heading"><div><h3>Quick actions</h3><p>Common server management tasks.</p></div></div><div className="server-quick-actions"><button className="button button-secondary" onClick={() => setTab('Console')}><Terminal size={14} /> Open console</button><button className="button button-secondary" onClick={() => setTab('Files')}><FolderOpen size={14} /> Manage files</button><button className="button button-secondary" onClick={() => setTab('Mods')}><Package size={14} /> Manage mods</button><button className="button button-secondary" onClick={() => void runAction('Open server folder', () => api.openServerFolder(selected.id), false)}><Folder size={14} /> Open folder</button></div></div>
          </div>}

          {tab === 'Console' && <div className="server-content-card server-console-card"><div className="section-heading"><div><h3>Live server console</h3><p>Process output and commands for {selected.name}.</p></div><span className={`console-live-indicator ${selected.isRunning ? 'is-live' : ''}`}><i /> {selected.isRunning ? 'LIVE' : 'STOPPED'}</span></div><div className="server-console-output">{selectedLines.length ? selectedLines.slice(-500).map((line, index) => <div className={`server-console-line ${line.stream}`} key={`${line.timestamp}-${index}`}><time>{prettyTime(line.timestamp)}</time><span>{line.stream.toUpperCase()}</span><code>{line.message}</code></div>) : <div className="workspace-empty"><Terminal size={20} /><strong>No server output yet</strong><p>Start the server to see logs and the startup process here.</p></div>}</div><form className="server-command-form" onSubmit={e => { e.preventDefault(); if (serverCommand.trim()) void runAction('Send command', () => api.sendServerCommand(selected.id, serverCommand)).then(ok => { if (ok) setServerCommand(''); }); }}><input value={serverCommand} onChange={e => setServerCommand(e.target.value)} placeholder="Enter a server command, e.g. list or say hello" disabled={!selected.isRunning} /><button className="button button-primary" disabled={!selected.isRunning || !serverCommand.trim()}><Terminal size={13} /> Send</button></form></div>}

          {tab === 'Files' && <div className="server-content-card"><div className="section-heading"><div><h3>Server files</h3><p>Browse server folders and edit supported configuration files.</p></div><div className="server-file-tools"><select value={folder} onChange={e => setFolder(e.target.value)}>{folders.map(value => <option key={value} value={value}>{value === 'root' ? 'Server root' : value}</option>)}</select><button className="icon-button" onClick={() => void loadFiles()} title="Refresh files"><RefreshCw size={14} /></button><button className="icon-button" onClick={() => void runAction('Open server folder', () => api.openServerFolder(selected.id), false)} title="Open in File Explorer"><FolderOpen size={14} /></button></div></div>
            {fileBusy ? <div className="inline-loading"><LoaderCircle size={16} className="spin" /> Reading server files…</div> : files.length === 0 ? <div className="workspace-empty"><Folder size={22} /><strong>This folder is empty</strong><p>Files created by the server or added by you will appear here.</p></div> : <div className="server-file-list">{files.map(file => <div className="server-file-row" key={file.name}><div className="server-file-icon">{file.isDirectory ? <Folder size={15} /> : <File size={15} />}</div><div className="server-file-name"><strong>{file.name}</strong><span>{file.isDirectory ? 'Folder' : fmtBytes(file.size)}</span></div>{folder === 'root' && !file.isDirectory && ['server.properties', 'whitelist.json', 'ops.json', 'banned-players.json', 'banned-ips.json'].includes(file.name) && <button className="button button-secondary" onClick={() => void openEditor(file.name)}><Code2 size={12} /> Edit</button>}<button className="icon-button danger-icon" title="Delete file" onClick={() => { if (window.confirm(`Delete ${file.name}?`)) void runAction('Delete file', () => api.removeServerFile(selected.id, folder, file.name)).then(loadFiles); }}><Trash2 size={13} /></button></div>)}</div>}
            <div className="server-folder-shortcuts">{folders.filter(value => value !== folder).map(value => <button key={value} className="choice-chip" onClick={() => setFolder(value)}>{value}</button>)}</div>
          </div>}

          {tab === 'Mods' && <div className="server-content-card"><div className="section-heading"><div><h3>Server mods</h3><p>Fabric server mods and their required dependencies from Modrinth.</p></div><span className="pill pill-muted">{selected.software === 'Fabric' ? 'FABRIC' : 'VANILLA'}</span></div>
            {selected.software !== 'Fabric' && <div className="server-inline-warning"><CircleHelp size={15} /> Server-side Modrinth mod installation is currently enabled for Fabric servers. Vanilla servers can still manage files manually.</div>}
            <div className="server-installed-mods">{files.filter(file => !file.isDirectory && (file.name.toLowerCase().endsWith('.jar') || file.name.toLowerCase().endsWith('.jar.disabled'))).map(file => <div className="server-file-row" key={file.name}><Package size={15} /><div className="server-file-name"><strong>{file.name}</strong><span>{file.name.endsWith('.disabled') ? 'Disabled' : 'Enabled'}</span></div><button className="button button-secondary" onClick={() => void runAction('Change mod state', () => api.toggleServerMod(selected.id, file.name, file.name.endsWith('.disabled'))).then(loadFiles)}>{file.name.endsWith('.disabled') ? 'Enable' : 'Disable'}</button><button className="icon-button danger-icon" onClick={() => { if (window.confirm(`Remove ${file.name}?`)) void runAction('Remove mod', () => api.removeServerFile(selected.id, 'mods', file.name)).then(loadFiles); }}><Trash2 size={13} /></button></div>)}{files.length === 0 && <div className="workspace-empty"><Package size={20} /><strong>No installed mods</strong><p>Use the Modrinth search below to add Fabric-compatible server mods.</p></div>}</div>
            <div className="server-mod-search"><div className="field"><span>DISCOVER SERVER MODS ON MODRINTH</span><div className="server-mod-search-row"><input value={modQuery} onChange={e => setModQuery(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void searchMods(); }} placeholder="Search server mods…" /><button className="button button-secondary" disabled={modSearching || selected.software !== 'Fabric'} onClick={() => void searchMods()}>{modSearching ? <LoaderCircle size={13} className="spin" /> : <Search size={13} />} Search</button></div></div>
              {modHits.map(hit => <div className="server-mod-result" key={hit.project_id}>{hit.icon_url ? <img src={hit.icon_url} alt="" /> : <div className="server-file-icon"><Package size={16} /></div>}<div className="server-file-name"><strong>{hit.title}</strong><span>by {hit.author} · {hit.downloads.toLocaleString()} downloads</span><small>{hit.description}</small></div><button className="button button-primary" disabled={!!working || selected.software !== 'Fabric'} onClick={() => void runAction('Install mod', async () => { const result: ServerModInstallResult = await api.installServerMod(selected.id, hit.project_id); return `Installed ${result.installed.length} file(s); skipped ${result.skipped.length} existing dependency/file(s).`; }).then(loadFiles)}>Install</button></div>)}
            </div>
          </div>}

          {tab === 'Settings' && settingsDraft && <div className="server-content-card"><div className="section-heading"><div><h3>Server configuration</h3><p>Adjust the resources and gameplay settings for this server instance.</p></div><button className="button button-primary" onClick={() => void saveSettings()} disabled={!!working}><Check size={13} /> Save settings</button></div>
            <div className="server-form-grid"><label className="field"><span>SERVER NAME</span><input value={settingsDraft.name} onChange={e => setSettingsDraft({ ...settingsDraft, name: e.target.value, motd: settingsDraft.motd === selected.name ? e.target.value : settingsDraft.motd })} /></label><label className="field"><span>JAVA EXECUTABLE (OPTIONAL)</span><input value={settingsDraft.javaPath ?? ''} onChange={e => setSettingsDraft({ ...settingsDraft, javaPath: e.target.value || null })} placeholder="java (PATH) or full java.exe path" /></label><label className="field"><span>RAM LIMIT</span><select value={settingsDraft.ramMb} onChange={e => setSettingsDraft({ ...settingsDraft, ramMb: Number(e.target.value) })}>{[2048,4096,6144,8192,12288,16384,24576,32768].map(value => <option key={value} value={value}>{value / 1024} GB</option>)}</select></label><label className="field"><span>CPU THREAD HINT</span><input type="number" min={1} max={64} value={settingsDraft.cpuThreads} onChange={e => setSettingsDraft({ ...settingsDraft, cpuThreads: Math.max(1, Math.min(64, Number(e.target.value))) })} /></label><label className="field"><span>SERVER PORT</span><input type="number" min={1} max={65535} value={settingsDraft.port} onChange={e => setSettingsDraft({ ...settingsDraft, port: Number(e.target.value) })} /></label><label className="field"><span>MAXIMUM PLAYERS</span><input type="number" min={1} max={1000} value={settingsDraft.maxPlayers} onChange={e => setSettingsDraft({ ...settingsDraft, maxPlayers: Number(e.target.value) })} /></label><label className="field full-field"><span>MOTD</span><input value={settingsDraft.motd} onChange={e => setSettingsDraft({ ...settingsDraft, motd: e.target.value })} maxLength={120} /></label></div>
            <label className="toggle-row server-toggle"><span><strong>Online mode</strong><small>Require Microsoft-authenticated Minecraft accounts to join. Turn off only for a private offline-mode server.</small></span><input type="checkbox" checked={settingsDraft.onlineMode} onChange={e => setSettingsDraft({ ...settingsDraft, onlineMode: e.target.checked })} /></label>
            <div className="server-inline-warning"><AlertTriangle size={15} /> Changing server.properties usually takes effect after the next restart. Resource limits apply on the next start.</div>
            <div className="server-content-subsection"><div className="section-heading"><div><h3>Server properties editor</h3><p>Edit the raw server.properties file if you need advanced options.</p></div><button className="button button-secondary" onClick={() => void openEditor('server.properties')}><Code2 size={13} /> Open editor</button></div></div>
          </div>}

          {tab === 'Network' && <div className="server-content-card"><div className="section-heading"><div><h3>Playit.gg network tunnel</h3><p>Share this server without router port forwarding.</p></div><span className={`pill ${playitRunning ? 'pill-success' : 'pill-muted'}`}>{playitRunning ? 'AGENT RUNNING' : 'AGENT STOPPED'}</span></div>
            <div className="playit-card"><div className="playit-mark"><Network size={24} /></div><div className="playit-copy"><strong>Playit.gg Windows service</strong><p>The official Windows installer registers the <code>playitd</code> service and tray app. VOID CLIENT controls the service and reads its recent log file. In your Playit dashboard, create a Minecraft Java tunnel and point it to local TCP port <b>{selected.port}</b>.</p></div></div>
            <div className="server-quick-actions"><button className="button button-secondary" disabled={!!working} onClick={() => void runAction('Install Playit agent', () => api.installPlayitWithWinget())}><ArrowDownToLine size={13} /> Install agent (winget)</button>{playitRunning ? <button className="button button-secondary" onClick={() => void runAction('Stop Playit service', () => api.stopPlayitAgent())}><Square size={13} /> Stop service</button> : <button className="button button-primary" disabled={!!working} onClick={() => void runAction('Start Playit service', () => api.startPlayitAgent(selected.id))}><Play size={13} /> Start service</button>}<button className="button button-secondary" onClick={() => void api.openExternalUrl('https://playit.gg/account/tunnels').catch(error => onNotice(String(error)))}>Open tunnel dashboard <ExternalLink size={13} /></button></div>
            <div className="integration-notice"><div className="notice-icon"><CircleHelp size={17} /></div><div><strong>One-time Playit setup</strong><p>The official Windows installer creates a background service named <code>playitd</code> and a tray application. VOID CLIENT can install and control that service. Claim/link the agent in the Playit tray app, then create a Minecraft Java tunnel in the official dashboard. Select TCP and use local port {selected.port}.</p></div></div>
          </div>}
        </>}
      </section>
    </div>

    {editName && <div className="modal-backdrop"><div className="modal-card server-editor-modal"><div className="modal-header"><div><div className="eyebrow">SERVER FILE EDITOR</div><h2>{editName}</h2></div><button className="icon-button" onClick={() => setEditName(null)}><X size={15} /></button></div><textarea className="server-text-editor" value={editContents} onChange={e => setEditContents(e.target.value)} spellCheck={false} /><div className="modal-actions"><button className="button button-secondary" onClick={() => setEditName(null)}>Cancel</button><button className="button button-primary" onClick={() => void saveEditor()}><Check size={13} /> Save file</button></div></div></div>}
  </div>;
}
