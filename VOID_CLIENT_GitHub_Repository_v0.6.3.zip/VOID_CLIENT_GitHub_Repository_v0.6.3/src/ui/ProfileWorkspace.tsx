import { useCallback, useEffect, useMemo, useState } from 'react';
import { listen } from '@tauri-apps/api/event';
import {
  ArrowLeft, ArrowUpRight, Box, Check, ChevronRight, CircleAlert, Download, ExternalLink,
  FileCode2, FileText, Folder, HardDrive, Layers3, LoaderCircle, Package,
  Palette, RefreshCw, Search, Settings2, ShieldCheck, Trash2, X, Play, Cpu, DownloadCloud, Terminal,
} from 'lucide-react';
import type { CurseForgeMod, EngineProgress, EngineStatus, JavaRuntime, ModrinthProject, Profile, ProfileFile } from './types';
import { api } from './storage';

type WorkspaceTab = 'Overview' | 'Mods' | 'Resource Packs' | 'Shaders' | 'Config' | 'Worlds' | 'Logs';
const sections: { name: WorkspaceTab; icon: typeof Package; folder: string }[] = [
  { name: 'Overview', icon: Box, folder: '' },
  { name: 'Mods', icon: Package, folder: 'mods' },
  { name: 'Resource Packs', icon: Layers3, folder: 'resourcepacks' },
  { name: 'Shaders', icon: Palette, folder: 'shaderpacks' },
  { name: 'Config', icon: FileCode2, folder: 'config' },
  { name: 'Worlds', icon: HardDrive, folder: 'saves' },
  { name: 'Logs', icon: FileText, folder: 'logs' },
];

function formatBytes(value: number) {
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}
function formatDownloads(value: number) {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return String(value);
}
function categoryFor(tab: WorkspaceTab) {
  return tab === 'Mods' ? 'mods' : tab === 'Resource Packs' ? 'resourcepacks' : tab === 'Shaders' ? 'shaderpacks' : tab === 'Config' ? 'config' : tab === 'Worlds' ? 'saves' : 'logs';
}
function projectTypeFor(tab: WorkspaceTab) {
  return tab === 'Mods' ? 'mod' : tab === 'Resource Packs' ? 'resourcepack' : 'shader';
}

export function ProfileWorkspace({ profile, initialTab = 'Overview', onBack, onEdit, onNotice, onRefresh, onOpenConsole }: {
  profile: Profile; initialTab?: WorkspaceTab; onBack: () => void; onEdit: (profile: Profile) => void; onNotice: (message: string) => void; onRefresh: () => Promise<void>; onOpenConsole: () => void;
}) {
  const [tab, setTab] = useState<WorkspaceTab>(initialTab);
  const [files, setFiles] = useState<ProfileFile[]>([]);
  const [loadingFiles, setLoadingFiles] = useState(false);
  const [query, setQuery] = useState('');
  const [hits, setHits] = useState<ModrinthProject[]>([]);
  const [curseForgeHits, setCurseForgeHits] = useState<CurseForgeMod[]>([]);
  const [catalogSource, setCatalogSource] = useState<'Modrinth' | 'CurseForge'>('Modrinth');
  const [loadingCatalog, setLoadingCatalog] = useState(false);
  const [catalogError, setCatalogError] = useState('');
  const [installing, setInstalling] = useState<string | null>(null);
  const [catalogSort, setCatalogSort] = useState('downloads');
  const [curseForgeKeyAvailable, setCurseForgeKeyAvailable] = useState(false);
  const [fileFilter, setFileFilter] = useState('');
  const [editingFile, setEditingFile] = useState<string | null>(null);
  const [editorText, setEditorText] = useState('');
  const [savingText, setSavingText] = useState(false);
  const [engineStatus, setEngineStatus] = useState<EngineStatus | null>(null);
  const [engineBusy, setEngineBusy] = useState(false);
  const [javaRuntimes, setJavaRuntimes] = useState<JavaRuntime[]>([]);
  const [javaBusy, setJavaBusy] = useState<number | null>(null);
  const [engineProgress, setEngineProgress] = useState<EngineProgress | null>(null);

  const isDiscoverable = tab === 'Mods' || tab === 'Resource Packs' || tab === 'Shaders';
  const folder = categoryFor(tab);
  const refreshFiles = useCallback(async () => {
    if (tab === 'Overview') return;
    setLoadingFiles(true);
    try { setFiles(await api.getProfileFiles(profile.id, folder)); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not read profile folder.'); }
    finally { setLoadingFiles(false); }
  }, [folder, onNotice, profile.id, tab]);

  useEffect(() => { void refreshFiles(); }, [refreshFiles]);

  const refreshEngine = useCallback(async () => {
    try {
      const [status, runtimes] = await Promise.all([api.getEngineStatus(profile.id), api.detectJavaRuntimes()]);
      setEngineStatus(status); setJavaRuntimes(runtimes);
    } catch { /* Native engine status is unavailable in browser preview. */ }
  }, [profile.id]);

  useEffect(() => { void refreshEngine(); }, [refreshEngine]);
  useEffect(() => { void api.hasCurseForgeApiKey().then(setCurseForgeKeyAvailable).catch(() => setCurseForgeKeyAvailable(false)); }, []);
  useEffect(() => {
    let unlisten: (() => void) | undefined;
    void listen<EngineProgress>('void-engine-progress', event => {
      if (event.payload.profileId === profile.id || event.payload.profileId === 'runtime') setEngineProgress(event.payload);
    }).then(stop => { unlisten = stop; });
    return () => { unlisten?.(); };
  }, [profile.id]);

  const installGame = async () => {
    setEngineBusy(true); setEngineProgress({ profileId: profile.id, stage: 'starting', done: 0, total: 1, percent: 0, detail: 'Preparing Minecraft installation…' });
    try { const message = await api.installProfileLoader(profile.id); await refreshEngine(); await refreshFiles(); await onRefresh(); onNotice(message); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Minecraft installation failed.'); }
    finally { setEngineBusy(false); }
  };

  const launchGame = async () => {
    if (!engineStatus?.installed) { onNotice('Install Minecraft and the selected loader before launching.'); return; }
    if (!engineStatus.javaFound) { onNotice(`Install Java ${engineStatus.javaRequired} in the Java runtime manager first.`); return; }
    setEngineBusy(true);
    onOpenConsole();
    onNotice(`Starting ${profile.name}. Live output is opening in Console…`);
    try { onNotice(await api.launchProfile(profile.id)); await onRefresh(); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Minecraft could not be launched. Open Console for details.'); }
    finally { setEngineBusy(false); await refreshEngine(); }
  };

  const diagnoseGame = async () => {
    setEngineBusy(true);
    onOpenConsole();
    onNotice(`Checking ${profile.name}. See Console for Java and installation diagnostics…`);
    try { onNotice(await api.diagnoseProfile(profile.id)); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Profile diagnostics failed. See Console for details.'); }
    finally { setEngineBusy(false); await refreshEngine(); }
  };

  const installJava = async (major: number) => {
    setJavaBusy(major);
    try { const runtime = await api.installJavaRuntime(major); await refreshEngine(); onNotice(`Java ${runtime.major} installed.`); }
    catch (error) { onNotice(error instanceof Error ? error.message : `Java ${major} installation failed.`); }
    finally { setJavaBusy(null); }
  };

  const searchCatalog = useCallback(async (searchText: string, sort = catalogSort) => {
    if (!isDiscoverable) return;
    setLoadingCatalog(true); setCatalogError('');
    try {
      if (tab === 'Mods' && catalogSource === 'CurseForge') {
        if (!curseForgeKeyAvailable) throw new Error('Add your approved CurseForge API key in Settings → Integrations to browse CurseForge mods.');
        const loaderCode = profile.loader === 'Forge' ? 1 : profile.loader === 'Fabric' ? 4 : profile.loader === 'Quilt' ? 5 : profile.loader === 'NeoForge' ? 6 : 0;
        setHits([]);
        setCurseForgeHits(await api.searchCurseForge(searchText.trim(), 6, profile.minecraftVersion, loaderCode));
      } else {
        setCurseForgeHits([]);
        const type = projectTypeFor(tab);
        setHits(await api.searchModrinth(searchText.trim(), type, profile.minecraftVersion, profile.loader, sort));
      }
    } catch (error) {
      setHits([]); setCurseForgeHits([]);
      setCatalogError(error instanceof Error ? error.message : `Could not reach ${catalogSource}.`);
    } finally { setLoadingCatalog(false); }
  }, [catalogSort, catalogSource, curseForgeKeyAvailable, isDiscoverable, profile.loader, profile.minecraftVersion, tab]);

  useEffect(() => {
    if (!isDiscoverable) return;
    const timer = window.setTimeout(() => { void searchCatalog(query); }, query ? 350 : 0);
    return () => window.clearTimeout(timer);
  }, [isDiscoverable, query, searchCatalog]);

  const install = async (hit: ModrinthProject) => {
    if (tab === 'Mods' && profile.loader === 'Vanilla') {
      onNotice('Mods need a mod loader. Edit this profile and choose Fabric, Forge, NeoForge or Quilt first.');
      return;
    }
    setInstalling(hit.project_id);
    try {
      const installed = await api.installModrinthProject(profile.id, hit.project_id, folder);
      await refreshFiles();
      onNotice(installed.length > 1 ? `${hit.title} installed with ${installed.length - 1} required dependency item(s).` : `${hit.title} installed into ${profile.name}.`);
    } catch (error) {
      onNotice(error instanceof Error ? error.message : 'Could not install this project.');
    } finally { setInstalling(null); }
  };

  const installCurseForge = async (hit: CurseForgeMod) => {
    if (profile.loader === 'Vanilla') { onNotice('CurseForge mods need Fabric, Forge, NeoForge or Quilt.'); return; }
    const file = hit.latestFiles?.[0];
    if (!file?.id) { onNotice('CurseForge did not return a compatible release file for this mod.'); return; }
    setInstalling(`cf-${hit.id}`);
    try {
      const installed = await api.installCurseForgeMod(profile.id, hit.id, file.id);
      await refreshFiles();
      onNotice(installed.length > 1 ? `${hit.name} installed with ${installed.length - 1} required CurseForge dependencies.` : `${hit.name} installed into ${profile.name}.`);
    } catch (error) { onNotice(error instanceof Error ? error.message : 'CurseForge mod installation failed.'); }
    finally { setInstalling(null); }
  };

  const openTextEditor = async (file: ProfileFile) => {
    try { setEditorText(await api.readProfileTextFile(profile.id, file.name)); setEditingFile(file.name); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not open text file.'); }
  };
  const saveTextEditor = async () => {
    if (!editingFile) return; setSavingText(true);
    try { await api.writeProfileTextFile(profile.id, editingFile, editorText); setEditingFile(null); onNotice(`${editingFile} saved.`); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not save file.'); }
    finally { setSavingText(false); }
  };
  const toggleMod = async (file: ProfileFile) => {
    const enabled = file.name.toLowerCase().endsWith('.jar.disabled');
    try { await api.toggleProfileMod(profile.id, file.name, enabled); await refreshFiles(); onNotice(`${file.name} ${enabled ? 'enabled' : 'disabled'}.`); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not change mod state.'); }
  };

  const removeFile = async (file: ProfileFile) => {
    if (!window.confirm(`Remove ${file.name} from ${profile.name}?`)) return;
    try { await api.removeProfileFile(profile.id, folder, file.name); await refreshFiles(); onNotice(`${file.name} removed.`); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not remove file.'); }
  };

  const filteredFiles = useMemo(() => files.filter(file => file.name.toLowerCase().includes(fileFilter.toLowerCase())), [files, fileFilter]);
  const countLabel = files.length === 1 ? '1 item' : `${files.length} items`;

  return <div className="workspace-page">
    <div className="workspace-topline">
      <button className="back-link" onClick={onBack}><ArrowLeft size={15} /> Profiles</button>
      <div className="workspace-actions"><span className="workspace-isolation"><ShieldCheck size={13} /> ISOLATED INSTANCE</span><button className="button button-secondary" onClick={() => onEdit(profile)}><Settings2 size={15} /> Profile settings</button></div>
    </div>
    <section className="workspace-hero">
      <div className="workspace-hero-glow" />
      <div className="workspace-profile-emblem">{profile.name.slice(0, 1).toUpperCase()}</div>
      <div className="workspace-profile-copy"><div className="eyebrow">PROFILE WORKSPACE</div><h1>{profile.name}</h1><div className="workspace-meta"><span>{profile.minecraftVersion}</span><i /> <span>{profile.loader}</span><i /> <span>{profile.ramGb} GB RAM</span></div><p>Manage everything that belongs to this instance. Files and downloads stay inside this profile.</p></div>
      <div className="workspace-hero-buttons"><button className="button button-primary" onClick={() => void launchGame()} disabled={engineBusy || !engineStatus?.installed || !engineStatus?.javaFound}><Play size={15} fill="currentColor" /> {engineBusy ? 'Working…' : 'PLAY'}</button><button className="button button-ghost" onClick={() => void installGame()} disabled={engineBusy}><DownloadCloud size={15} /> {engineStatus?.installed ? 'Repair / reinstall' : `Install ${profile.loader}`}</button><button className="button button-ghost" onClick={() => api.openProfileFolder(profile.id).catch(e => onNotice(String(e)))}><Folder size={15} /> Open profile folder</button></div>
    </section>
    <div className="workspace-tabs" role="tablist" aria-label="Profile sections">
      {sections.map(section => { const Icon = section.icon; return <button key={section.name} role="tab" aria-selected={tab === section.name} className={`workspace-tab ${tab === section.name ? 'active' : ''}`} onClick={() => { setTab(section.name); setQuery(''); setFileFilter(''); }}><Icon size={15} /><span>{section.name}</span>{section.folder && tab === section.name && <b>{files.length}</b>}</button>; })}
    </div>

    {tab === 'Overview' ? <div className="workspace-overview">
      <div className="settings-card engine-install-card">
        <div className="workspace-section-header"><div><div className="eyebrow">MINECRAFT ENGINE</div><h2>{engineStatus?.installed ? 'Game files are installed' : 'Install this profile'}</h2><p>{engineStatus?.installed ? `Installed runtime: ${engineStatus.installedVersion ?? profile.minecraftVersion}` : `VOID CLIENT will download Minecraft ${profile.minecraftVersion}, its libraries and assets, then install ${profile.loader}.`}</p></div><span className={`engine-status-pill ${engineStatus?.installed ? 'ready' : 'missing'}`}>{engineStatus?.installed ? 'INSTALLED' : 'NOT INSTALLED'}</span></div>
        <div className="engine-action-row"><button className="button button-primary" onClick={() => void installGame()} disabled={engineBusy}>{engineBusy ? 'Working…' : engineStatus?.installed ? 'Repair / reinstall game' : `Install Minecraft + ${profile.loader}`}</button><button className="button button-secondary" onClick={() => void diagnoseGame()} disabled={engineBusy || !engineStatus?.installed}><Terminal size={14} /> Check setup</button><button className="button button-secondary" onClick={() => void launchGame()} disabled={engineBusy || !engineStatus?.installed || !engineStatus?.javaFound}><Play size={14} fill="currentColor" /> PLAY</button><span className="engine-requirement">Requires Java {engineStatus?.javaRequired ?? 21}{engineStatus?.javaFound ? ' · runtime ready' : ' · runtime missing'}</span></div>
        {engineProgress && engineBusy && <div className="engine-progress"><div className="engine-progress-copy"><span>{engineProgress.detail}</span><strong>{engineProgress.percent}%</strong></div><div className="engine-progress-track"><i style={{ width: `${engineProgress.percent}%` }} /></div></div>}
      </div>
      <div className="settings-card java-manager-card"><div className="workspace-section-header"><div><div className="eyebrow">RUNTIME MANAGER</div><h2>Java installations</h2><p>VOID CLIENT detects installed Java runtimes and can install Temurin runtimes locally.</p></div><Cpu size={20} /></div>
        {javaRuntimes.length ? <div className="java-runtime-list">{javaRuntimes.map(runtime => <div className="java-runtime-row" key={runtime.path}><div><strong>Java {runtime.major}</strong><span>{runtime.source} · {runtime.path}</span></div><span className="engine-status-pill ready">DETECTED</span></div>)}</div> : <div className="installed-empty"><Cpu size={17} /> No Java runtime detected yet.</div>}
        <div className="java-install-actions">{[8, 17, 21, 25].map(major => <button key={major} className="button button-secondary" onClick={() => void installJava(major)} disabled={javaBusy !== null}>{javaBusy === major ? 'Installing…' : `Install Java ${major}`}</button>)}</div>
      </div>
      <div className="overview-stats"><div className="overview-stat"><span>GAME VERSION</span><strong>{profile.minecraftVersion}</strong><small>Target version</small></div><div className="overview-stat"><span>MOD LOADER</span><strong>{profile.loader}</strong><small>Instance runtime</small></div><div className="overview-stat"><span>MEMORY</span><strong>{profile.ramGb} GB</strong><small>Maximum allocation</small></div><div className="overview-stat"><span>PROFILE STATUS</span><strong className="status-ready">Folders ready</strong><small>Instance directory created</small></div></div>
      <div className="workspace-overview-grid"><div className="settings-card workspace-shortcuts"><div className="section-heading compact-heading"><div><h3>Instance manager</h3><p>Jump into a specific part of this profile.</p></div></div><div className="workspace-shortcut-grid">{sections.slice(1).map(section => { const Icon = section.icon; return <button className="workspace-shortcut" key={section.name} onClick={() => setTab(section.name)}><span><Icon size={17} /></span><strong>{section.name}</strong><ChevronRight size={14} /></button>; })}</div></div>
        <div className="settings-card workspace-health"><div className="eyebrow">INSTANCE HEALTH</div><h3>Everything has its own place.</h3><p>Mods, shader packs, resource packs, configs and worlds are stored in profile-specific folders. Removing a file here does not affect another profile.</p><div className="health-line"><ShieldCheck size={16} /><span>Profile isolation active</span><Check size={15} /></div><div className="health-line"><HardDrive size={16} /><span>Local folders created</span><Check size={15} /></div><div className="health-line"><CircleAlert size={16} /><span>Game installation</span><em>{engineStatus?.installed ? 'Installed' : 'Not installed'}</em></div><div className="health-line"><Cpu size={16} /><span>Java runtime</span><em>{engineStatus?.javaFound ? 'Ready' : 'Missing'}</em></div></div></div>
    </div> : <div className="workspace-content-grid">
      <section className="settings-card workspace-main-card">
        <div className="workspace-section-header"><div><div className="eyebrow">{isDiscoverable ? (tab === 'Mods' && catalogSource === 'CurseForge' ? 'CURSEFORGE CATALOG' : 'MODRINTH CATALOG') : 'PROFILE FILES'}</div><h2>{tab}</h2><p>{isDiscoverable ? `Browse files compatible with Minecraft ${profile.minecraftVersion}${tab === 'Mods' ? ` · ${profile.loader}` : ''}.` : `Manage the ${folder} folder inside ${profile.name}.`}</p></div><button className="icon-button" title="Refresh" onClick={() => { void refreshFiles(); if (isDiscoverable) void searchCatalog(query); }}><RefreshCw size={15} /></button></div>
        {isDiscoverable && <>
          {tab === 'Mods' && profile.loader === 'Vanilla' && <div className="workspace-warning"><CircleAlert size={15} /><span>This profile is Vanilla. Switch it to Fabric, Forge, NeoForge or Quilt before installing mods.</span></div>}
          <div className="installed-section">
            <div className="installed-section-heading"><div><div className="eyebrow">PROFILE LIBRARY</div><h3>Installed in {profile.name}</h3><p>{loadingFiles ? 'Reading this profile folder…' : `${files.length} ${files.length === 1 ? 'file' : 'files'} in ${folder}/`}</p></div><div className="installed-section-actions"><div className="file-search"><Search size={13} /><input value={fileFilter} onChange={e => setFileFilter(e.target.value)} placeholder="Filter installed…" /></div><button className="button button-secondary" onClick={() => api.openProfileCategory(profile.id, folder).catch(e => onNotice(String(e)))}><Folder size={13} /> Open folder</button></div></div>
            {loadingFiles ? <div className="inline-loading compact-loading"><LoaderCircle size={17} className="spin" /> Scanning profile files…</div> : filteredFiles.length === 0 ? <div className="installed-empty"><Package size={18} /><span>{files.length ? 'No installed files match this filter.' : `Nothing installed here yet. Add ${tab.toLowerCase()} from the catalog below.`}</span></div> : <div className="file-list installed-file-list">{filteredFiles.map(file => <div className="file-row" key={file.name}><div className="file-type-icon">{file.isDirectory ? <Folder size={16} /> : <FileText size={16} />}</div><div className="file-name"><strong>{file.name}</strong><span>{file.isDirectory ? 'Folder' : formatBytes(file.size)}</span></div>{tab === 'Mods' && !file.isDirectory && (file.name.toLowerCase().endsWith('.jar') || file.name.toLowerCase().endsWith('.jar.disabled')) && <button className="button button-secondary file-action-button" onClick={() => void toggleMod(file)}>{file.name.toLowerCase().endsWith('.jar.disabled') ? 'Enable' : 'Disable'}</button>}<button className="icon-button danger-icon" title={file.isDirectory ? 'Remove folder' : 'Remove file'} onClick={() => void removeFile(file)}><Trash2 size={14} /></button></div>)}</div>}
          </div>
          <div className="catalog-discovery-heading"><div><div className="eyebrow">{tab === 'Mods' ? 'MOD DISCOVERY' : 'MODRINTH DISCOVERY'}</div><h3>Find new {tab.toLowerCase()}</h3><p>Compatible releases are selected automatically. Required dependencies are resolved when the source provides them.</p></div></div>
          {tab === 'Mods' && <div className="catalog-source-switch"><button className={catalogSource === 'Modrinth' ? 'selected' : ''} onClick={() => setCatalogSource('Modrinth')}>Modrinth</button><button className={catalogSource === 'CurseForge' ? 'selected' : ''} onClick={() => setCatalogSource('CurseForge')}>CurseForge</button>{catalogSource === 'CurseForge' && !curseForgeKeyAvailable && <span>API key required · Settings → Integrations</span>}</div>}
          <div className="catalog-toolbar"><div className="catalog-search"><Search size={15} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder={`Search ${tab.toLowerCase()} on ${tab === 'Mods' ? catalogSource : 'Modrinth'}…`} /><button onClick={() => void searchCatalog(query)}><Search size={14} /></button></div><select value={catalogSort} onChange={e => setCatalogSort(e.target.value)}><option value="downloads">Most downloaded</option><option value="relevance">Relevance</option><option value="newest">Newest</option><option value="updated">Recently updated</option></select></div>
          {loadingCatalog ? <div className="inline-loading"><LoaderCircle className="spin" size={20} /> Searching {tab === 'Mods' ? catalogSource : 'Modrinth'}…</div> : catalogError ? <div className="inline-error"><CircleAlert size={17} /><span>{catalogError}</span><button className="text-button" onClick={() => void searchCatalog(query)}>Retry</button></div> : tab === 'Mods' && catalogSource === 'CurseForge' ? (curseForgeHits.length === 0 ? <div className="workspace-empty"><Package size={25} /><strong>No CurseForge mods found</strong><p>Try another search or check your API-key access and loader filter.</p></div> : <div className="catalog-grid">{curseForgeHits.map(hit => <article className="catalog-card" key={hit.id}>
            <div className="catalog-card-top">{hit.logo?.thumbnailUrl ? <img src={hit.logo.thumbnailUrl} alt="" /> : <div className="catalog-icon-fallback"><Package size={18} /></div>}<div className="catalog-card-title"><strong>{hit.name}</strong><span>CurseForge · {formatDownloads(hit.downloadCount)} downloads</span></div><button type="button" className="catalog-external" onClick={() => void api.openExternalUrl(`https://www.curseforge.com/minecraft/mc-mods/${hit.slug}`).catch(e => onNotice(String(e)))} title="Open CurseForge page"><ExternalLink size={13} /></button></div>
            <p>{hit.summary}</p><div className="catalog-card-bottom"><span>{hit.latestFiles?.[0]?.fileName ?? 'Latest compatible file'}</span><button className="button button-secondary" onClick={() => void installCurseForge(hit)} disabled={installing !== null || profile.loader === 'Vanilla' || !hit.latestFiles?.length}>{installing === `cf-${hit.id}` ? <><LoaderCircle size={13} className="spin" /> Installing</> : <><Download size={13} /> Install</>}</button></div>
          </article>)}</div>) : hits.length === 0 ? <div className="workspace-empty"><Package size={25} /><strong>No results found</strong><p>Try another search or check your connection.</p></div> : <div className="catalog-grid">{hits.map(hit => <article className="catalog-card" key={hit.project_id}>
            <div className="catalog-card-top">{hit.icon_url ? <img src={hit.icon_url} alt="" /> : <div className="catalog-icon-fallback"><Package size={18} /></div>}<div className="catalog-card-title"><strong>{hit.title}</strong><span>by {hit.author}</span></div><button type="button" className="catalog-external" onClick={() => void api.openExternalUrl(`https://modrinth.com/${hit.project_type}/${hit.slug}`).catch(e => onNotice(String(e)))} title="Open Modrinth page"><ExternalLink size={13} /></button></div>
            <p>{hit.description}</p><div className="catalog-card-bottom"><span><Download size={12} /> {formatDownloads(hit.downloads)}</span><button className="button button-secondary" onClick={() => void install(hit)} disabled={installing !== null || (tab === 'Mods' && profile.loader === 'Vanilla')}>{installing === hit.project_id ? <><LoaderCircle size={13} className="spin" /> Installing</> : <><Download size={13} /> Install</>}</button></div>
          </article>)}</div>}
        </>}
        {!isDiscoverable && <>
          <div className="file-toolbar"><div className="file-count"><span className="green-dot" /> {loadingFiles ? 'SCANNING' : countLabel.toUpperCase()}</div><div className="file-toolbar-actions"><div className="file-search"><Search size={13} /><input value={fileFilter} onChange={e => setFileFilter(e.target.value)} placeholder="Filter files…" /></div><button className="button button-secondary" onClick={() => api.openProfileCategory(profile.id, folder).catch(e => onNotice(String(e)))}><Folder size={13} /> Open folder</button></div></div>
          {loadingFiles ? <div className="inline-loading"><LoaderCircle size={19} className="spin" /> Reading profile files…</div> : filteredFiles.length === 0 ? <div className="workspace-empty"><Folder size={25} /><strong>This folder is empty</strong><p>Files added here will stay isolated to {profile.name}.</p><button className="button button-secondary" onClick={() => api.openProfileCategory(profile.id, folder).catch(e => onNotice(String(e)))}><Folder size={14} /> Open folder</button></div> : <div className="file-list">{filteredFiles.map(file => <div className="file-row" key={file.name}><div className="file-type-icon">{file.isDirectory ? <Folder size={16} /> : tab === 'Config' ? <FileCode2 size={16} /> : <FileText size={16} />}</div><div className="file-name"><strong>{file.name}</strong><span>{file.isDirectory ? 'Folder' : formatBytes(file.size)}</span></div>{tab === 'Config' && !file.isDirectory && /\.(json|txt|properties|toml|cfg|yml|yaml)$/i.test(file.name) && <button className="button button-secondary file-action-button" onClick={() => void openTextEditor(file)}>Edit</button>}<button className="icon-button danger-icon" title="Remove file" onClick={() => void removeFile(file)}><Trash2 size={14} /></button></div>)}</div>}
        </>}
      </section>
      <aside className="settings-card workspace-side-card"><div className="eyebrow">PROFILE CONTEXT</div><h3>{profile.name}</h3><p>Every action on this page targets this one isolated profile.</p><div className="context-row"><span>Version</span><strong>{profile.minecraftVersion}</strong></div><div className="context-row"><span>Loader</span><strong>{profile.loader}</strong></div><div className="context-row"><span>Directory</span><strong>{folder || 'profile root'}</strong></div><div className="context-divider" />
        <div className="context-note"><ShieldCheck size={15} /><span>Catalog results are requested from Modrinth. Downloads are stored directly in this profile's folder.</span></div>
        {isDiscoverable && <button type="button" className="modrinth-link" onClick={() => void api.openExternalUrl('https://modrinth.com').catch(e => onNotice(String(e)))}>Modrinth <ArrowUpRight size={13} /></button>}
      </aside>
    </div>}
    {editingFile && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setEditingFile(null); }}><div className="modal-card config-editor-modal"><div className="modal-header"><div><div className="eyebrow">PROFILE CONFIGURATION</div><h2>{editingFile}</h2></div><button className="icon-button" onClick={() => setEditingFile(null)}><X size={17} /></button></div><textarea className="config-editor-textarea" spellCheck={false} value={editorText} onChange={e => setEditorText(e.target.value)} /><div className="modal-footnote"><ShieldCheck size={14} /> Saved directly to this profile's config folder.</div><div className="modal-actions"><button className="button button-secondary" onClick={() => setEditingFile(null)}>Cancel</button><button className="button button-primary" onClick={() => void saveTextEditor()} disabled={savingText}>{savingText ? 'Saving…' : 'Save file'}</button></div></div></div>}
  </div>;
}
