import { invoke } from '@tauri-apps/api/core';
import type { AccountSummary, DeviceCode, LauncherSettings, ModrinthProject, Profile, ProfileFile, GameVersion, JavaRuntime, EngineStatus, CurseForgeMod, ServerInfo, ServerInstance, ServerFile, ServerModInstallResult } from './types';
import { defaultSettings } from './types';

const isDesktop = () => typeof window !== 'undefined' && '__TAURI_INTERNALS__' in window;
const PROFILE_KEY = 'void-client.profiles.v1';
const SETTINGS_KEY = 'void-client.settings.v1';

const readLocalProfiles = (): Profile[] => {
  try { return JSON.parse(localStorage.getItem(PROFILE_KEY) || '[]') as Profile[]; }
  catch { return []; }
};

export const api = {
  isDesktop,
  async getProfiles(): Promise<Profile[]> {
    if (isDesktop()) return invoke<Profile[]>('get_profiles');
    return readLocalProfiles();
  },
  async createProfile(input: { name: string; minecraftVersion: string; loader: string; ramGb: number }): Promise<Profile> {
    if (isDesktop()) return invoke<Profile>('create_profile', input);
    const profile: Profile = {
      id: `p${Date.now()}`, ...input, loader: input.loader as Profile['loader'],
      createdAt: Date.now(), lastPlayed: null, javaPath: null, jvmArgs: '',
      gameWidth: 1280, gameHeight: 720, fullscreen: false,
    };
    const all = readLocalProfiles();
    localStorage.setItem(PROFILE_KEY, JSON.stringify([...all, profile]));
    return profile;
  },
  async updateProfile(profile: Profile): Promise<Profile> {
    if (isDesktop()) return invoke<Profile>('update_profile', { profile });
    localStorage.setItem(PROFILE_KEY, JSON.stringify(readLocalProfiles().map(p => p.id === profile.id ? profile : p)));
    return profile;
  },
  async duplicateProfile(profileId: string): Promise<Profile> {
    if (isDesktop()) return invoke<Profile>('duplicate_profile', { profileId });
    const original = readLocalProfiles().find(p => p.id === profileId);
    if (!original) throw new Error('Profile not found.');
    const copy = { ...original, id: `p${Date.now()}`, name: `${original.name} Copy`, createdAt: Date.now(), lastPlayed: null };
    localStorage.setItem(PROFILE_KEY, JSON.stringify([...readLocalProfiles(), copy]));
    return copy;
  },
  async deleteProfile(profileId: string): Promise<void> {
    if (isDesktop()) return invoke('delete_profile', { profileId });
    localStorage.setItem(PROFILE_KEY, JSON.stringify(readLocalProfiles().filter(p => p.id !== profileId)));
  },
  async openProfileFolder(profileId: string): Promise<void> {
    if (isDesktop()) return invoke('open_profile_folder', { profileId });
    throw new Error('Open folder is available in the Windows desktop app.');
  },
  async getSettings(): Promise<LauncherSettings> {
    if (isDesktop()) return invoke<LauncherSettings>('get_settings');
    try { return { ...defaultSettings, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }; }
    catch { return defaultSettings; }
  },
  async saveSettings(settings: LauncherSettings): Promise<void> {
    if (isDesktop()) return invoke('save_settings', { settings });
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  },
  async getStoragePath(): Promise<string> {
    if (isDesktop()) return invoke<string>('get_storage_path');
    return 'Browser preview storage (localStorage)';
  },
  async getProfileFiles(profileId: string, category: string): Promise<ProfileFile[]> {
    if (!isDesktop()) return [];
    return invoke<ProfileFile[]>('get_profile_files', { profileId, category });
  },
  async removeProfileFile(profileId: string, category: string, fileName: string): Promise<void> {
    if (!isDesktop()) throw new Error('File management is available in the Windows desktop app.');
    return invoke('remove_profile_file', { profileId, category, fileName });
  },
  async toggleProfileMod(profileId: string, fileName: string, enabled: boolean): Promise<void> {
    if (!isDesktop()) throw new Error('Mod management is available in the Windows desktop app.');
    return invoke('toggle_profile_mod', { profileId, fileName, enabled });
  },
  async readProfileTextFile(profileId: string, fileName: string): Promise<string> {
    if (!isDesktop()) throw new Error('Config editing is available in the Windows desktop app.');
    return invoke<string>('read_profile_text_file', { profileId, fileName });
  },
  async writeProfileTextFile(profileId: string, fileName: string, contents: string): Promise<void> {
    if (!isDesktop()) throw new Error('Config editing is available in the Windows desktop app.');
    return invoke('write_profile_text_file', { profileId, fileName, contents });
  },
  async openProfileCategory(profileId: string, category: string): Promise<void> {
    if (!isDesktop()) throw new Error('Open folder is available in the Windows desktop app.');
    return invoke('open_profile_category', { profileId, category });
  },
  async installRemoteFile(profileId: string, category: string, fileName: string, url: string, expectedSha512?: string): Promise<ProfileFile> {
    if (!isDesktop()) throw new Error('Downloads are available in the Windows desktop app.');
    return invoke<ProfileFile>('install_remote_file', { profileId, category, fileName, url, expectedSha512: expectedSha512 ?? null });
  },
  async searchModrinth(query: string, projectType: string, minecraftVersion: string, loader: string, sort: string): Promise<ModrinthProject[]> {
    if (isDesktop()) {
      const result = await invoke<{ hits?: ModrinthProject[] }>('search_modrinth', { query, projectType, minecraftVersion, loader, sort });
      return result.hits ?? [];
    }
    const facets: string[][] = [[`project_type:${projectType}`]];
    if (minecraftVersion.trim()) facets.push([`versions:${minecraftVersion.trim()}`]);
    if (projectType === 'mod' && loader && loader !== 'Vanilla') facets.push([`categories:${loader.toLowerCase()}`]);
    const params = new URLSearchParams({ query, facets: JSON.stringify(facets), index: sort, limit: '24' });
    const response = await fetch(`https://api.modrinth.com/v2/search?${params.toString()}`);
    if (!response.ok) throw new Error(`Modrinth returned ${response.status}.`);
    const result = await response.json() as { hits?: ModrinthProject[] };
    return result.hits ?? [];
  },

  async listMinecraftVersions(kind = 'release'): Promise<GameVersion[]> {
    if (!isDesktop()) throw new Error('Minecraft version discovery is available in the Windows desktop app.');
    return invoke<GameVersion[]>('list_minecraft_versions', { kind });
  },
  async installVanilla(profileId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Game installation is available in the Windows desktop app.');
    return invoke<string>('install_vanilla', { profileId });
  },
  async installProfileLoader(profileId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Loader installation is available in the Windows desktop app.');
    return invoke<string>('install_profile_loader', { profileId });
  },
  async launchProfile(profileId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Game launching is available in the Windows desktop app.');
    return invoke<string>('launch_profile', { profileId });
  },
  async diagnoseProfile(profileId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Profile diagnostics are available in the Windows desktop app.');
    return invoke<string>('diagnose_profile', { profileId });
  },
  async detectJavaRuntimes(): Promise<JavaRuntime[]> {
    if (!isDesktop()) return [];
    return invoke<JavaRuntime[]>('detect_java_runtimes');
  },
  async installJavaRuntime(major: number): Promise<JavaRuntime> {
    if (!isDesktop()) throw new Error('Java runtime installation is available in the Windows desktop app.');
    return invoke<JavaRuntime>('install_java_runtime', { major });
  },
  async getEngineStatus(profileId: string): Promise<EngineStatus> {
    if (!isDesktop()) throw new Error('Installation status is available in the Windows desktop app.');
    return invoke<EngineStatus>('get_engine_status', { profileId });
  },
  async setCurseForgeApiKey(key: string): Promise<void> {
    if (!isDesktop()) throw new Error('CurseForge setup is available in the Windows desktop app.');
    return invoke('set_curseforge_api_key', { key });
  },
  async hasCurseForgeApiKey(): Promise<boolean> {
    if (!isDesktop()) return false;
    return invoke<boolean>('has_curseforge_api_key');
  },
  async searchCurseForge(query: string, classId = 4471, gameVersion = '', modLoaderType = 0): Promise<CurseForgeMod[]> {
    if (!isDesktop()) throw new Error('CurseForge search is available in the Windows desktop app.');
    const result = await invoke<{ data?: CurseForgeMod[] }>('search_curseforge', { query, classId, gameVersion, modLoaderType });
    return result.data ?? [];
  },
  async installModrinthProject(profileId: string, projectId: string, category: string): Promise<string[]> {
    if (!isDesktop()) throw new Error('Mod installation is available in the Windows desktop app.');
    return invoke<string[]>('install_modrinth_project', { profileId, projectId, category });
  },
  async installModrinthModpack(profileId: string, projectId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Modpack installation is available in the Windows desktop app.');
    return invoke<string>('install_modrinth_modpack', { profileId, projectId });
  },
  async installModrinthPackFile(profileId: string, filePath: string): Promise<string> {
    if (!isDesktop()) throw new Error('Modpack import is available in the Windows desktop app.');
    return invoke<string>('install_modrinth_pack_file', { profileId, filePath });
  },
  async installCurseForgeModpack(profileId: string, modId: number, fileId: number): Promise<string> {
    if (!isDesktop()) throw new Error('CurseForge modpack installation is available in the Windows desktop app.');
    return invoke<string>('install_curseforge_modpack', { profileId, modId, fileId });
  },
  async installCurseForgeMod(profileId: string, modId: number, fileId: number): Promise<string[]> {
    if (!isDesktop()) throw new Error('CurseForge mod installation is available in the Windows desktop app.');
    return invoke<string[]>('install_curseforge_mod', { profileId, modId, fileId });
  },
  async getAccounts(): Promise<AccountSummary[]> {
    if (!isDesktop()) return [];
    return invoke<AccountSummary[]>('get_accounts');
  },
  async addOfflineAccount(username: string): Promise<AccountSummary> {
    if (!isDesktop()) throw new Error('Offline account creation is available in the Windows desktop app.');
    return invoke<AccountSummary>('add_offline_account', { username });
  },
  async openExternalUrl(url: string): Promise<void> {
    if (!isDesktop()) {
      window.open(url, '_blank', 'noopener,noreferrer');
      return;
    }
    return invoke('open_external_url', { url });
  },
  async isMicrosoftLoginConfigured(): Promise<boolean> {
    if (!isDesktop()) return false;
    return invoke<boolean>('is_microsoft_login_configured');
  },
  async beginMicrosoftLogin(): Promise<DeviceCode> {
    if (!isDesktop()) throw new Error('Microsoft sign-in is available in the Windows desktop app.');
    return invoke<DeviceCode>('begin_microsoft_login');
  },
  async completeMicrosoftLogin(deviceCode: DeviceCode): Promise<AccountSummary> {
    if (!isDesktop()) throw new Error('Microsoft sign-in is available in the Windows desktop app.');
    return invoke<AccountSummary>('complete_microsoft_login', {
      deviceCode: deviceCode.deviceCode,
      interval: deviceCode.interval,
      expiresIn: deviceCode.expiresIn,
    });
  },
  async refreshMicrosoftSession(accountId: string): Promise<AccountSummary> {
    if (!isDesktop()) throw new Error('Microsoft session management is available in the Windows desktop app.');
    return invoke<AccountSummary>('refresh_microsoft_session', { accountId });
  },
  async removeAccount(accountId: string): Promise<void> {
    if (!isDesktop()) throw new Error('Account management is available in the Windows desktop app.');
    return invoke('remove_account', { accountId });
  },
  async getServers(): Promise<ServerInfo[]> {
    if (!isDesktop()) return [];
    return invoke<ServerInfo[]>('get_servers');
  },
  async createServer(input: { name: string; minecraftVersion: string; software: string; ramMb: number; cpuThreads: number; port: number }): Promise<ServerInstance> {
    if (!isDesktop()) throw new Error('Server creation is available in the Windows desktop app.');
    return invoke<ServerInstance>('create_server', input);
  },
  async updateServer(updated: ServerInstance): Promise<ServerInstance> {
    if (!isDesktop()) throw new Error('Server settings are available in the Windows desktop app.');
    return invoke<ServerInstance>('update_server', { updated });
  },
  async setServerEula(serverId: string, accepted: boolean): Promise<void> {
    if (!isDesktop()) throw new Error('Server setup is available in the Windows desktop app.');
    return invoke('set_server_eula', { serverId, accepted });
  },
  async installServer(serverId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Server installation is available in the Windows desktop app.');
    return invoke<string>('install_server', { serverId });
  },
  async reinstallServer(serverId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Server reinstall is available in the Windows desktop app.');
    return invoke<string>('reinstall_server', { serverId });
  },
  async startServer(serverId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Server start is available in the Windows desktop app.');
    return invoke<string>('start_server', { serverId });
  },
  async stopServer(serverId: string): Promise<void> {
    if (!isDesktop()) throw new Error('Server stop is available in the Windows desktop app.');
    return invoke('stop_server', { serverId });
  },
  async killServer(serverId: string): Promise<void> {
    if (!isDesktop()) throw new Error('Server process control is available in the Windows desktop app.');
    return invoke('kill_server', { serverId });
  },
  async sendServerCommand(serverId: string, command: string): Promise<void> {
    if (!isDesktop()) throw new Error('Server console is available in the Windows desktop app.');
    return invoke('send_server_command', { serverId, command });
  },
  async deleteServer(serverId: string): Promise<void> {
    if (!isDesktop()) throw new Error('Server deletion is available in the Windows desktop app.');
    return invoke('delete_server', { serverId });
  },
  async getServerFiles(serverId: string, category: string): Promise<ServerFile[]> {
    if (!isDesktop()) return [];
    return invoke<ServerFile[]>('get_server_files', { serverId, category });
  },
  async removeServerFile(serverId: string, category: string, fileName: string): Promise<void> {
    if (!isDesktop()) throw new Error('Server file management is available in the Windows desktop app.');
    return invoke('remove_server_file', { serverId, category, fileName });
  },
  async toggleServerMod(serverId: string, fileName: string, enabled: boolean): Promise<void> {
    if (!isDesktop()) throw new Error('Server mod management is available in the Windows desktop app.');
    return invoke('toggle_server_mod', { serverId, fileName, enabled });
  },
  async readServerTextFile(serverId: string, fileName: string): Promise<string> {
    if (!isDesktop()) throw new Error('Server file editing is available in the Windows desktop app.');
    return invoke<string>('read_server_text_file', { serverId, fileName });
  },
  async writeServerTextFile(serverId: string, fileName: string, contents: string): Promise<void> {
    if (!isDesktop()) throw new Error('Server file editing is available in the Windows desktop app.');
    return invoke('write_server_text_file', { serverId, fileName, contents });
  },
  async openServerFolder(serverId: string): Promise<void> {
    if (!isDesktop()) throw new Error('Open server folder is available in the Windows desktop app.');
    return invoke('open_server_folder', { serverId });
  },
  async searchServerMods(query: string, serverId: string): Promise<ModrinthProject[]> {
    if (!isDesktop()) throw new Error('Server mod search is available in the Windows desktop app.');
    const result = await invoke<{ hits?: ModrinthProject[] }>('search_server_mods', { query, serverId });
    return result.hits ?? [];
  },
  async installServerMod(serverId: string, projectId: string): Promise<ServerModInstallResult> {
    if (!isDesktop()) throw new Error('Server mod installation is available in the Windows desktop app.');
    return invoke<ServerModInstallResult>('install_server_mod', { serverId, projectId });
  },
  async installPlayitWithWinget(): Promise<string> {
    if (!isDesktop()) throw new Error('Playit installation is available in the Windows desktop app.');
    return invoke<string>('install_playit_with_winget');
  },
  async startPlayitAgent(serverId: string): Promise<string> {
    if (!isDesktop()) throw new Error('Playit agent is available in the Windows desktop app.');
    return invoke<string>('start_playit_agent', { serverId });
  },
  async stopPlayitAgent(): Promise<string> {
    if (!isDesktop()) throw new Error('Playit service controls are available in the Windows desktop app.');
    return invoke<string>('stop_playit_agent');
  },
  async isPlayitRunning(): Promise<boolean> {
    if (!isDesktop()) return false;
    return invoke<boolean>('is_playit_running');
  },

};
