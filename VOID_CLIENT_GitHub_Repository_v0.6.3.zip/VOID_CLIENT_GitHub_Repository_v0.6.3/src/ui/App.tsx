import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { listen } from '@tauri-apps/api/event';
import {
  Activity, Archive, ArrowDownToLine, ArrowUpRight, Boxes, ChevronDown, ChevronRight,
  CircleHelp, CloudDownload, Command, Copy, Cpu, Download, ExternalLink, Folder,
  Gamepad2, HardDrive, Home, Layers3, LayoutGrid, Menu, Monitor, MoreHorizontal,
  Package, Palette, Plus, RefreshCw, Search, Settings, ShieldCheck, SlidersHorizontal, Sparkles, LoaderCircle,
  Terminal, Trash2, UserRound, Users, X, Zap, Server,
} from 'lucide-react';
import type { AccountSummary, CurseForgeMod, DeviceCode, EngineProgress, LaunchLogEntry, LauncherSettings, Loader, ModrinthProject, Profile, ServerLogEntry } from './types';
import { defaultSettings } from './types';
import { api } from './storage';
import { ProfileWorkspace } from './ProfileWorkspace';
import { ServersPage } from './ServersPage';

type Page = 'Home' | 'Profiles' | 'Workspace' | 'Modpacks' | 'Mods' | 'Resource Packs' | 'Shaders' | 'Worlds' | 'Accounts' | 'Downloads' | 'Console' | 'Servers' | 'Settings';
type Modal = { kind: 'create' } | { kind: 'edit'; profile: Profile } | { kind: 'delete'; profile: Profile } | null;

const navGroups: { label?: string; items: { name: Page; icon: typeof Home; hint?: string }[] }[] = [
  { items: [{ name: 'Home', icon: Home }, { name: 'Profiles', icon: LayoutGrid }] },
  { label: 'DISCOVER', items: [{ name: 'Modpacks', icon: Boxes }, { name: 'Mods', icon: Package }, { name: 'Resource Packs', icon: Layers3 }, { name: 'Shaders', icon: Palette }] },
  { label: 'LIBRARY', items: [{ name: 'Servers', icon: Server }, { name: 'Worlds', icon: Archive }, { name: 'Downloads', icon: CloudDownload }, { name: 'Console', icon: Terminal }] },
  { label: 'PREFERENCES', items: [{ name: 'Accounts', icon: UserRound }, { name: 'Settings', icon: Settings }] },
];

function formatDate(value: number | null) {
  if (!value) return 'Never played';
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(value));
}

function describeError(error: unknown): string {
  if (typeof error === 'string') return error;
  if (error instanceof Error) return error.message;
  if (error && typeof error === 'object' && 'message' in error) return String((error as { message?: unknown }).message ?? 'Unknown error');
  try { return JSON.stringify(error) ?? 'Unknown error'; } catch { return 'Unknown error'; }
}

function App() {
  const [page, setPage] = useState<Page>('Home');
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [settings, setSettings] = useState<LauncherSettings>(defaultSettings);
  const [accounts, setAccounts] = useState<AccountSummary[]>([]);
  const [workspaceTab, setWorkspaceTab] = useState<'Overview' | 'Mods' | 'Resource Packs' | 'Shaders' | 'Config' | 'Worlds' | 'Logs'>('Overview');
  const [modal, setModal] = useState<Modal>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState('');
  const [busy, setBusy] = useState(false);
  const [storagePath, setStoragePath] = useState('');
  const [consoleLines, setConsoleLines] = useState<LaunchLogEntry[]>([]);
  const [serverLines, setServerLines] = useState<ServerLogEntry[]>([]);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const selectedProfile = profiles.find(p => p.id === selected) ?? profiles[0] ?? null;
  const activeAccount = accounts.find(account => account.id === settings.selectedAccountId) ?? accounts[0] ?? null;
  const filteredProfiles = useMemo(() => profiles.filter(p => `${p.name} ${p.minecraftVersion} ${p.loader}`.toLowerCase().includes(search.toLowerCase())), [profiles, search]);

  const notify = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 3200);
  }, []);

  const refresh = async () => {
    try {
      const [nextProfiles, nextSettings, path, nextAccounts] = await Promise.all([api.getProfiles(), api.getSettings(), api.getStoragePath(), api.getAccounts()]);
      setProfiles(nextProfiles);
      setSettings(nextSettings);
      setStoragePath(path);
      setAccounts(nextAccounts);
      setSelected(current => current && nextProfiles.some(p => p.id === current) ? current : nextProfiles[0]?.id ?? null);
    } catch (error) {
      notify(error instanceof Error ? error.message : 'Could not load launcher data.');
    }
  };

  useEffect(() => { void refresh(); }, []);
  useEffect(() => {
    let unlisten: (() => void) | undefined;
    let disposed = false;
    void listen<LaunchLogEntry>('void-launch-log', event => {
      setConsoleLines(current => [...current.slice(-1499), event.payload]);
    }).then(stop => {
      if (disposed) stop(); else unlisten = stop;
    }).catch(error => {
      console.error('Could not subscribe to Minecraft launch logs:', error);
    });
    return () => { disposed = true; unlisten?.(); };
  }, []);
  useEffect(() => {
    let unlisten: (() => void) | undefined;
    let disposed = false;
    void listen<ServerLogEntry>('void-server-log', event => {
      setServerLines(current => [...current.slice(-1499), event.payload]);
    }).then(stop => {
      if (disposed) stop(); else unlisten = stop;
    }).catch(error => console.error('Could not subscribe to server logs:', error));
    return () => { disposed = true; unlisten?.(); };
  }, []);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const withBusy = async (work: () => Promise<void>) => {
    setBusy(true);
    try { await work(); await refresh(); }
    catch (error) { notify(error instanceof Error ? error.message : 'Something went wrong.'); }
    finally { setBusy(false); }
  };

  const saveSettings = async (next: LauncherSettings) => withBusy(async () => { await api.saveSettings(next); setSettings(next); notify('Settings saved.'); });

  return (
    <div className="app-shell" data-accent={settings.accent} data-theme={settings.theme}>
      <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
        <div className="brand-row">
          <div className="brand-mark"><span>V</span></div>
          {!collapsed && <div className="brand-copy"><strong>VOID<span>CLIENT</span></strong><small>PERSONAL GAME LAUNCHER</small></div>}
          <button className="icon-button sidebar-toggle" title="Collapse sidebar" onClick={() => setCollapsed(v => !v)}><Menu size={17} /></button>
        </div>

        <button className="account-switch" onClick={() => setPage('Accounts')}>
          <div className="account-avatar">{activeAccount?.skinUrl ? <img src={activeAccount.skinUrl} alt="" /> : <UserRound size={17} />}</div>
          {!collapsed && <><div className="account-copy"><strong>{activeAccount?.name ?? 'No account connected'}</strong><span>{activeAccount ? (activeAccount.accountType === 'offline' ? 'Offline account' : 'Active Minecraft account') : 'Connect an account'}</span></div><ChevronDown size={14} className="muted-icon" /></>}
        </button>

        <nav className="main-nav">
          {navGroups.map((group, index) => (
            <div className="nav-group" key={index}>
              {!collapsed && group.label && <div className="nav-label">{group.label}</div>}
              {group.items.map(item => {
                const Icon = item.icon;
                const workspaceTarget = item.name === 'Mods' || item.name === 'Resource Packs' || item.name === 'Shaders';
                const isActive = page === item.name || (page === 'Workspace' && workspaceTarget && workspaceTab === item.name);
                return <button key={item.name} className={`nav-item ${isActive ? 'active' : ''}`} onClick={() => { if (workspaceTarget && selectedProfile) { setWorkspaceTab(item.name as typeof workspaceTab); setPage('Workspace'); } else if (workspaceTarget && !selectedProfile) { setPage('Profiles'); notify('Create or select a profile first.'); } else { setPage(item.name); } }} title={collapsed ? item.name : undefined}>
                  <Icon size={17} strokeWidth={1.8} /><span>{!collapsed && item.name}</span>{!collapsed && item.name === 'Downloads' && <i className="nav-dot" />}
                </button>;
              })}
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          {!collapsed && <div className="sidebar-status"><span className="status-pulse" />Launcher is running<span className="status-version">v0.6.3</span></div>}
          <button className="nav-item support-item" onClick={() => notify('Support and diagnostics will be added with the launcher engine.')} title="Help"><CircleHelp size={17} /><span>{!collapsed && 'Help & support'}</span></button>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumbs"><span>VOID CLIENT</span><ChevronRight size={13} /><strong>{page}</strong></div>
          <div className="topbar-actions">
            <div className="global-search"><Search size={15} /><input ref={searchInputRef} value={search} onChange={e => setSearch(e.target.value)} placeholder="Search profiles..." /><kbd>Ctrl K</kbd></div>
            <div className="top-divider" />
            <button className="icon-button" title="Settings" onClick={() => setPage('Settings')}><Settings size={17} /></button>
            <div className="tiny-avatar">{activeAccount?.skinUrl ? <img src={activeAccount.skinUrl} alt="" /> : <UserRound size={15} />}</div>
          </div>
        </header>

        <div className="page-content">
          {page === 'Home' && <HomePage profiles={profiles} selectedProfile={selectedProfile} onSelect={setSelected} onCreate={() => setModal({ kind: 'create' })} onNavigate={target => { if (target === 'Mods' && selectedProfile) { setWorkspaceTab('Mods'); setPage('Workspace'); } else if (target === 'Mods') { setPage('Profiles'); notify('Create or select a profile before browsing compatible mods.'); } else { setPage(target); } }} />}
          {page === 'Profiles' && <ProfilesPage profiles={filteredProfiles} selected={selected} onSelect={setSelected} onCreate={() => setModal({ kind: 'create' })} onEdit={p => setModal({ kind: 'edit', profile: p })} onDelete={p => setModal({ kind: 'delete', profile: p })} onManage={p => { setSelected(p.id); setWorkspaceTab('Overview'); setPage('Workspace'); }} onDuplicate={id => withBusy(async () => { const p = await api.duplicateProfile(id); setSelected(p.id); notify('Profile duplicated.'); })} onOpen={id => withBusy(async () => api.openProfileFolder(id))} busy={busy} />}
          {page === 'Workspace' && selectedProfile && <ProfileWorkspace key={`${selectedProfile.id}-${workspaceTab}`} profile={selectedProfile} initialTab={workspaceTab} onBack={() => setPage('Profiles')} onEdit={p => setModal({ kind: 'edit', profile: p })} onNotice={notify} onRefresh={refresh} onOpenConsole={() => setPage('Console')} />}
          {page === 'Workspace' && !selectedProfile && <div className="empty-state"><div className="empty-icon"><LayoutGrid size={21} /></div><h3>Select a profile first</h3><p>Choose or create a Minecraft profile before opening its workspace.</p><button className="button button-primary" onClick={() => setPage('Profiles')}>Go to profiles</button></div>}
          {page === 'Accounts' && <AccountsPage accounts={accounts} settings={settings} onSave={saveSettings} onRefresh={refresh} onNotice={notify} onActivate={id => saveSettings({ ...settings, selectedAccountId: id })} />}
          {page === 'Settings' && <SettingsPage settings={settings} storagePath={storagePath} onSave={saveSettings} />}
          {page === 'Console' && <ConsolePage entries={consoleLines} onClear={() => setConsoleLines([])} />}
          {page === 'Servers' && <ServersPage lines={serverLines} onNotice={notify} />}
          {page === 'Modpacks' && <ModpacksPage profiles={profiles} selectedProfile={selectedProfile} onSelectProfile={setSelected} onRefresh={refresh} onNotice={notify} />}
          {['Worlds', 'Downloads'].includes(page) && <RoadmapPage page={page} onGoSettings={() => setPage('Settings')} />}
        </div>
      </main>

      {modal && <ProfileModal modal={modal} onClose={() => setModal(null)} onCreate={input => withBusy(async () => { const p = await api.createProfile(input); setSelected(p.id); setPage('Profiles'); setModal(null); notify('Profile created. Its folders are ready.'); })} onUpdate={profile => withBusy(async () => { await api.updateProfile(profile); setModal(null); notify('Profile updated.'); })} onDelete={profile => withBusy(async () => { await api.deleteProfile(profile.id); if (selected === profile.id) setSelected(null); setModal(null); notify('Profile deleted.'); })} busy={busy} />}
      <div className="made-by-credit">made by <strong>voidwem / m.af</strong></div>
      {toast && <div className="toast"><span className="toast-indicator" />{toast}<button onClick={() => setToast('')}><X size={14} /></button></div>}
    </div>
  );
}

function PageHeading({ eyebrow, title, subtitle, action }: { eyebrow: string; title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>{action && <div className="heading-action">{action}</div>}</div>;
}

function HomePage({ profiles, selectedProfile, onSelect, onCreate, onNavigate }: { profiles: Profile[]; selectedProfile: Profile | null; onSelect: (id: string) => void; onCreate: () => void; onNavigate: (page: Page) => void }) {
  return <>
    <PageHeading eyebrow="YOUR GAME LIBRARY" title="Welcome back." subtitle="Your Minecraft, organized your way." action={<button className="button button-primary" onClick={onCreate}><Plus size={16} /> Create profile</button>} />
    <section className="hero-panel">
      <div className="hero-noise" />
      <div className="hero-content">
        <div className="hero-kicker"><span className="hero-dot" /> YOUR NEXT ADVENTURE STARTS HERE</div>
        <h2>One launcher.<br /><em>Every world.</em></h2>
        <p>Keep every version, modpack and play style in its own space. Pick up right where you left off.</p>
        <div className="hero-actions"><button className="button button-primary hero-button" onClick={() => { if (selectedProfile) { onSelect(selectedProfile.id); onNavigate('Profiles'); } else { onCreate(); } }}>{selectedProfile ? 'View selected profile' : 'Create your first profile'}<ArrowUpRight size={15} /></button><button className="button button-ghost" onClick={() => onNavigate('Profiles')}>Explore profiles</button></div>
      </div>
      <div className="hero-art" aria-hidden="true"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="cube-shadow" /><div className="voxel-cube"><div className="cube-top" /><div className="cube-left" /><div className="cube-right" /></div><div className="hero-coordinates">VOID / 001<br /><span>BUILD YOUR WORLD</span></div></div>
    </section>

    <div className="section-heading"><div><h3>Your library</h3><p>{profiles.length} {profiles.length === 1 ? 'profile' : 'profiles'} configured</p></div><button className="text-button" onClick={() => onNavigate('Profiles')}>View all <ChevronRight size={14} /></button></div>
    {profiles.length === 0 ? <div className="empty-state compact-empty"><div className="empty-icon"><LayoutGrid size={21} /></div><h3>Your library is waiting</h3><p>Create an isolated Minecraft profile to get started. Each profile will have its own mods, worlds, settings and folders.</p><button className="button button-secondary" onClick={onCreate}><Plus size={15} /> Create your first profile</button></div> : <div className="profile-grid home-grid">{profiles.slice(0, 3).map(p => <ProfileCard key={p.id} profile={p} selected={selectedProfile?.id === p.id} onClick={() => { onSelect(p.id); onNavigate('Profiles'); }} compact />)}</div>}

    <div className="section-heading second-section"><div><h3>Quick access</h3><p>Everything you need, one click away.</p></div></div>
    <div className="quick-grid">
      <QuickCard icon={Boxes} title="Discover modpacks" description="Find your next adventure." onClick={() => onNavigate('Modpacks')} />
      <QuickCard icon={Package} title="Browse mods" description="Build the perfect setup." onClick={() => onNavigate('Mods')} />
      <QuickCard icon={UserRound} title="Connect account" description="Sign in with Microsoft." onClick={() => onNavigate('Accounts')} />
    </div>
  </>;
}

function QuickCard({ icon: Icon, title, description, onClick }: { icon: typeof Package; title: string; description: string; onClick: () => void }) {
  return <button className="quick-card" onClick={onClick}><div className="quick-icon"><Icon size={18} /></div><div><strong>{title}</strong><span>{description}</span></div><ArrowUpRight size={15} className="quick-arrow" /></button>;
}

function ProfileCard({ profile, selected, onClick, compact = false }: { profile: Profile; selected: boolean; onClick: () => void; compact?: boolean }) {
  const loaderClass = profile.loader.toLowerCase().replace(/[^a-z]/g, '');
  return <button className={`profile-card ${selected ? 'selected' : ''} ${compact ? 'compact' : ''}`} onClick={onClick}>
    <div className="profile-card-top"><div className={`profile-emblem ${loaderClass}`}><span>{profile.name.trim().slice(0, 1).toUpperCase()}</span></div><span className="profile-menu-dot"><MoreHorizontal size={17} /></span></div>
    <div className="profile-card-info"><strong>{profile.name}</strong><span>{profile.minecraftVersion} <i /> {profile.loader}</span></div>
    <div className="profile-card-bottom"><span className="last-played">{formatDate(profile.lastPlayed)}</span><span className="ram-tag"><Cpu size={12} /> {profile.ramGb} GB</span></div>
  </button>;
}

function ProfilesPage({ profiles, selected, onSelect, onCreate, onEdit, onDelete, onManage, onDuplicate, onOpen, busy }: { profiles: Profile[]; selected: string | null; onSelect: (id: string) => void; onCreate: () => void; onEdit: (p: Profile) => void; onDelete: (p: Profile) => void; onManage: (p: Profile) => void; onDuplicate: (id: string) => void; onOpen: (id: string) => void; busy: boolean }) {
  const current = profiles.find(p => p.id === selected) ?? null;
  return <>
    <PageHeading eyebrow="YOUR LIBRARY" title="Profiles" subtitle="Independent Minecraft installations. Completely yours." action={<button className="button button-primary" onClick={onCreate}><Plus size={16} /> New profile</button>} />
    {profiles.length === 0 ? <div className="empty-state"><div className="empty-icon"><LayoutGrid size={22} /></div><h3>No profiles yet</h3><p>Create your first profile. VOID CLIENT will keep its mods, resource packs, shaders, worlds and configuration separate from every other profile.</p><button className="button button-primary" onClick={onCreate}><Plus size={15} /> Create profile</button></div> : <div className="profiles-layout">
      <div className="profile-library"><div className="library-toolbar"><div className="library-count"><span className="green-dot" /> {profiles.length} PROFILES</div><div className="sort-label"><SlidersHorizontal size={13} /> Recently created</div></div><div className="profile-grid">{profiles.map(p => <ProfileCard key={p.id} profile={p} selected={selected === p.id} onClick={() => onSelect(p.id)} />)}</div></div>
      <aside className="profile-inspector">{current ? <><div className="inspector-art"><div className="inspector-emblem">{current.name.slice(0, 1).toUpperCase()}</div><span className="inspector-version">{current.minecraftVersion}</span></div><div className="inspector-title"><div><div className="eyebrow">SELECTED PROFILE</div><h2>{current.name}</h2></div><button className="icon-button" title="Edit profile" onClick={() => onEdit(current)}><SlidersHorizontal size={16} /></button></div><div className="inspector-meta"><span><Layers3 size={14} /> {current.loader}</span><span><Cpu size={14} /> {current.ramGb} GB RAM</span></div><div className="inspector-divider" /><div className="inspector-details"><div><span>GAME VERSION</span><strong>{current.minecraftVersion}</strong></div><div><span>LAST PLAYED</span><strong>{formatDate(current.lastPlayed)}</strong></div><div><span>RESOLUTION</span><strong>{current.gameWidth} × {current.gameHeight}</strong></div><div><span>PROFILE TYPE</span><strong>Isolated instance</strong></div></div><button className="button button-primary full-button manage-profile-button" onClick={() => onManage(current)}><Layers3 size={15} /> Open profile workspace <ChevronRight size={14} /></button><button className="button button-secondary full-button launch-disabled" onClick={() => onManage(current)} title="Open the install, Java and Play controls for this profile."><Gamepad2 size={16} /> Install / Play controls <ChevronRight size={14} /></button><div className="inspector-actions"><button onClick={() => onEdit(current)}><Settings size={15} /> Edit settings</button><button onClick={() => onOpen(current.id)}><Folder size={15} /> Open folder</button><button onClick={() => onDuplicate(current.id)} disabled={busy}><Copy size={15} /> Duplicate</button><button className="danger-action" onClick={() => onDelete(current)}><Trash2 size={15} /> Delete profile</button></div></> : <div className="inspector-empty"><LayoutGrid size={22} /><p>Select a profile to see its details.</p></div>}</aside>
    </div>}
    <div className="info-strip"><ShieldCheck size={16} /><span><strong>Profile isolation is enabled.</strong> Each profile receives its own folders for mods, configs, worlds, resource packs and shaders.</span></div>
  </>;
}

function ProfileModal({ modal, onClose, onCreate, onUpdate, onDelete, busy }: { modal: Exclude<Modal, null>; onClose: () => void; onCreate: (input: { name: string; minecraftVersion: string; loader: string; ramGb: number }) => void; onUpdate: (profile: Profile) => void; onDelete: (profile: Profile) => void; busy: boolean }) {
  const editing = modal.kind === 'edit' ? modal.profile : null;
  const deleting = modal.kind === 'delete' ? modal.profile : null;
  const [name, setName] = useState(editing?.name ?? '');
  const [version, setVersion] = useState(editing?.minecraftVersion ?? '1.21.11');
  const [loader, setLoader] = useState<Loader>(editing?.loader ?? 'Fabric');
  const [ram, setRam] = useState(editing?.ramGb ?? 4);
  const [width, setWidth] = useState(editing?.gameWidth ?? 1280);
  const [height, setHeight] = useState(editing?.gameHeight ?? 720);
  const [fullscreen, setFullscreen] = useState(editing?.fullscreen ?? false);
  const [jvmArgs, setJvmArgs] = useState(editing?.jvmArgs ?? '');
  const [javaPath, setJavaPath] = useState(editing?.javaPath ?? '');
  const [error, setError] = useState('');
  const [versionChoices, setVersionChoices] = useState<string[]>([]);
  useEffect(() => { void api.listMinecraftVersions('all').then(items => { setVersionChoices(items.map(item => item.id)); if (!editing) { const latestRelease = items.find(item => item.versionType === 'release'); if (latestRelease) setVersion(latestRelease.id); } }).catch(() => setVersionChoices([])); }, []);

  const submit = () => {
    if (!name.trim()) { setError('Give your profile a name.'); return; }
    if (!/^[a-zA-Z0-9._+-]{3,80}$/.test(version.trim())) { setError('Enter a valid Minecraft version ID.'); return; }
    if (editing) onUpdate({ ...editing, name: name.trim(), minecraftVersion: version.trim(), loader, ramGb: ram, gameWidth: width, gameHeight: height, fullscreen, jvmArgs, javaPath: javaPath.trim() || null });
    else onCreate({ name: name.trim(), minecraftVersion: version.trim(), loader, ramGb: ram });
  };

  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div className="modal-card">
    <div className="modal-header"><div><div className="eyebrow">PROFILE MANAGER</div><h2>{deleting ? 'Delete profile?' : editing ? 'Edit profile' : 'Create a profile'}</h2></div><button className="icon-button" onClick={onClose}><X size={17} /></button></div>
    {deleting ? <><div className="delete-warning"><Trash2 size={19} /><div><strong>This will permanently delete {deleting.name}.</strong><p>The profile folder, mods, configurations, resource packs, shaders and worlds inside it will be removed. This cannot be undone.</p></div></div><div className="modal-actions"><button className="button button-secondary" onClick={onClose}>Cancel</button><button className="button button-danger" onClick={() => onDelete(deleting)} disabled={busy}>Delete profile</button></div></> : <>
      <div className="form-grid"><label className="field full-field"><span>PROFILE NAME</span><input value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Survival World" maxLength={48} autoFocus /></label>
        <label className="field"><span>MINECRAFT VERSION</span><input list="void-minecraft-versions" value={version} onChange={e => setVersion(e.target.value)} placeholder="1.21.11" /><datalist id="void-minecraft-versions">{versionChoices.map(id => <option key={id} value={id} />)}</datalist></label>
        <label className="field"><span>MOD LOADER</span><select value={loader} onChange={e => setLoader(e.target.value as Loader)}>{['Vanilla', 'Fabric', 'Forge', 'NeoForge', 'Quilt'].map(v => <option key={v}>{v}</option>)}</select></label>
        <div className="field full-field"><div className="field-row"><span>MEMORY ALLOCATION</span><strong>{ram} GB</strong></div><input className="range-input" type="range" min="2" max="16" step="1" value={ram} onChange={e => setRam(Number(e.target.value))} /><div className="range-ends"><span>2 GB</span><span>16 GB</span></div></div>
        {editing && <><div className="field"><span>GAME WIDTH</span><input type="number" min="640" max="7680" value={width} onChange={e => setWidth(Number(e.target.value))} /></div><div className="field"><span>GAME HEIGHT</span><input type="number" min="480" max="4320" value={height} onChange={e => setHeight(Number(e.target.value))} /></div><label className="field full-field"><span>JVM ARGUMENTS</span><input value={jvmArgs} onChange={e => setJvmArgs(e.target.value)} placeholder="Optional custom JVM arguments" /></label><label className="field full-field"><span>CUSTOM JAVA EXECUTABLE (OPTIONAL)</span><input value={javaPath} onChange={e => setJavaPath(e.target.value)} placeholder="C:\Program Files\Java\bin\java.exe" /><small>Leave empty to let VOID CLIENT select a compatible installed runtime automatically.</small></label><label className="toggle-row full-field"><span><strong>Fullscreen</strong><small>Launch the game in fullscreen mode.</small></span><input type="checkbox" checked={fullscreen} onChange={e => setFullscreen(e.target.checked)} /></label></>}
      </div>{error && <div className="form-error">{error}</div>}<div className="modal-footnote"><ShieldCheck size={14} /> This profile gets its own isolated game folders.</div><div className="modal-actions"><button className="button button-secondary" onClick={onClose}>Cancel</button><button className="button button-primary" onClick={submit} disabled={busy}>{editing ? 'Save changes' : 'Create profile'} <ChevronRight size={15} /></button></div>
    </>}
  </div></div>;
}

function AccountsPage({ accounts, settings, onSave, onRefresh, onNotice, onActivate }: { accounts: AccountSummary[]; settings: LauncherSettings; onSave: (settings: LauncherSettings) => Promise<void>; onRefresh: () => Promise<void>; onNotice: (message: string) => void; onActivate: (accountId: string) => Promise<void> }) {
  const [deviceCode, setDeviceCode] = useState<DeviceCode | null>(null);
  const [signingIn, setSigningIn] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [browserOpenError, setBrowserOpenError] = useState('');
  const [removing, setRemoving] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState<string | null>(null);
  const [authConfigured, setAuthConfigured] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [clientIdDraft, setClientIdDraft] = useState(settings.microsoftClientId ?? '');
  const [savingClientId, setSavingClientId] = useState(false);
  const [offlineUsername, setOfflineUsername] = useState('');
  const [addingOffline, setAddingOffline] = useState(false);

  useEffect(() => {
    setClientIdDraft(settings.microsoftClientId ?? '');
  }, [settings.microsoftClientId]);

  useEffect(() => {
    let alive = true;
    void api.isMicrosoftLoginConfigured()
      .then(value => { if (alive) setAuthConfigured(value); })
      .catch(() => { if (alive) setAuthConfigured(false); })
      .finally(() => { if (alive) setCheckingAuth(false); });
    return () => { alive = false; };
  }, []);

  const saveMicrosoftClientId = async () => {
    const clientId = clientIdDraft.trim();
    if (!clientId) { onNotice('Paste your Microsoft Application (client) ID first.'); return; }
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(clientId)) {
      onNotice('That does not look like an Application (client) ID. Use the GUID from Entra app Overview, not the Object ID or Directory ID.');
      return;
    }
    setSavingClientId(true);
    try {
      await onSave({ ...settings, microsoftClientId: clientId });
      const configured = await api.isMicrosoftLoginConfigured();
      setAuthConfigured(configured);
      onNotice(configured ? 'Microsoft app ID saved. You can now sign in.' : 'The app ID was saved, but Microsoft sign-in is not available in this build.');
    } catch (error) { onNotice(`Could not save Microsoft app ID: ${describeError(error)}`); }
    finally { setSavingClientId(false); }
  };

  const openMicrosoftBrowser = async (url?: string): Promise<string | null> => {
    const target = url ?? deviceCode?.verificationUri;
    if (!target) return 'Microsoft did not provide a verification URL.';
    try {
      const parsed = new URL(target);
      if (parsed.protocol !== 'https:' || !['microsoft.com', 'www.microsoft.com'].includes(parsed.hostname.toLowerCase())) {
        throw new Error('Microsoft returned an unexpected verification link. For safety, VOID CLIENT only opens microsoft.com sign-in pages.');
      }
      await api.openExternalUrl(parsed.toString());
      setBrowserOpenError('');
      return null;
    } catch (error) {
      const message = describeError(error);
      setBrowserOpenError(message);
      return message;
    }
  };

  const startLogin = async () => {
    setSigningIn(true);
    setLoginError('');
    setBrowserOpenError('');
    setDeviceCode(null);
    try {
      const code = await api.beginMicrosoftLogin();
      if (!code.deviceCode || !code.userCode || !code.verificationUri) {
        throw new Error('Microsoft returned an incomplete device sign-in response. Check the Application Client ID and device-code settings in Entra.');
      }
      setDeviceCode(code);
      // Tauri WebViews do not reliably open target=_blank links. Invoke the native
      // Windows URL handler immediately after the device code is received.
      const browserError = await openMicrosoftBrowser(code.verificationUri);
      onNotice(browserError
        ? `The sign-in code was created, but the browser did not open: ${browserError}. Use the Open Microsoft in browser button or visit microsoft.com/devicelogin and enter the displayed code.`
        : 'Microsoft sign-in opened in your browser. Approve the request; VOID CLIENT is waiting automatically.');
      const account = await api.completeMicrosoftLogin(code);
      setDeviceCode(null);
      setBrowserOpenError('');
      await onSave({ ...settings, selectedAccountId: account.id });
      await onRefresh();
      onNotice(`Connected ${account.name}. Your session is saved securely in Windows Credential Manager.`);
    } catch (error) {
      const message = describeError(error);
      setLoginError(message);
      setDeviceCode(null);
      onNotice(`Microsoft sign-in failed: ${message}`);
    } finally { setSigningIn(false); }
  };
  const addOfflineAccount = async () => {
    const username = offlineUsername.trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
      onNotice('Choose a username of 3–16 letters, numbers or underscores.');
      return;
    }
    setAddingOffline(true);
    try {
      const account = await api.addOfflineAccount(username);
      await onSave({ ...settings, selectedAccountId: account.id });
      setOfflineUsername('');
      await onRefresh();
      onNotice(`Offline account ${account.name} added and selected. Use single-player or servers that allow offline-mode connections.`);
    } catch (error) {
      onNotice(error instanceof Error ? error.message : 'Could not add offline account.');
    } finally { setAddingOffline(false); }
  };

  const refreshSession = async (account: AccountSummary) => {
    setRefreshing(account.id);
    try {
      const renewed = await api.refreshMicrosoftSession(account.id);
      await onRefresh();
      onNotice(`Microsoft session renewed for ${renewed.name}.`);
    } catch (error) { onNotice(error instanceof Error ? error.message : 'Could not renew this Microsoft session.'); }
    finally { setRefreshing(null); }
  };
  const remove = async (account: AccountSummary) => {
    if (!window.confirm(`Remove ${account.name} from VOID CLIENT?`)) return;
    setRemoving(account.id);
    try { await api.removeAccount(account.id); await onRefresh(); onNotice(`${account.name} removed.`); }
    catch (error) { onNotice(error instanceof Error ? error.message : 'Could not remove account.'); }
    finally { setRemoving(null); }
  };
  return <>
    <PageHeading eyebrow="IDENTITY" title="Accounts" subtitle="Use Microsoft sign-in or a local offline username for single-player and offline-mode servers." />
    <div className="account-page-grid"><section className="settings-card account-card">
      <div className="account-card-heading"><div className="account-large-icon"><UserRound size={22} /></div><div><h3>Microsoft account</h3><p>Official Microsoft → Xbox Live → Minecraft Services authentication</p></div><span className={`pill ${accounts.some(a => a.accountType !== 'offline') ? 'pill-success' : 'pill-muted'}`}>{accounts.filter(a => a.accountType !== 'offline').length ? `${accounts.filter(a => a.accountType !== 'offline').length} connected` : 'Not connected'}</span></div>
      <div className="account-feature-list"><div><ShieldCheck size={16} /><span>Sign in securely with Microsoft. VOID CLIENT never asks for your password.</span></div><div><Users size={16} /><span>Connect multiple Minecraft accounts and switch between them.</span></div><div><Zap size={16} /><span>Sessions are remembered securely in Windows Credential Manager.</span></div></div>
      {accounts.length > 0 && <div className="connected-account-list">{accounts.map(account => { const active = (settings.selectedAccountId ?? accounts[0]?.id) === account.id; return <div className={`connected-account ${active ? 'account-active' : ''}`} key={account.id}>{account.skinUrl ? <img src={account.skinUrl} alt={`${account.name} skin`} /> : <div className="connected-account-avatar"><UserRound size={18} /></div>}<div className="connected-account-copy"><strong>{account.name}</strong><span>{account.accountType === 'offline' ? 'Local offline identity' : account.uuid}</span></div><span className={`account-type-badge ${account.accountType === 'offline' ? 'offline' : 'microsoft'}`}>{account.accountType === 'offline' ? 'OFFLINE' : 'MICROSOFT'}</span><button className={`pill ${active ? 'pill-success' : 'pill-muted'} account-use-button`} onClick={() => void onActivate(account.id)} disabled={active}>{active ? 'Active account' : 'Use account'}</button>{account.accountType !== 'offline' && <button className="icon-button" title="Renew Microsoft session" onClick={() => void refreshSession(account)} disabled={refreshing === account.id || !authConfigured}>{refreshing === account.id ? <LoaderCircle size={14} className="spin" /> : <RefreshCw size={14} />}</button>}<button className="icon-button danger-icon" title="Remove account" onClick={() => void remove(account)} disabled={removing === account.id}>{removing === account.id ? <LoaderCircle size={14} className="spin" /> : <Trash2 size={14} />}</button></div>; })}</div>}
      <div className="offline-account-control">
        <div className="microsoft-client-heading"><div><strong>Offline account</strong><span>Use a local username without Microsoft sign-in.</span></div><span className="account-type-badge offline">LOCAL</span></div>
        <div className="offline-account-input-row"><input type="text" value={offlineUsername} onChange={e => setOfflineUsername(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void addOfflineAccount(); }} maxLength={16} autoComplete="off" spellCheck={false} placeholder="Enter username (3–16 characters)" aria-label="Offline Minecraft username" /><button className="button button-primary" onClick={() => void addOfflineAccount()} disabled={addingOffline || !offlineUsername.trim()}>{addingOffline ? <LoaderCircle size={13} className="spin" /> : <Plus size={13} />} Add offline account</button></div>
        <small>Offline accounts are local identities, not verified Minecraft accounts. They can launch single-player and connect only to servers configured for offline-mode. Microsoft-authenticated servers, Realms and account entitlements are not available.</small>
      </div>
      <div className="microsoft-client-control">
        <div className="microsoft-client-heading"><div><strong>Microsoft app ID</strong><span>One-time setup for this launcher installation.</span></div><span className={`client-id-status ${authConfigured ? 'ready' : ''}`}>{authConfigured ? 'CONFIGURED' : 'SETUP REQUIRED'}</span></div>
        <input type="text" autoComplete="off" spellCheck={false} value={clientIdDraft} onChange={e => setClientIdDraft(e.target.value)} placeholder="Paste Application (client) ID" aria-label="Microsoft Application Client ID" />
        <div className="microsoft-client-actions"><button className="button button-secondary" onClick={() => void api.openExternalUrl('https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade').catch(error => onNotice(describeError(error)))}>Get a Microsoft app ID <ExternalLink size={13} /></button><button className="button button-primary" onClick={() => void saveMicrosoftClientId()} disabled={savingClientId || !clientIdDraft.trim()}>{savingClientId ? <LoaderCircle size={13} className="spin" /> : <ShieldCheck size={13} />} Save app ID</button></div>
        <small>This is a public OAuth identifier, not your password or a client secret. Register it as a personal Microsoft account public-client app and enable device-code / public-client flow.</small>
      </div>
      {!checkingAuth && !authConfigured && <div className="integration-notice"><div className="notice-icon"><CircleHelp size={17} /></div><div><strong>Save your Microsoft app ID to continue</strong><p>After saving it once, the sign-in button will be enabled. You will not need to paste it again on this PC.</p></div></div>}
      <div className="account-actions"><div className="account-primary-actions"><button className="button button-primary" onClick={() => void startLogin()} disabled={signingIn || checkingAuth || !authConfigured}>{signingIn ? <LoaderCircle size={14} className="spin" /> : <UserRound size={14} />}{accounts.length ? 'Add Microsoft account' : 'Sign in with Microsoft'}</button></div></div>
      {loginError && !deviceCode && <div className="inline-error account-login-error"><CircleHelp size={15} /><span>{loginError}</span><button className="text-button" onClick={() => setLoginError('')}>Dismiss</button></div>}
      {deviceCode && <div className="device-code-panel"><div className="device-code-heading"><div><div className="eyebrow">MICROSOFT SIGN-IN</div><strong>Approve VOID CLIENT in your browser</strong></div></div><div className="device-code-copy-row"><div className="device-code-value">{deviceCode.userCode}</div><button className="button button-secondary" onClick={() => navigator.clipboard.writeText(deviceCode.userCode).then(() => onNotice('Microsoft sign-in code copied.')).catch(() => onNotice('Could not copy the code; select it and copy manually.'))}><Copy size={13} /> Copy code</button></div><p>{deviceCode.message || 'Open Microsoft device sign-in and enter the code above.'}</p><button className="button button-secondary device-open-link" onClick={async () => { const error = await openMicrosoftBrowser(); onNotice(error ? `Could not open Microsoft: ${error}` : 'Opened Microsoft sign-in in your default browser.'); }}>Open Microsoft in browser <ArrowUpRight size={13} /></button>{browserOpenError && <div className="inline-error"><CircleHelp size={15} /><span>Automatic browser opening failed: {browserOpenError}. You can copy the code and open https://microsoft.com/devicelogin manually.</span></div>}<div className="device-wait-status"><LoaderCircle size={14} className="spin" /> Waiting for Microsoft approval automatically. You do not need to press another button.</div><small>Code expires in about {Math.ceil(deviceCode.expiresIn / 60)} minutes. Keep this window open.</small></div>}
    </section><aside className="settings-card account-side-card"><div className="eyebrow">ACCOUNT SECURITY</div><h3>Your credentials stay yours.</h3><p>Microsoft handles your password and multi-factor authentication in its sign-in page. VOID CLIENT receives tokens only, and keeps the refresh token in Windows Credential Manager.</p><div className="security-seal"><ShieldCheck size={28} /><span>WINDOWS PROTECTED STORAGE</span></div><div className="account-security-note"><strong>One-time app setup</strong><span>Save the public Microsoft Application Client ID once on this PC. After that, sign in by approving Microsoft's device prompt. VOID CLIENT never needs your Microsoft password or a client secret.</span></div></aside></div>
  </>;
}

function ConsolePage({ entries, onClear }: { entries: LaunchLogEntry[]; onClear: () => void }) {
  const [filter, setFilter] = useState<'all' | 'system' | 'stdout' | 'stderr' | 'errors'>('all');
  const [autoScroll, setAutoScroll] = useState(true);
  const bodyRef = useRef<HTMLDivElement>(null);
  const visible = entries.filter(entry => filter === 'all'
    || (filter === 'errors' ? entry.stream === 'error' || entry.stream === 'warning' : entry.stream === filter));
  useEffect(() => {
    if (autoScroll && bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
  }, [entries, autoScroll, filter]);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(visible.map(entry => `[${new Date(entry.timestamp).toLocaleTimeString()}] [${entry.stream.toUpperCase()}] [${entry.profileName}] ${entry.message}`).join('\n'));
    } catch { /* Clipboard can be unavailable in restricted webviews. */ }
  };
  return <>
    <PageHeading eyebrow="LIVE GAME DIAGNOSTICS" title="Console" subtitle="Live Minecraft launch status, Java output, errors and process exit events." action={<div className="console-heading-actions"><button className="button button-secondary" onClick={() => void copy()}><Copy size={14} /> Copy visible</button><button className="button button-secondary" onClick={onClear}><Trash2 size={14} /> Clear</button></div>} />
    <section className="console-panel">
      <div className="console-toolbar">
        <div className="console-live-indicator"><span className="status-pulse" /> LISTENING FOR GAME EVENTS</div>
        <div className="console-filters">{(['all', 'system', 'stdout', 'stderr', 'errors'] as const).map(value => <button key={value} className={filter === value ? 'selected' : ''} onClick={() => setFilter(value)}>{value === 'all' ? 'All' : value === 'errors' ? 'Errors' : value.toUpperCase()}</button>)}</div>
        <label className="console-autoscroll"><input type="checkbox" checked={autoScroll} onChange={e => setAutoScroll(e.target.checked)} /> Auto-scroll</label>
      </div>
      <div className="console-body" ref={bodyRef} role="log" aria-live="polite">
        {visible.length === 0 ? <div className="console-empty"><Terminal size={26} /><strong>No console output yet</strong><p>Open a profile, install Minecraft and press PLAY. Startup checks, Java output and game logs will appear here.</p></div> : visible.map((entry, index) => <div className={`console-line stream-${entry.stream}`} key={`${entry.timestamp}-${index}`}><time>{new Date(entry.timestamp).toLocaleTimeString()}</time><span className="console-stream">{entry.stream.toUpperCase()}</span><span className="console-profile">{entry.profileName}</span><p>{entry.message}</p></div>)}
      </div>
      <div className="console-footer"><span>{visible.length} visible / {entries.length} captured</span><span>Game log files are also saved inside the selected profile's logs folder.</span></div>
    </section>
  </>;
}

function SettingsPage({ settings, storagePath, onSave }: { settings: LauncherSettings; storagePath: string; onSave: (settings: LauncherSettings) => Promise<void> }) {
  const [draft, setDraft] = useState(settings);
  const [saving, setSaving] = useState(false);
  const [curseForgeKey, setCurseForgeKey] = useState('');
  const [curseForgeKeySaved, setCurseForgeKeySaved] = useState(false);
  const [savingCurseForgeKey, setSavingCurseForgeKey] = useState(false);
  const [curseForgeKeyMessage, setCurseForgeKeyMessage] = useState('');
  useEffect(() => setDraft(settings), [settings]);
  useEffect(() => { void api.hasCurseForgeApiKey().then(setCurseForgeKeySaved).catch(() => setCurseForgeKeySaved(false)); }, []);
  const save = async () => { setSaving(true); try { await onSave(draft); } finally { setSaving(false); } };
  const saveCurseForgeKey = async () => { setSavingCurseForgeKey(true); setCurseForgeKeyMessage(''); try { await api.setCurseForgeApiKey(curseForgeKey); setCurseForgeKey(''); setCurseForgeKeySaved(true); setCurseForgeKeyMessage('API key saved securely in Windows Credential Manager.'); } catch (error) { setCurseForgeKeyMessage(error instanceof Error ? error.message : 'Could not save API key.'); } finally { setSavingCurseForgeKey(false); } };
  return <>
    <PageHeading eyebrow="PREFERENCES" title="Settings" subtitle="Make VOID CLIENT feel like yours." action={<button className="button button-primary" onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button>} />
    <div className="settings-layout"><div className="settings-card"><div className="settings-section"><div><h3>Appearance</h3><p>Choose the look and feel of your launcher.</p></div><div className="setting-control"><span className="setting-label">ACCENT COLOR</span><div className="accent-options">{['violet', 'blue', 'mint', 'orange'].map(color => <button key={color} aria-label={`${color} accent`} className={`accent-swatch ${color} ${draft.accent === color ? 'chosen' : ''}`} onClick={() => setDraft({ ...draft, accent: color })} />)}</div></div><div className="setting-control"><span className="setting-label">THEME</span><div className="choice-row">{['dark', 'light'].map(theme => <button key={theme} className={`choice-chip ${draft.theme === theme ? 'chosen' : ''}`} onClick={() => setDraft({ ...draft, theme })}>{theme === 'dark' ? 'Dark' : 'Light'}</button>)}</div></div></div><div className="settings-divider" /><div className="settings-section"><div><h3>Downloads</h3><p>Control concurrent downloads when the download manager is connected.</p></div><div className="setting-control"><div className="field-row"><span className="setting-label">MAXIMUM SIMULTANEOUS DOWNLOADS</span><strong>{draft.maxDownloads}</strong></div><input className="range-input" type="range" min="1" max="16" value={draft.maxDownloads} onChange={e => setDraft({ ...draft, maxDownloads: Number(e.target.value) })} /></div></div><div className="settings-divider" /><div className="settings-section curseforge-integration-section"><div><h3>CurseForge integration</h3><p>CurseForge requires an API key for approved third-party launcher access. The key is stored in Windows Credential Manager, not launcher settings.</p></div><div className="curseforge-key-control"><div className="curseforge-key-status"><ShieldCheck size={15} /><span>{curseForgeKeySaved ? 'API key stored securely' : 'API key not configured'}</span></div><input type="password" autoComplete="off" value={curseForgeKey} onChange={e => setCurseForgeKey(e.target.value)} placeholder={curseForgeKeySaved ? 'Enter a replacement API key' : 'Paste CurseForge API key'} /><div className="curseforge-key-actions"><button className="button button-secondary" onClick={() => void api.openExternalUrl('https://console.curseforge.com/').catch(error => setCurseForgeKeyMessage(`Could not open the CurseForge developer console: ${describeError(error)}`))}>CurseForge developer console <ExternalLink size={13} /></button><button className="button button-primary" onClick={() => void saveCurseForgeKey()} disabled={savingCurseForgeKey || !curseForgeKey.trim()}>{savingCurseForgeKey ? 'Saving…' : 'Save API key'}</button></div>{curseForgeKeyMessage && <small>{curseForgeKeyMessage}</small>}</div></div><div className="settings-divider" /><div className="settings-section"><div><h3>Storage location</h3><p>Launcher data, profiles and cached metadata.</p></div><div className="storage-path"><HardDrive size={16} /><span>{storagePath || 'Loading storage path…'}</span></div></div></div><aside className="settings-card settings-side"><div className="eyebrow">ABOUT VOID CLIENT</div><div className="about-mark">V</div><h3>VOID CLIENT</h3><span className="version-chip">VERSION 0.6.3 · WINDOWS INSTALLER</span><p>A personal Minecraft launcher with isolated instances, version installation, Java runtimes and modpack tools.</p><div className="about-stat"><span>Desktop framework</span><strong>Tauri 2</strong></div><div className="about-stat"><span>Frontend</span><strong>React + TypeScript</strong></div><div className="about-stat"><span>Profile storage</span><strong>Local JSON + folders</strong></div></aside></div>
  </>;
}


function ModpacksPage({ profiles, selectedProfile, onSelectProfile, onRefresh, onNotice }: {
  profiles: Profile[]; selectedProfile: Profile | null; onSelectProfile: (id: string) => void; onRefresh: () => Promise<void>; onNotice: (message: string) => void;
}) {
  const [source, setSource] = useState<'Modrinth' | 'CurseForge'>('Modrinth');
  const [query, setQuery] = useState('');
  const [modrinthHits, setModrinthHits] = useState<ModrinthProject[]>([]);
  const [curseForgeHits, setCurseForgeHits] = useState<CurseForgeMod[]>([]);
  const [loading, setLoading] = useState(false);
  const [installing, setInstalling] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [hasCurseForgeKey, setHasCurseForgeKey] = useState(false);
  const [installingProfileId, setInstallingProfileId] = useState<string | null>(null);
  const [installProgress, setInstallProgress] = useState<EngineProgress | null>(null);
  useEffect(() => { void api.hasCurseForgeApiKey().then(setHasCurseForgeKey).catch(() => setHasCurseForgeKey(false)); }, []);
  useEffect(() => {
    if (!installingProfileId) return;
    let unlisten: (() => void) | undefined;
    void listen<EngineProgress>('void-engine-progress', event => {
      if (event.payload.profileId === installingProfileId || event.payload.profileId === 'runtime') setInstallProgress(event.payload);
    }).then(stop => { unlisten = stop; });
    return () => { unlisten?.(); };
  }, [installingProfileId]);
  const search = async () => {
    setLoading(true); setError('');
    try {
      if (source === 'Modrinth') {
        setModrinthHits(await api.searchModrinth(query.trim(), 'modpack', '', 'Vanilla', 'downloads'));
        setCurseForgeHits([]);
      } else {
        // Modpacks carry their own Minecraft/loader requirements; do not filter them by the target profile.
        setCurseForgeHits(await api.searchCurseForge(query.trim(), 4471, '', 0));
        setModrinthHits([]);
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Could not search modpacks.'); setModrinthHits([]); setCurseForgeHits([]);
    } finally { setLoading(false); }
  };
  useEffect(() => { void search(); }, [source]);
  const makePackProfile = async (packName: string): Promise<Profile> => {
    const baseName = packName.trim().slice(0, 40) || 'Minecraft Modpack';
    let profileName = baseName;
    let suffix = 2;
    while (profiles.some(profile => profile.name.toLowerCase() === profileName.toLowerCase())) {
      const tail = ` (${suffix++})`;
      profileName = `${baseName.slice(0, 48 - tail.length)}${tail}`;
    }
    const latestRelease = selectedProfile?.minecraftVersion ?? (await api.listMinecraftVersions('release'))[0]?.id ?? '1.21.11';
    return api.createProfile({
      name: profileName,
      minecraftVersion: latestRelease,
      loader: 'Vanilla',
      ramGb: selectedProfile?.ramGb ?? 4,
    });
  };
  const installModrinth = async (project: ModrinthProject) => {
    setInstalling(project.project_id);
    let target: Profile | null = null;
    try {
      target = await makePackProfile(project.title);
      setInstallingProfileId(target.id);
      setInstallProgress({ profileId: target.id, stage: 'starting', done: 0, total: 1, percent: 0, detail: 'Preparing modpack installation…' });
      onSelectProfile(target.id);
      onNotice(`Created isolated profile “${target.name}”. Installing ${project.title}…`);
      const result = await api.installModrinthModpack(target.id, project.project_id);
      await onRefresh();
      onNotice(`${target.name}: ${result}`);
    } catch (error) {
      if (target) { await onRefresh(); onSelectProfile(target.id); }
      onNotice(`${target ? `Profile “${target.name}” was created. ` : ''}${error instanceof Error ? error.message : 'Modrinth modpack installation failed.'}`);
    } finally { setInstalling(null); setInstallingProfileId(null); setInstallProgress(null); }
  };
  const installCurseForge = async (project: CurseForgeMod) => {
    const file = project.latestFiles?.[0];
    if (!file?.id) { onNotice('CurseForge did not include a recent pack file for this project. Open the project on CurseForge to check its releases.'); return; }
    setInstalling(String(project.id));
    let target: Profile | null = null;
    try {
      target = await makePackProfile(project.name);
      setInstallingProfileId(target.id);
      setInstallProgress({ profileId: target.id, stage: 'starting', done: 0, total: 1, percent: 0, detail: 'Preparing modpack installation…' });
      onSelectProfile(target.id);
      onNotice(`Created isolated profile “${target.name}”. Installing ${project.name}…`);
      const result = await api.installCurseForgeModpack(target.id, project.id, file.id);
      await onRefresh();
      onNotice(`${target.name}: ${result}`);
    } catch (error) {
      if (target) { await onRefresh(); onSelectProfile(target.id); }
      onNotice(`${target ? `Profile “${target.name}” was created. ` : ''}${error instanceof Error ? error.message : 'CurseForge modpack installation failed.'}`);
    } finally { setInstalling(null); setInstallingProfileId(null); setInstallProgress(null); }
  };
  return <>
    <PageHeading eyebrow="MODPACK DISCOVERY" title="Modpacks" subtitle="Find a pack and install it into a brand-new isolated profile. The launcher selects the pack’s own Minecraft version and mod loader." />
    <div className="modpack-browser settings-card">
      <div className="modpack-toolbar-top"><div className="source-switch"><button className={source === 'Modrinth' ? 'selected' : ''} onClick={() => setSource('Modrinth')}>Modrinth</button><button className={source === 'CurseForge' ? 'selected' : ''} onClick={() => setSource('CurseForge')}>CurseForge</button></div><label className="modpack-target"><span>PROFILE SETTINGS TEMPLATE</span><select value={selectedProfile?.id ?? ''} onChange={e => onSelectProfile(e.target.value)}>{profiles.map(profile => <option key={profile.id} value={profile.id}>{profile.name} · {profile.minecraftVersion}</option>)}</select></label></div>
      <div className="catalog-toolbar modpack-search-row"><div className="catalog-search"><Search size={15} /><input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') void search(); }} placeholder={`Search ${source} modpacks…`} /><button onClick={() => void search()} disabled={loading}><Search size={14} /></button></div><button className="button button-secondary" onClick={() => void search()} disabled={loading}><RefreshCw size={14} /> Refresh</button></div>
      {!selectedProfile && <div className="workspace-warning"><CircleHelp size={15} /> A new isolated profile will be created with default 4 GB memory. The pack supplies its own game version and loader.</div>}
      {source === 'CurseForge' && !hasCurseForgeKey && <div className="workspace-warning"><CircleHelp size={15} /> Add your approved CurseForge API key in Settings → Integrations before searching CurseForge.</div>}
      {installing && <div className="engine-progress modpack-install-progress"><div className="engine-progress-copy"><span>{installProgress?.detail ?? 'Installing modpack…'}</span><strong>{installProgress?.percent ?? 0}%</strong></div><div className="engine-progress-track"><i style={{ width: `${installProgress?.percent ?? 0}%` }} /></div></div>}
      {loading ? <div className="inline-loading"><LoaderCircle className="spin" size={20} /> Searching {source}…</div> : error ? <div className="inline-error"><CircleHelp size={16} /><span>{error}</span><button className="text-button" onClick={() => void search()}>Retry</button></div> : source === 'Modrinth' ? <div className="catalog-grid modpack-results">{modrinthHits.map(hit => <article className="catalog-card" key={hit.project_id}><div className="catalog-card-top">{hit.icon_url ? <img src={hit.icon_url} alt="" /> : <div className="catalog-icon-fallback"><Boxes size={18} /></div>}<div className="catalog-card-title"><strong>{hit.title}</strong><span>by {hit.author}</span></div><button type="button" className="catalog-external" onClick={() => void api.openExternalUrl(`https://modrinth.com/modpack/${hit.slug}`).catch(error => onNotice(describeError(error)))}><ExternalLink size={13} /></button></div><p>{hit.description}</p><div className="catalog-card-bottom"><span><CloudDownload size={12} /> {formatDownloads(hit.downloads)} downloads</span><button className="button button-primary" disabled={installing !== null} onClick={() => void installModrinth(hit)}>{installing === hit.project_id ? <><LoaderCircle size={13} className="spin" /> Installing</> : 'Install pack'}</button></div></article>)}{modrinthHits.length === 0 && <div className="workspace-empty"><Boxes size={24} /><strong>No Modrinth modpacks found</strong><p>Try a different search.</p></div>}</div> : <div className="catalog-grid modpack-results">{curseForgeHits.map(hit => <article className="catalog-card" key={hit.id}><div className="catalog-card-top">{hit.logo?.thumbnailUrl ? <img src={hit.logo.thumbnailUrl} alt="" /> : <div className="catalog-icon-fallback"><Boxes size={18} /></div>}<div className="catalog-card-title"><strong>{hit.name}</strong><span>CurseForge · {formatDownloads(hit.downloadCount)} downloads</span></div><button type="button" className="catalog-external" onClick={() => void api.openExternalUrl(`https://www.curseforge.com/minecraft/modpacks/${hit.slug}`).catch(error => onNotice(describeError(error)))}><ExternalLink size={13} /></button></div><p>{hit.summary}</p><div className="catalog-card-bottom"><span>{hit.latestFiles?.[0]?.fileName ?? 'Latest release'}</span><button className="button button-primary" disabled={installing !== null || !hit.latestFiles?.length} onClick={() => void installCurseForge(hit)}>{installing === String(hit.id) ? <><LoaderCircle size={13} className="spin" /> Installing</> : 'Install pack'}</button></div></article>)}{curseForgeHits.length === 0 && <div className="workspace-empty"><Boxes size={24} /><strong>No CurseForge modpacks found</strong><p>Try a different search or check your API key access.</p></div>}</div>}
      <div className="modpack-footer-note"><ShieldCheck size={14} /><span>Modrinth modpacks are installed from their .mrpack index with SHA-1/SHA-512 file verification and client overrides. CurseForge requires a valid API key; authors may restrict direct downloads for individual files.</span></div>
    </div>
  </>;
}

function formatDownloads(value: number) {
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
  return String(value);
}

function RoadmapPage({ page, onGoSettings }: { page: Page; onGoSettings: () => void }) {
  const descriptions: Record<string, string> = {
    Modpacks: 'Search and install modpacks from Modrinth and CurseForge, with compatible Minecraft versions and loaders.',
    Mods: 'Browse compatible mods, manage versions and resolve dependencies per profile.',
    'Resource Packs': 'Keep resource packs isolated and organized by profile.',
    Shaders: 'Discover shader packs and manage them per Minecraft profile.',
    Worlds: 'Browse, back up and restore the worlds stored in your profiles.',
    Downloads: 'Track active, queued, completed and failed downloads without freezing the launcher.',
  };
  const icons: Record<string, typeof Package> = { Modpacks: Boxes, Mods: Package, 'Resource Packs': Layers3, Shaders: Palette, Worlds: Archive, Downloads: CloudDownload };
  const Icon = icons[page] ?? Package;
  return <><PageHeading eyebrow="LIBRARY & DISCOVERY" title={page} subtitle={descriptions[page]} /><div className="roadmap-panel"><div className="roadmap-icon"><Icon size={23} /></div><div className="roadmap-status"><span className="status-pulse" /> IN DEVELOPMENT</div><h2>This part is being built.</h2><p>The navigation is ready, but this feature is not wired to a real catalog or local installation pipeline yet. No fake results or simulated downloads are shown.</p><div className="roadmap-divider" /><div className="roadmap-next"><div><strong>Current foundation</strong><span>Persistent profiles and isolated folder structure</span></div><div><strong>Next integration</strong><span>Modrinth / CurseForge catalog and verified downloads</span></div></div><button className="button button-secondary" onClick={onGoSettings}><Settings size={15} /> Launcher settings</button></div></>;
}

export default App;
