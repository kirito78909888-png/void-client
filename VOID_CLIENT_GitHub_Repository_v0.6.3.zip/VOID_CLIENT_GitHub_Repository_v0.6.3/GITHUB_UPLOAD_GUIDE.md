# Upload this project to GitHub

1. Create a repository at https://github.com/new (for example, `void-client`).
2. Choose Public or Private. Public is useful if you want to use the repository URL as the project's information page; it exposes the source to everyone.
3. Do not initialize the new repository with another README or license if you plan to push this full folder as-is.
4. Extract this ZIP. The `void-client` folder contains the repository files.

## Recommended: GitHub Desktop

1. Install GitHub Desktop: https://desktop.github.com/
2. In GitHub Desktop choose **File → Add Local Repository** and select the extracted `void-client` folder. If it says this is not a Git repository, choose **create a repository** in that folder.
3. Enter a summary such as `Initial VOID CLIENT source release` and commit.
4. Click **Publish repository** and choose the desired visibility.

## Alternative: Git command line

Open PowerShell in the extracted `void-client` folder. Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username:

```powershell
git init
git add .
git status
git commit -m "Initial VOID CLIENT source release"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/void-client.git
git push -u origin main
```

Review `git status` before committing. Never upload `node_modules`, `dist`, `src-tauri/target`, `.env`, tokens, API keys, saved account data, or Minecraft worlds.

GitHub's browser upload also works: open the new repository, choose **Add file → Upload files**, and upload the contents of the extracted `void-client` folder. Do not upload only this ZIP if you want GitHub to show the source files individually.
