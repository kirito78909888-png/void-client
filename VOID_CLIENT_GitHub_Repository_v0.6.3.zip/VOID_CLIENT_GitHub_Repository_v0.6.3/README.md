# VOID CLIENT

**A Windows-first Minecraft: Java Edition launcher and multi-server manager.**

VOID CLIENT is an independent desktop launcher built with **Tauri 2, React, TypeScript and Rust**. It brings Minecraft profiles, mod discovery, account management, game launching and private server administration into one desktop application.

> **Development status:** This is an actively developed project. Some integrations depend on external account registration, API approval or local Windows configuration. A successful source build does not by itself mean every external service has been approved or tested.

## Features in this source tree

### Minecraft profiles

- Independent profiles with separate game directories, mods, configuration, resource packs, shader packs, saves, screenshots and logs.
- Vanilla and mod-loader installation/launch paths implemented in the engine.
- Per-profile Java executable, memory allocation, JVM arguments and game resolution settings.
- In-app launch console and profile diagnostics.

### Mod and modpack tools

- Modrinth project search and install paths.
- CurseForge search and install paths, requiring a valid API key and eligible API access.
- Mod, resource-pack and shader management inside individual profiles.
- Modrinth modpack installation and `.mrpack` import support.
- CurseForge modpack support where the API supplies an accessible download.

### Accounts

- Microsoft device-code sign-in flow for a configured public Microsoft Entra application.
- Refresh-token storage through the Windows Credential Manager integration.
- Multiple account summaries and account switching.
- Local offline identities for local testing, single-player and servers configured to accept offline-mode connections. Offline identities do **not** authenticate to Microsoft, Xbox, Minecraft Realms or online-mode servers, and do not grant Minecraft ownership.

### Server manager

- Multiple isolated server instances with separate worlds, mods, config, logs and backups.
- Vanilla and Fabric server installation paths.
- Server start, stop, live console, file management and settings.
- RAM setting, Java path, port, max players, MOTD and online-mode setting.
- A CPU thread-count hint (`ActiveProcessorCount`), not a hard Windows CPU quota.
- Playit Windows service detection/start/stop support. Tunnel claiming and tunnel creation are handled in the official Playit app/dashboard.

## Current limitations

- Forge and NeoForge client loader support depends on the current engine installation path; server software installation in this source is currently Vanilla and Fabric.
- Server-side Modrinth dependency installation is currently intended for Fabric servers.
- CurseForge access requires a valid API key and may be subject to provider approval, rate limits or file restrictions.
- Minecraft Services may reject a Microsoft application ID with HTTP 403 until the application is approved for the relevant Minecraft Services access. See [Microsoft/Minecraft App ID information](https://aka.ms/AppRegInfo).
- Playit tunnel provisioning is not implemented through an undocumented API; use the official Playit UI to claim the agent and create tunnels.
- This project has not had an independent security audit. Treat it as development software until you have reviewed and tested the source you build.

## Build on Windows

### Prerequisites

- Windows 10/11 x64.
- Node.js LTS (includes npm).
- Rust stable with the `stable-x86_64-pc-windows-msvc` toolchain.
- Visual Studio Build Tools with **Desktop development with C++** and a Windows SDK.
- WebView2 Runtime (the installer is configured to bootstrap it when needed).

### Install dependencies and build the frontend

Open PowerShell in the repository directory:

```powershell
npm.cmd install
npm.cmd run build
```

### Run the desktop app in development

```powershell
npm.cmd run tauri dev
```

Or double-click `run-windows-dev.bat`.

### Build the Windows setup executable

```powershell
npm.cmd run build:installer
```

Or double-click `build-windows.bat`.

The NSIS installer is produced under:

```text
src-tauri\target\release\bundle\nsis\
```

## Microsoft sign-in setup

Microsoft sign-in needs a **public Application (client) ID** from an Entra app registration. Do not create or embed a client secret in this desktop app.

1. Create an app registration in [Microsoft Entra](https://entra.microsoft.com/).
2. Configure it for the personal Microsoft account types you intend to support.
3. Add the **Mobile and desktop applications** platform if the portal requests a platform.
4. Enable **Allow public client flows** for device-code authentication.
5. Save the **Application (client) ID** in the launcher's Accounts page.
6. For Minecraft Services HTTP 403 / invalid app registration responses, consult [https://aka.ms/AppRegInfo](https://aka.ms/AppRegInfo) and follow the app approval process. Entra configuration alone does not guarantee Minecraft Services approval.

The Client ID is a public identifier, not a password. You can optionally set it for a publisher build in PowerShell before compiling:

```powershell
$env:VOID_CLIENT_MICROSOFT_CLIENT_ID = "YOUR-APPLICATION-CLIENT-ID"
npm.cmd run build:installer
```

Do not put refresh tokens, access tokens, client secrets or CurseForge API keys into source files, README files, commits or issue reports.

## CurseForge setup

CurseForge integration requires API access under CurseForge's current developer terms. Configure the API key in the launcher's Settings page; the source stores it using the Windows Credential Manager integration. Do not commit a key to GitHub.

## Local data and backups

Launcher settings, profile metadata, account summaries and server records are stored in the Tauri application-data directory. Profile and server directories are stored under that data root unless the user configures a different location. Back up this application-data directory before testing destructive operations or changing releases.

Deleting a server from the Servers page removes its selected server directory, including its world. Reinstalling server software is designed to preserve world and configuration data, but backups are still strongly recommended.

## Repository notes

- `package.json` contains `"private": true` to prevent accidental publication to the npm package registry. **It does not make a GitHub repository private.** Choose Public or Private when creating the GitHub repository.
- No open-source license has been selected for this project yet. Unless the author adds a license, other people should not assume they have permission to reuse or redistribute the code.
- Generated folders (`node_modules`, `dist`, `src-tauri/target`) and local environment files are excluded by `.gitignore`.

## Credits and independence

Created by **voidwem / m.af**.

VOID CLIENT is an independent community project and is not affiliated with, endorsed by, or sponsored by Microsoft, Mojang, Minecraft, CurseForge, Modrinth or Playit.gg. Product and service names are used only to identify compatibility/integrations.
