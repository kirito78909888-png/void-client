# Contributing to VOID CLIENT

Thanks for your interest in VOID CLIENT.

## Before making changes

1. Open an issue describing the bug or proposed feature.
2. Avoid changes that bypass Microsoft authentication, Minecraft ownership checks or third-party service access controls.
3. Keep profile and server data isolated; never assume a file path supplied by the UI is safe without validating it in Rust.
4. Never commit API keys, access tokens, refresh tokens, passwords, personal settings files or local game data.

## Development setup

Requirements are listed in `README.md` under **Build on Windows**.

```powershell
npm.cmd install
npm.cmd run build
npm.cmd run tauri dev
```

For a Windows NSIS installer:

```powershell
npm.cmd run build:installer
```

## Pull requests

- Keep changes focused and explain the user-visible impact.
- Include steps to reproduce bugs and test changes.
- Update the README when build steps, external setup or feature limitations change.
- Do not claim an integration works unless it has been tested against the actual external service.
