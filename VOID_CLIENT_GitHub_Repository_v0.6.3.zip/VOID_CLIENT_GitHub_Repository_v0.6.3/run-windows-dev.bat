@echo off
setlocal
cd /d "%~dp0"
echo.
echo  VOID CLIENT - Windows Development Launcher
echo ============================================
echo.
where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js/npm was not found. Install Node.js LTS first.
  goto :failed
)
where cargo.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: Rust/Cargo was not found. Install Rust with the stable MSVC toolchain.
  goto :failed
)

rem Reuse an optional build-time OAuth ID or a previously saved public Client ID.
rem The Accounts page can also save the Client ID for future runs.
if not defined VOID_CLIENT_MICROSOFT_CLIENT_ID (
  for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:APPDATA 'com.voidclient.launcher\settings.json'; if (Test-Path $p) { $s=Get-Content $p -Raw | ConvertFrom-Json; if ($s.microsoftClientId) { $s.microsoftClientId } }" 2^>nul`) do set "VOID_CLIENT_MICROSOFT_CLIENT_ID=%%I"
)
if not defined VOID_CLIENT_MICROSOFT_CLIENT_ID (
  echo NOTE: No Microsoft Client ID is configured yet.
  echo VOID CLIENT will still launch normally. Add the public Application Client ID in Accounts to enable sign-in.
  echo.
) else (
  echo Microsoft sign-in is configured for this development run.
  echo.
)
call npm.cmd install
if errorlevel 1 goto :failed
call npm.cmd run tauri dev
if errorlevel 1 goto :failed
exit /b 0

:failed
echo.
echo VOID CLIENT development launch failed. Review the error above.
pause
exit /b 1
