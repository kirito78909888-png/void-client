# Release notes

## v0.6.3

- Fixes the Settings page CurseForge developer-console link error handler so the TypeScript build no longer references an out-of-scope `onNotice` callback.
- Keeps the Microsoft device-code sign-in browser-opening fix from v0.6.2.
- Includes the multi-server manager and Playit Windows service controls from v0.6.1.

## v0.6.2

- Automatically opens Microsoft's device-code verification URL in the system browser.
- Adds a manual browser retry action and preserves native authentication error details.
- Restricts native external URL opening to approved HTTPS domains.

## v0.6.1

- Adds the Servers page and per-server management foundations.
- Adds server-side Vanilla/Fabric installation paths, console output and server file/config management.
- Adds Playit Windows service detection and controls.
- Improves Microsoft device-code polling and Xbox/XSTS error reporting.

Earlier development history is represented by the prior project snapshots; this repository starts from the v0.6.3 source tree.
