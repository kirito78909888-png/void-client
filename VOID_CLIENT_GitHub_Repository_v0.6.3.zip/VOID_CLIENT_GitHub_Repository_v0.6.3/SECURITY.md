# Security policy

VOID CLIENT is under active development and has not received an independent security audit.

## Reporting a vulnerability

Please do not publish access tokens, refresh tokens, passwords, Client IDs paired with secrets, CurseForge keys, crash dumps containing credentials, or other private data in a public issue.

Until a dedicated security contact is published, contact the repository owner privately through GitHub's private vulnerability reporting feature (if enabled) or another private channel supplied by the owner.

## Credential handling

- Microsoft passwords should only be entered on Microsoft's genuine sign-in pages.
- The desktop application uses a public OAuth Client ID; it must not contain a client secret.
- Microsoft refresh tokens and the CurseForge API key are intended to be stored through Windows Credential Manager.
- Never commit `.env` files, tokens, API keys, local settings or launcher data.
- Offline identities are not authenticated Microsoft accounts and must not be treated as proof of player identity on public servers.
