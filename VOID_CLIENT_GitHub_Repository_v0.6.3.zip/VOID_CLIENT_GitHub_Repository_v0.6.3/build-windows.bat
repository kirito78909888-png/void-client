@echo off
setlocal
cd /d "%~dp0"
echo.
echo  VOID CLIENT - Windows Installer Builder
echo ==========================================
echo.

where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js/npm was not found. Install Node.js LTS first.
  goto :failed
)
where cargo.exe >nul 2>nul
if errorlevel 1 (
  echo ERROR: Rust/Cargo was not found. Install Rust with the stable MSVC toolchain.
  goto :failed
)

 echo [1/3] Configuring optional Microsoft sign-in and installing dependencies...
if not defined VOID_CLIENT_MICROSOFT_CLIENT_ID (
  for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Join-Path $env:APPDATA 'com.voidclient.launcher\settings.json'; if (Test-Path $p) { $s=Get-Content $p -Raw | ConvertFrom-Json; if ($s.microsoftClientId) { $s.microsoftClientId } }" 2^>nul`) do set "VOID_CLIENT_MICROSOFT_CLIENT_ID=%%I"
)
if not defined VOID_CLIENT_MICROSOFT_CLIENT_ID (
  echo.
  echo NOTE: No build-time Microsoft Client ID was provided.
  echo You can configure the public Application Client ID once inside Accounts after installing.
  echo The launcher and installer build do not require OAuth configuration.
  echo.
) else (
  echo Microsoft sign-in has an optional build-time Client ID fallback.
)
call npm.cmd install
if errorlevel 1 goto :failed

echo.
echo [2/3] Building the Windows NSIS setup executable...
call npm.cmd run build:installer
if errorlevel 1 goto :failed

echo.
echo [3/3] Locating installer...
set "BUNDLE_DIR=%CD%\src-tauri\target\release\bundle\nsis"
if not exist "%BUNDLE_DIR%\" (
  echo ERROR: NSIS output folder was not created.
  goto :failed
)
echo.
echo Build complete. Your VOID CLIENT setup EXE is in:
echo %BUNDLE_DIR%
echo.
explorer "%BUNDLE_DIR%"
echo You can now run the *-setup.exe installer.
echo.
pause
exit /b 0

:failed
echo.
echo Installer build failed. Read the error message above.
echo.
pause
exit /b 1
